# @acp/chat-panel v0.3.13 Release Notes

Documentation only. No code, style, or typing changes (dist, styles, and harness files are byte-identical to v0.3.12).

## Why
Hosts that followed the old instruction and imported the two CSS files from `src/main.ts` looked correct with `ng serve` but were unstyled in production builds (for example a Docker image served by nginx), because the production build emits those imports as a lazy `main-<hash>.css` file that nothing links.

## Changed
- README, INTEGRATION_SPEC 1.2 / 2.1 / checklist, SPEC_DOC section 11 and the setup list: load the stylesheets through the build's global stylesheet list (Angular: `angular.json` `styles`), and verify a production build.
- Upgrading from v0.3.12 is optional: no host change is needed for the package itself. A host that imports the CSS from TypeScript should switch to `angular.json` `styles` (see AGENT_GUIDE Step 1.1).
