# @acp/chat-panel v0.3.9 Release Notes

Bulk enrollment form fixes on top of v0.3.8. No other behavior changes.

## Changed files
- `dist/acp-chat-panel.js`: `BuddyEnrolWorkspaceSurface` and one small helper. Nothing else.
- `styles/acp-chat-panel.css`: one additive rule, `.buddy-ws-check-note`.
- Docs: SPEC_DOC 6.3, README, CHANGELOG, AGENT_GUIDE. Test: `tests/bulk-enrollment.html`.
- Not changed: harness connector, chat panel, Workspace/Assembler containers, typings.

## Behavior
| Scenario | v0.3.9 |
|---|---|
| Raw text names a course the agent did not fill | Course is filled from the list; raw text unchanged |
| Course selected in the form | Chip shows the course name immediately; raw text gets it once, in the line's delimiter style |
| Validate after selecting | No duplicate in raw text; selection kept even if the reply echoes an empty course |
| Validation does not pass | Reason shown under the form; Submit stays disabled |
| Line already contains the value | Not added again |
