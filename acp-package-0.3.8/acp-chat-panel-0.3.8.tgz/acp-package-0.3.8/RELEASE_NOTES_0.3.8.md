# @acp/chat-panel v0.3.8 Release Notes

Course list fallback for the bulk enrollment form. No other behavior changes.

## Changed files
- `dist/acp-chat-panel.js`: `BuddyEnrolWorkspaceSurface` plus a small shared catalog loader. Nothing else.
- `dist/acp-chat-panel.d.ts`: `courseCatalogUrl` and `defaultCourseCatalogUrl` on `BuddyEnrolWorkspaceSurface`.
- Docs: SPEC_DOC 6.3, INTEGRATION_SPEC checklist, README, CHANGELOG, AGENT_GUIDE. Test: `tests/bulk-enrollment.html`.
- Not changed: harness connector, chat panel, Workspace/Assembler containers, styles.

## Behavior
| Scenario | v0.3.8 |
|---|---|
| Agent supplies course options | Used as before; no fetch |
| No course options supplied | `mock-api/courses.json` is fetched once, cached, and shared; select filled in place |
| Course list arrives while the user is typing | Typed values, focus, and selection are preserved |
| Agent value is a course name or different case | Resolved to the catalog id; chip label updated |
| Load fails | List stays empty, one warning, retry after 30 seconds |
| Authenticated course API | Not supported by direct fetch; the agent must supply options |
