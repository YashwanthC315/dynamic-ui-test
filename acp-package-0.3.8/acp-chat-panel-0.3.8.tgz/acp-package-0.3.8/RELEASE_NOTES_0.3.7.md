# @acp/chat-panel v0.3.7 Release Notes

Bulk enrollment form fixes on top of v0.3.6. No other behavior changes.

## Changed files
- `dist/acp-chat-panel.js`: `BuddyEnrolWorkspaceSurface` only (plus one additive helper, `normalizeBuddyOptions`).
- Docs: SPEC_DOC section 6.3, INTEGRATION_SPEC checklist, README, CHANGELOG, AGENT_GUIDE.
- New test: `tests/bulk-enrollment.html`.
- Not changed: harness connector, chat panel, Workspace/Assembler containers, styles, typings.

## Behavior
| Scenario | v0.3.7 |
|---|---|
| Prepare returns an invalid date | Shown as text in the form with the warning; becomes a date control once valid |
| User corrects fields in the form | The student's line in Raw Text Input is updated (original date style kept); other lines untouched |
| Course options as strings / id-name / code-title objects | Listed correctly; kept when a validation reply omits them |
| Course or gender supplied as a label | Resolved to the option value |
| Prepare fails, user fixes fields and validates | Submit enables |
| Raw text edited by hand after Prepare | Still requires a new Prepare |
