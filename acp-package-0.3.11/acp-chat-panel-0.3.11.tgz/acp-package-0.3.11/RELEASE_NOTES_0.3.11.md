# @acp/chat-panel v0.3.11 Release Notes

Validation fix on top of v0.3.10. No other behavior changes.

## Changed files
- `dist/acp-harness-bridge.js`: `handleBuddyParse` and `handleBuddyCheck` send the resolved fields (with options) and per-student `labels`.
- `dist/acp-chat-panel.js`: new `resolvedFields()` on `BuddyEnrolWorkspaceSurface`; `reasons` added to the failure message.
- `dist/acp-chat-panel.d.ts`: `resolvedFields()`.
- Docs: SPEC_DOC 6.3, README, CHANGELOG, AGENT_GUIDE. Test: `tests/bulk-enrollment.html`.
- Not changed: chat panel, Workspace/Assembler containers, styles.

## Behavior
| Scenario | v0.3.11 |
|---|---|
| Agent supplies no course options | Prepare/Validate requests carry the course list shown in the form |
| Validate | Each student record includes `labels.courseId` (course name) beside `values.courseId` |
| Agent says not valid with `reasons` | Reasons shown under the form |
