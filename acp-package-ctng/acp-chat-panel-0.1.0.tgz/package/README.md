# @acp/chat-panel

Framework-agnostic, non-overlay AI chat panel and workspace surface package for Angular (all versions: 4–19+) and modern web applications.

This package exposes native W3C Custom Elements:
- `<acp-chat-panel>`: Full-height, resizable AI chat workspace column docked directly beside the sidebar.
- `<acp-dynamic-container>`: Dynamic form container opening immediately to the right of the chat panel.
- `<buddy-enrol-workspace-surface>`: Multi-student enrollment workspace with raw text parser, search, chip strip, and batch submission.
- `<acp-actions-pane>`: Post-commit activity accumulator pane with status kind styling, row action buttons, and kebab overflow menu.

## Quick Installation

In your application root:

```bash
# Option A: Install directly from local path
npm install ./acp-package

# Option B: Pack into a tarball and install
cd acp-package && npm pack
npm install ./acp-package/acp-chat-panel-1.0.0.tgz
```

## Quickstart

### 1. Register Custom Elements
Import once at app startup (`src/main.ts`):
```typescript
import '@acp/chat-panel';
```

### 2. Enable `CUSTOM_ELEMENTS_SCHEMA`
In your Angular shell component or `AppModule`:
```typescript
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

@Component({
  // ...
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
```

### 3. Load Design Tokens and Styles
In `angular.json` or your global stylesheet (`styles.css` / `styles.scss`):
```css
@import '@acp/chat-panel/tokens.css';
@import '@acp/chat-panel/styles.css';
```

### 4. Integration Guide
See [AGENT_GUIDE.md](./AGENT_GUIDE.md) for the complete step-by-step agent guide, shell template markup, flexbox layout rules, and verification checklist.
