const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const ts = require('typescript');

const release = path.resolve(__dirname, '..');
const repository = path.dirname(release);
const baseline = path.join(repository, 'acp-package-0.2.2');
const bundle = path.join(release, 'dist/acp-chat-panel.js');
const declarations = path.join(release, 'dist/acp-chat-panel.d.ts');
const metadata = JSON.parse(fs.readFileSync(path.join(release, 'package.json'), 'utf8'));
assert.strictEqual(metadata.version, '0.2.3');

function loadApi(file) {
  const registered = new Map();
  const context = {
    HTMLElement: class HTMLElement {},
    window: {},
    customElements: {
      get: name => registered.get(name),
      define: (name, element) => registered.set(name, element)
    }
  };
  new vm.Script(fs.readFileSync(file, 'utf8'), { filename: file }).runInNewContext(context);
  return registered;
}

const previousApi = loadApi(path.join(baseline, 'dist/acp-chat-panel.js'));
const currentApi = loadApi(bundle);
assert.deepStrictEqual(Array.from(currentApi.keys()), Array.from(previousApi.keys()));
for (const [tag, previous] of previousApi) {
  const current = currentApi.get(tag);
  for (const member of Object.getOwnPropertyNames(previous.prototype)) {
    const before = Object.getOwnPropertyDescriptor(previous.prototype, member);
    const after = Object.getOwnPropertyDescriptor(current.prototype, member);
    assert(after, `${tag}.${member} was removed`);
    assert.strictEqual(typeof after.value, typeof before.value, `${tag}.${member} changed kind`);
    assert.strictEqual(typeof after.get, typeof before.get, `${tag}.${member} getter changed`);
    assert.strictEqual(typeof after.set, typeof before.set, `${tag}.${member} setter changed`);
  }
  assert.deepStrictEqual(Array.from(current.observedAttributes || []), Array.from(previous.observedAttributes || []));
}
console.log('PASS: bundle syntax and all four 0.2.2 element APIs retained');

const previousTypes = fs.readFileSync(path.join(baseline, 'dist/acp-chat-panel.d.ts'), 'utf8');
const currentTypes = fs.readFileSync(declarations, 'utf8');
assert.strictEqual(currentTypes.replace('v0.2.3', 'v0.2.2'), previousTypes);
const program = ts.createProgram([declarations], {
  noEmit: true, strict: true, types: [], target: ts.ScriptTarget.ES2015,
  lib: ['lib.es2015.d.ts', 'lib.dom.d.ts']
});
const diagnostics = ts.getPreEmitDiagnostics(program);
assert.strictEqual(diagnostics.length, 0, diagnostics.map(diagnostic =>
  ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n')).join('\n'));
console.log('PASS: backward-compatible declarations compile');

function fileList(directory, prefix = '') {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
    const relative = path.join(prefix, entry.name);
    return entry.isDirectory() ? fileList(path.join(directory, entry.name), relative) : [relative];
  }).sort();
}

const original = path.join(repository, 'src/app/agent-chat-panel');
const snapshot = path.join(release, 'src/app/agent-chat-panel');
const originals = fileList(original);
assert.deepStrictEqual(fileList(snapshot), originals);
for (const relative of originals) {
  assert(fs.readFileSync(path.join(original, relative)).equals(fs.readFileSync(path.join(snapshot, relative))),
    `Source snapshot differs: ${relative}`);
}
console.log(`PASS: all ${originals.length} Angular feature files match the current source byte-for-byte`);

const guide = fs.readFileSync(path.join(release, 'AGENT_GUIDE.md'), 'utf8');
assert(metadata.files.includes('AGENT_GUIDE.md'));
assert(metadata.files.includes('SPEC_DOC.md'));
assert(fs.existsSync(path.join(release, 'dist/styles.css')));
assert(guide.includes('v0.2.3') && !guide.includes('v0.2.2'));
const controller = Array.from(guide.matchAll(/```typescript\r?\n([\s\S]*?)```/g))
  .map(match => match[1]).find(text => text.includes('class AppShellComponent'));
assert(controller, 'Guide controller example missing');
const source = ts.createSourceFile('guide.ts', controller, ts.ScriptTarget.Latest, true);
assert.strictEqual(source.parseDiagnostics.length, 0, 'Guide controller syntax is invalid');
const shell = source.statements.find(statement => ts.isClassDeclaration(statement));
const members = new Set(shell.members.map(member => member.name && member.name.getText(source)));
const compiler = require('@angular/compiler');
const template = /```html\r?\n([\s\S]*?)```/.exec(guide)[1];
const parsedTemplate = new compiler.HtmlParser().parse(template, 'guide.html');
assert.strictEqual(parsedTemplate.errors.length, 0, 'Guide HTML is invalid');
const shellBody = parsedTemplate.rootNodes[0].children.find(node => node.name === 'div');
const workspaceRow = shellBody.children.find(node => node.name === 'div');
assert.deepStrictEqual(workspaceRow.children.filter(node => node.name).map(node => node.name),
  ['acp-chat-panel', 'acp-dynamic-container', 'acp-actions-pane', 'main']);
const templateWithoutComments = template.replace(/<!--[\s\S]*?-->/g, '');
for (const binding of templateWithoutComments.matchAll(/(?:\[[^\]]+\]|\([^\)]+\))="([^"]+)"/g)) {
  const expression = ts.createSourceFile('expression.ts', binding[1], ts.ScriptTarget.Latest, true);
  const checkMember = node => {
    if (ts.isIdentifier(node) && !(node.parent && ts.isPropertyAccessExpression(node.parent) && node.parent.name === node)) {
      assert(node.text === '$event' || members.has(node.text), `Guide references missing controller member: ${node.text}`);
    }
    ts.forEachChild(node, checkMember);
  };
  checkMember(expression);
}
assert(template.includes('(acp-link-click)'));
assert(!template.includes('(acp-suggestion-click)') && !template.includes('$event.detail'));
console.log('PASS: packaged guide/styles, template bindings, and direct-sibling layout');

const guideModule = { exports: {} };
const decorators = { Component: () => target => target, ViewChild: () => () => {} };
const javascript = ts.transpileModule(controller, {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2015, experimentalDecorators: true }
}).outputText;
new vm.Script(javascript, { filename: 'guide-controller.js' }).runInNewContext({
  exports: guideModule.exports,
  require: name => name === '@angular/core' ? decorators : require(name)
});
const { Observable } = require('rxjs');
const requests = [];
const request = url => new Observable(subscriber => {
  const pending = { url, subscriber, aborted: false };
  requests.push(pending);
  return () => { pending.aborted = true; };
});
const navigations = [];
const host = new guideModule.exports.AppShellComponent(
  { post: url => request(url), get: url => request(url) },
  { url: '/home', navigateByUrl: href => navigations.push(href) }
);
host.onChatMessage('hello');
assert.strictEqual(host.isPending, true);
host.onCancelRequest();
assert(requests[0].aborted && requests[0].subscriber.closed, 'Cancellation did not tear down the request');
requests[0].subscriber.next({ text: 'late canceled reply' });
assert.strictEqual(host.messages.length, 2, 'Canceled reply appended to messages');
host.onChatMessage('another turn');
host.onNewChat();
assert(requests[1].aborted && !host.isPending && host.messages.length === 0);
host.onRestoreConversation({ conversationId: 'thread/1' });
assert(requests[2].url.endsWith('thread%2F1'));
host.onNewChat();
requests[2].subscriber.next({ messages: [{ text: 'late history' }] });
assert.strictEqual(host.messages.length, 0, 'Canceled history restore replaced the new chat');
host.onNavigate({ href: '/fees/transactions' });
host.onNavigate({ href: '//external.example' });
host.onNavigate({ href: '/\\external.example' });
assert.deepStrictEqual(navigations, ['/fees/transactions']);
host.workspacePane = { nativeElement: { minimized: true, maximized: true } };
host.actionsPane = { nativeElement: { minimized: true, maximized: true } };
host.restoreDefaultSplit();
assert(!host.workspacePane.nativeElement.maximized && !host.actionsPane.nativeElement.maximized);
assert(!host.workspacePane.nativeElement.minimized && !host.actionsPane.nativeElement.minimized);
host.ngOnDestroy();
console.log('PASS: guide cancellation, late-reply suppression, navigation guard, and restore behavior');