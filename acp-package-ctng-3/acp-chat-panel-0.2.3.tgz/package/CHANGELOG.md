# 0.2.3

## Standalone Distribution

- Based on the complete 0.2.2 distribution, not the older unversioned package.
- Workspace resize and maximize reserve space for visible sibling panes.
- Assembler resize and maximize use the same parent-aware width constraint.
- Parent/sibling resizing updates pane geometry without re-rendering form content.
- All four custom element tags, existing methods/properties, event names,
  and TypeScript declarations remain compatible with 0.2.2.
- Added npm metadata, integration notes, and repeatable regression checks.
- Included the corrected 0.2.3 agent guide and standalone `dist/styles.css`.
- Guide examples use direct flex siblings, actual client cancellation,
  single-path navigation, defined height bindings, and complete split restore.
- Documented that Angular 22 host compilation and live backend flows are unverified.

## Current Angular Source Included

The complete feature folder is copied without modifications from the current
working tree at `3f7d6f73db4fe70dc4956e457682fe81afd35045`, including its tests.
The untracked 0.2.2 artifacts have no git release commit, so these are included
current capabilities, not a claimed exact commit-by-commit delta from 0.2.2.

- Workspace resize limit and maximize state update (`ff86bc08`).
- Store-backed view context bricks, serialization, and tool filtering (M14).
- Configurable agent file-run HTTP port and read-only events socket (M15-T1/T2).
- File-run send/reply/parse flow, agent labels, and applied buddy notes (M15-T3).
- Record validation and host-local record selection (M15-T4/T5).
- Enrolment persistence through effects and course-option fallback (M15-T6).
- Separate suggestion runs and chips-shaped reply handling (M15-T7).
- Conversation list no longer calls mock-harness listing; an empty list is
  intentional when no history service is configured (M15-T8).

These Angular integration changes are included as source. They are not silently
substituted for the standalone Web Components' existing host event contract.