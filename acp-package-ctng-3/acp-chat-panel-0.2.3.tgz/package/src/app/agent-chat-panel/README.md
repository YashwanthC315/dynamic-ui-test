# Shared Agent Chat Panel

This folder is the root-level shared copy of the reusable Angular chat component.

## Contents

- `components/agent-chat-panel.component.ts`
- `components/agent-chat-panel.component.html`
- `services/chat-contracts.ts`
- `services/chat-transport-adapter.service.ts`
- `services/ct-bot-host-protocol.ts`
- `services/ct-bot-host.service.ts`
- `services/mock-agent-harness.service.ts`
- `styles/agent-chat-panel.css`

## Intended Use

Each app (current and future) can copy these files into its own `src/app` structure and wire host-specific state/actions.

Suggested destination in an app:

- `src/app/components/agent-chat-panel.component.ts`
- `src/app/components/agent-chat-panel.component.html`
- `src/app/services/chat-contracts.ts`
- `src/app/services/chat-transport-adapter.service.ts`
- `src/app/services/ct-bot-host-protocol.ts`
- `src/app/services/ct-bot-host.service.ts`
- `src/app/services/mock-agent-harness.service.ts`

Then import `styles/agent-chat-panel.css` rules into the app-level stylesheet.

Phase 3 portability wiring is provider/token-based:

- Register `DEFAULT_AGENT_CHAT_PORT_PROVIDERS` from `services/portability/default-agent-chat-port.providers.ts`.
- This binds state/response ports and default surface plugins via `AGENT_CHAT_SURFACE_PLUGINS`.
- The panel core resolves dynamic surfaces through plugin registration instead of hard-coded component imports.

Detailed integration steps are documented in `docs/agent-chat-panel-portability-guide.md`.

Recommended shared component inputs in host templates:

- `[appContext]`: high-level app/screen metadata.
- `[hostContext]`: domain-specific context payload.
- `[entities]`: optional generic entity list for count/context.

Backward compatibility aliases are still accepted:

- `[feeContext]` (legacy alias of `hostContext`)
- `[students]` (legacy alias of `entities`)

The host app should decide:

- Sidebar placement (left/right, docked, drawer, overlay).
- Open/close interaction and shell layout behavior.
- Final visual theming via `.agent-*` style overrides.

## Notes

- The component remains domain-agnostic at the UI layer.
- Host app owns non-link navigation/state updates from `agentEvent` output.
- `CtBotHostService` is a thin WebSocket host transport for CT-Bot protocol v1.
  It sends `user_message` and `emit_event`, renders assistant blocks in the
  panel (`text`, `link`, `form`, `confirmation`).
- In-flight chat copy is intentionally plain-language: `Thinking...` during request processing.
- Navigation guidance is click-to-navigate: assistant `link` blocks render as controls and route only after user click (no auto-route on response receipt).
- Assistant replies may include optional `suggestions` chips from the harness:
  - `send_message` chips send the provided text through normal chat-submit flow.
  - `navigate` chips use the same safe internal navigation click path as `link` blocks.
- Conversation history is loaded from mock-harness REST (`GET /v1/conversations`, `GET /v1/conversations/:id`) with user scoping.
- Active thread `conversationId` is retained across refresh and restored from the REST history API.
- Assistant replay restores full renderable payload blocks (`text`, `link`, `suggestions`) from persisted assistant responses.
- WS transport and REST history client both use the same shared token resolver (`CtBotSessionTokenService`): NgRx `app.accessToken` first, then sessionStorage access-token keys.

## CT-Bot local development

Run the standalone mock with `npm run mock-harness:dev` from the repository
root (or `cd mock-harness && npm run dev`). Open the Agent drawer from the
application shell while logged in, then send: `take me to fees`.

Expected result:

- assistant text appears in the chat
- assistant shows an **Open Fees** link
- app routes to `/fees` only after clicking the link

Collect-intent polish uses route-aware navigation:

- `take me home` returns a link to `/home` (home dashboard)
- `take me to fees` returns a link to `/fees` (overview dashboard)
- `collect fees` returns a link to `/fees/add` (operational recording screen)
- `institute info`, `inst details`, `about the organization` (or `about the institute`) return API-backed summary text when available and a link to `/admin/inst`
- `send marks cards` (or `marks card email`) returns guidance text and a link to `/connect/marksCardRecipients`
- unknown destinations (for example `take me to the moon`) return safe guidance with supported destinations only (no auto-route, no invented routes)
- replies may include “what next” suggestion chips (for example, Open fee transactions / Collect fees / Institute info)

Phase 6a institute flow uses FE-mediated authenticated data:

- On institute-info intent, `CtBotHostService` loads institute snapshot via `CTApi.getInst(...)` using current logged-in session.
- The snapshot is attached in `user_message.context.institute` for harness-side formatting.
- If the API call fails, context marks institute data unavailable so harness returns honest failure text (no invented brochure summary) and can still include a link to `/admin/inst`.

The host continues to send context on every `user_message` and `emit_event`.

Phase 6c host context bag:

- `route` (guaranteed)
- `moduleFlags.underFees|underConnect|underStudent` (guaranteed; derived from route)
- `persona` (best-effort from app/auth state)
- `view` (when a view provider can supply it; currently Fees under `/fees`)
- `focus` remains best-effort from selected entity in store (`student` / `applicant` / `null`) but is not required for fee answers
- `flags.underFees` remains for backward compatibility

View context is provider-driven:

- `CtBotHostService` evaluates registered view providers per route.
- `FeesViewContextProvider` is the first provider and snapshots loaded Fees rows as flat scalar objects.
- Snapshot rows are bounded (`maxRows`), include discovered `columns`, and skip nested/non-scalar blobs.
- The shape is generic so additional modules can add providers later without protocol redesign.

Example:

```json
{
  "route": "/fees/transactions",
  "persona": "Admin",
  "moduleFlags": { "underFees": true, "underConnect": false, "underStudent": false },
  "view": {
    "module": "fees",
    "screen": "transactions",
    "columns": ["studentName", "txDate", "amount", "due", "txNo"],
    "rowCount": 2,
    "truncated": false,
    "maxRows": 30,
    "rows": [
      { "studentName": "Abhay Kulkarni", "txDate": "2026-07-02", "amount": 1200, "due": 300, "txNo": "RCPT-101" }
    ]
  },
  "focus": { "type": "student", "id": "stu_123", "label": "Ananya Rao" },
  "flags": { "underFees": true }
}
```

For fee paid/due/date questions, live mode uses model-over-snapshot from `context.view` rows/columns and explicitly avoids inventing values.
For prompts like "what can you see?", the harness summarizes screen/columns/sample rows from `context.view` in plain text.
No separate name-lookup API call is wired here yet; answer quality depends on rows already loaded in the current Fees view snapshot.

Browser WebSockets cannot set custom headers, so when an access token exists
it is attached as the `access_token` query parameter. For local mock use, no
token is required.

For REST history requests, configure:

- `AGENT_HARNESS_API_URL` (optional; defaults from `AGENT_HARNESS_WS_URL` when omitted)
