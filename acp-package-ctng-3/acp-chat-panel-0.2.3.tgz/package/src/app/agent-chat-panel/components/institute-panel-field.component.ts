import { Component, HostBinding, Input } from '@angular/core';

@Component({
  selector: 'app-institute-panel-field',
  template: `
    <span class="institute-label">{{ label }}</span>
    <a class="institute-value" *ngIf="isLink" [href]="href" target="_blank" rel="noopener">{{ displayValue }}</a>
    <span class="institute-value" *ngIf="!isLink">{{ displayValue }}</span>
  `,
  styles: [`
    :host {
      min-width: 0;
      display: block;
    }
    .institute-label {
      display: block;
      margin-bottom: 3px;
      color: #64748b;
      font-size: 11px;
      font-weight: 600;
      letter-spacing: .04em;
      text-transform: uppercase;
    }
    .institute-value {
      display: block;
      overflow-wrap: anywhere;
      line-height: 1.4;
    }
    a.institute-value {
      color: #1565c0;
      text-decoration: none;
    }
    a.institute-value:hover {
      text-decoration: underline;
    }
  `]
})
export class InstitutePanelFieldComponent {
  @Input() label = '';
  @Input() displayValue = '';
  @Input() isLink = false;
  @Input() href = '';
  @Input() wide = false;

  @HostBinding('class.institute-field') readonly hostFieldClass = true;

  @HostBinding('class.institute-field-wide')
  get hostWideClass(): boolean {
    return this.wide;
  }
}
