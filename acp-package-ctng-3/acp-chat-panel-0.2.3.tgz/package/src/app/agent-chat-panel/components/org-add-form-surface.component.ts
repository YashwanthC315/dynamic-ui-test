import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild, ViewContainerRef } from '@angular/core';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs/Subscription';

import * as rootReducer from '../../rootReducer';
import { OrgService } from '../../org/service/service';
import { OrgAddFieldOption, OrgAddFieldSchema } from './org-add-field.component';
import { OrgAddSurfaceRendererService } from '../services/org-add-surface-renderer.service';

interface OrgDraftModel {
  name: string;
  shortName: string;
  parentId: string;
  ownerId: string;
}

interface OrgAddSchema {
  fields?: OrgAddFieldSchema[];
}

@Component({
  selector: 'app-org-add-form-surface',
  template: `
    <div class="org-add-surface">
      <div class="org-add-surface-head">
        <h3>{{ title || 'Add New Org' }}</h3>
        <p>Fill in the organization details, then submit to save, or continue in the full form.</p>
      </div>

      <div class="org-add-form">
        <ng-container #fieldHost></ng-container>

        <div class="org-add-actions">
          <button type="button" class="org-add-save-btn" [disabled]="!canSave()" (click)="onSubmit()">
            {{ submitted ? 'Saving...' : 'Submit' }}
          </button>
          <button type="button" class="org-add-continue-btn" [disabled]="submitted" (click)="onContinue()" title="Continue in full form">
            Continue in full form
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`` +
    `.org-add-surface {
      padding: 18px;
      color: #243447;
      background: #fff;
      font-size: 14px;
    }
    .org-add-surface-head {
      margin-bottom: 14px;
    }
    .org-add-surface-head h3 {
      margin: 0 0 6px;
      font-size: 20px;
      line-height: 1.2;
    }
    .org-add-surface-head p {
      margin: 0;
      color: #5a6b7b;
      font-size: 12px;
      line-height: 1.4;
    }
    .org-add-form {
      display: grid;
      gap: 12px;
    }
    .org-add-field {
      display: grid;
      gap: 4px;
    }
    .org-add-field label {
      color: #5a6b7b;
      font-size: 12px;
      font-weight: 600;
      letter-spacing: .03em;
      text-transform: uppercase;
    }
    .org-add-field input,
    .org-add-field select {
      height: 36px;
      border: 1px solid #ced8e3;
      border-radius: 6px;
      padding: 0 10px;
      background: #fff;
    }
    .org-add-field.has-error input {
      border-color: #d9534f;
    }
    .org-add-field small {
      color: #6b7a89;
      font-size: 11px;
    }
    .org-add-actions {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      padding-top: 6px;
    }
    .org-add-save-btn {
      background: #2f9e44;
      border: 0;
      border-radius: 6px;
      color: #fff;
      font-weight: 600;
      padding: 8px 12px;
      cursor: pointer;
    }
    .org-add-save-btn[disabled],
    .org-add-continue-btn[disabled] {
      opacity: 0.65;
      cursor: not-allowed;
    }
    .org-add-continue-btn {
      background: #fff;
      border: 1px solid #ced8e3;
      border-radius: 6px;
      color: #243447;
      font-weight: 600;
      padding: 8px 12px;
      cursor: pointer;
    }`],
  providers: [OrgService]
})
export class OrgAddFormSurfaceComponent implements OnInit, OnDestroy {
  @ViewChild('fieldHost', { read: ViewContainerRef }) fieldHost: ViewContainerRef | null = null;

  @Input() title: string | null = null;
  @Input() initialValues: Partial<OrgDraftModel> | null = null;
  @Input() schema: OrgAddSchema | null = null;
  @Input() formId: string | null = null;
  @Input() submitAction: string | null = null;
  @Input() correlationId: string | null = null;
  @Output() formSubmit = new EventEmitter<{
    formId?: string;
    action: string;
    correlationId: string;
    values: Record<string, any>;
  }>();
  @Output() formContinue = new EventEmitter<{
    formId?: string;
    action: string;
    correlationId: string;
    values: Record<string, any>;
  }>();

  draft: Record<string, any> = {};
  firstLevelOrgs: any[] = [];
  modules: any[] = [];
  private fields: OrgAddFieldSchema[] = [];
  submitted = false;

  private subFirstLevelOrgs: Subscription | null = null;
  private subModules: Subscription | null = null;

  constructor(
    private readonly service: OrgService,
    private readonly store: Store<rootReducer.State>,
    private readonly renderer: OrgAddSurfaceRendererService
  ) {}

  ngOnInit(): void {
    this.fields = this.resolveFields();
    this.draft = this.createInitialDraft(this.fields, this.initialValues || {});
    if (this.needsOrgLookup()) {
      this.service.getFirstLevelOrgs();
      this.service.getModules();

      this.subFirstLevelOrgs = this.store.select(rootReducer.get_first_level_orgs).subscribe((res) => {
        if (res) {
          this.firstLevelOrgs = res;
          this.renderFields();
        }
      });

      this.subModules = this.store.select(rootReducer.get_modules).subscribe((res) => {
        if (res) {
          this.modules = res;
          this.renderFields();
        }
      });
    }

    setTimeout(() => this.renderFields());
  }

  ngOnDestroy(): void {
    if (this.subFirstLevelOrgs) {
      this.subFirstLevelOrgs.unsubscribe();
      this.subFirstLevelOrgs = null;
    }
    if (this.subModules) {
      this.subModules.unsubscribe();
      this.subModules = null;
    }
    this.renderer.clearAllComponents();
  }

  canSave(): boolean {
    if (this.submitted) {
      return false;
    }
    return this.fields
      .filter((field) => !!field.required)
      .every((field) => !!this.toText(this.draft[field.id]).trim());
  }

  remainingShortNameChars(): number {
    return Math.max(0, 6 - this.toText(this.draft['shortName']).length);
  }

  asOptionValue(value: any): string {
    if (value === null || value === undefined) {
      return '';
    }
    return String(value);
  }

  resetSubmitting(): void {
    this.submitted = false;
  }

  onSubmit(): void {
    if (!this.canSave()) {
      return;
    }
    this.submitted = true;
    this.formSubmit.emit(this.buildFormPayload(this.submitAction || 'org.add.submit'));
  }

  onContinue(): void {
    if (this.submitted) {
      return;
    }
    this.formContinue.emit(this.buildFormPayload('org.add.continue'));
  }

  private buildFormPayload(defaultAction: string): {
    formId?: string;
    action: string;
    correlationId: string;
    values: Record<string, any>;
  } {
    const action = (this.submitAction && String(this.submitAction).trim()) || defaultAction;
    const correlationId = (this.correlationId && String(this.correlationId).trim())
      || (this.formId && String(this.formId).trim())
      || 'org-add-thin';
    return {
      formId: this.formId || undefined,
      action: action,
      correlationId: correlationId,
      values: this.collectValues()
    };
  }

  private collectValues(): Record<string, any> {
    const values: Record<string, any> = {};
    this.fields.forEach((field) => {
      values[field.id] = this.toText(this.draft[field.id]);
    });
    return values;
  }

  private renderFields(): void {
    if (!this.fieldHost) {
      return;
    }
    this.renderer.renderFields(
      this.fields,
      this.draft,
      this.fieldHost,
      (field) => this.resolveFieldOptions(field),
      (fieldId, value) => {
        this.draft[fieldId] = value;
      }
    );
  }

  private needsOrgLookup(): boolean {
    return this.fields.some((field) => {
      const isOrgField = field.optionsSource === 'firstLevelOrgs'
        || ((field.id === 'parentId' || field.id === 'ownerId') && field.type === 'select');
      if (field.optionsSource !== 'modules' && !isOrgField) {
        return false;
      }
      return !(field.options && field.options.length);
    });
  }

  private resolveFields(): OrgAddFieldSchema[] {
    if (this.schema && Array.isArray(this.schema.fields) && this.schema.fields.length) {
      return this.schema.fields;
    }

    return [
      { id: 'name', label: 'Name', type: 'text', required: true, maxLength: 50 },
      { id: 'shortName', label: 'Short Name', type: 'text', required: true, maxLength: 6, helperText: 'Up to 6 characters' },
      { id: 'parentId', label: 'Parent', type: 'select', optionsSource: 'firstLevelOrgs' },
      { id: 'ownerId', label: 'Owner', type: 'select', optionsSource: 'firstLevelOrgs' },
    ];
  }

  private createInitialDraft(fields: OrgAddFieldSchema[], values: Record<string, any>): Record<string, any> {
    const draft: Record<string, any> = {};
    fields.forEach((field) => {
      draft[field.id] = this.toText(values && values[field.id]);
    });
    return draft;
  }

  private resolveFieldOptions(field: OrgAddFieldSchema): OrgAddFieldOption[] {
    if (field.options && field.options.length) {
      return field.options;
    }

    if (field.optionsSource === 'modules') {
      return (this.modules || []).map((module) => ({
        label: this.toText(module && (module.name || module.label || module.id)),
        value: this.toText(module && module.id)
      })).filter((option) => !!option.value);
    }

    if (field.optionsSource === 'firstLevelOrgs'
      || ((field.id === 'parentId' || field.id === 'ownerId') && field.type === 'select')) {
      return (this.firstLevelOrgs || []).map((org) => ({
        label: this.toText(org && org.name),
        value: this.toText(org && org.id)
      })).filter((option) => !!option.value);
    }

    return [];
  }

  private toText(value: any): string {
    if (value === null || value === undefined) {
      return '';
    }
    return String(value);
  }
}
