import { Component, EventEmitter, HostBinding, Input, Output } from '@angular/core';
import { ActivityAction, ActivityItem, ActivityLogSurface } from '../services/surface-contracts';

/**
 * P0-B2 dumb presentational activity list for the result pane.
 * Renders `ActivityItem[]` as human lines with kind tones; action buttons raise
 * `actionClick` for the host to interpret (P0-B4 wires focus_record there).
 * No CTApi, no ChatFacade.
 */
@Component({
  selector: 'app-activity-log-list',
  template: `
    <ul class="activity-log-list">
      <li
        *ngFor="let item of surface?.items"
        class="activity-log-item"
        [class.activity-log-info]="item.kind === 'info'"
        [class.activity-log-success]="item.kind === 'success'"
        [class.activity-log-warning]="item.kind === 'warning'"
        [class.activity-log-error]="item.kind === 'error'"
      >
        <span class="activity-log-text">{{ item.text }}</span>
        <span class="activity-log-actions" *ngIf="item.actions && item.actions.length">
          <button
            type="button"
            class="activity-log-action"
            *ngFor="let action of item.actions"
            (click)="onActionClick(item, action)"
          >{{ action.label }}</button>
        </span>
      </li>
    </ul>
  `,
  styles: [`
    :host {
      display: block;
    }
    .activity-log-list {
      list-style: none;
      margin: 0;
      padding: 0;
    }
    .activity-log-item {
      display: flex;
      align-items: baseline;
      justify-content: space-between;
      gap: 8px;
      padding: 8px 10px;
      margin-bottom: 6px;
      border-radius: 4px;
      border-left: 3px solid #c7cfdb;
      background: #f8fafc;
      font-size: 13px;
      line-height: 1.4;
      overflow-wrap: anywhere;
    }
    .activity-log-info    { border-left-color: #4670b8; }
    .activity-log-success { border-left-color: #2e7d32; background: #f1f8f1; }
    .activity-log-warning { border-left-color: #b8860b; background: #fdf8ee; }
    .activity-log-error   { border-left-color: #c62828; background: #fdf1f1; }
    .activity-log-text { flex: 1 1 auto; }
    .activity-log-actions {
      display: flex;
      gap: 6px;
      flex: 0 0 auto;
    }
    .activity-log-action {
      background: #fff;
      border: 1px solid #c7cfdb;
      border-radius: 3px;
      padding: 2px 8px;
      font-size: 12px;
      cursor: pointer;
    }
  `]
})
export class ActivityLogListComponent {
  @Input() surface: ActivityLogSurface | null = null;

  @Output() actionClick = new EventEmitter<{ item: ActivityItem; action: ActivityAction }>();

  @HostBinding('class.activity-log-host') readonly hostClass = true;

  onActionClick(item: ActivityItem, action: ActivityAction): void {
    this.actionClick.emit({ item, action });
  }
}
