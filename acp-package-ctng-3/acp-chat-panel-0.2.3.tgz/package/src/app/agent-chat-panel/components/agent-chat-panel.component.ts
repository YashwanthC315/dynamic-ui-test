import { CommonModule } from '@angular/common';
import {
  AfterViewChecked,
  ComponentRef,
  Component,
  ComponentFactoryResolver,
  ElementRef,
  EventEmitter,
  HostListener,
  Inject,
  OnDestroy,
  Input,
  OnInit,
  Optional,
  Output,
  ViewContainerRef,
  ViewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Subscription } from 'rxjs';
import { NavigationEnd, Router } from '@angular/router';
import {
  ChatAction,
  ChatBlock,
  ChatContext,
  ChatEmitEventRequest,
  ChatRequest,
  ChatResponse,
  ChatResponseStatus,
  ChatSuggestionAction,
} from '../services/chat-contracts';
import { HarnessSaveActivity } from '../services/ct-bot-host-protocol';
import { environment } from '../../../../env/environment';
import { CtBotHostService } from '../services/ct-bot-host.service';
import {
  ConversationDetailResponse,
  ConversationListItem,
  PersistedConversationMessage,
} from '../services/ct-bot-conversation-history.service';
import { ChatFacade } from '../services/chat.facade';
import { ChatResponseForwarder } from '../services/chat-response-forwarder.service';
import {
  AGENT_CHAT_RESPONSE_PORT,
  AGENT_CHAT_SURFACE_PLUGINS,
  AGENT_CHAT_STATE_PORT,
  AgentChatResponsePort,
  AgentChatSurfacePluginPort,
  AgentChatStatePort,
} from '../services/portability/agent-chat-port.contracts';
import { AgentSurface, ActivityAction, ActivityItem, ActivityLogSurface } from '../services/surface-contracts';
import {
  ActivityLogSurfacePlugin,
  assemblerFallbackMenuActions,
  assemblerFallbackRowActions,
  normalizeAssemblerSurface,
} from '../services/portability/default-agent-chat-surface.plugins';

interface ChatEntity {
  id: string;
  label?: string;
  [key: string]: unknown;
}

type MessageRole = 'assistant' | 'user' | 'system' | 'error';

interface ConversationMessage {
  id: string;
  role: MessageRole;
  blocks: ChatBlock[];
  timestamp: string;
  status?: ChatResponseStatus;
  requestId?: string;
  userMessageId?: string;
  agent?: { id?: string; name?: string } | null;
}

interface ChatHistoryItem {
  id: string;
  title: string;
  updatedAt: string;
}

/**
 * M15-T5 follow-up: compose the surface a row click should carry to the
 * store. Focus is set on the surface that ALREADY holds the rows — the
 * live workspace instance's surface keeps the parse-added records; the
 * plugin-closure surface can be stale after a same-id rebind (its
 * records array may be missing or empty, which is exactly how clicking
 * a row emptied the list). A missing/empty records array dispatches
 * nothing — the records stay component/live-surface state.
 */
export function selectRecordSurface(
  closureSurface: AgentSurface | null,
  liveSurface: AgentSurface | null,
  selectedRecordId: string
): AgentSurface | null {
  const selected = String(selectedRecordId || '').trim();
  if (!selected) { return null; }
  const baseRecords = liveSurface && Array.isArray((liveSurface as any).records) ? (liveSurface as any).records
    : (closureSurface && Array.isArray((closureSurface as any).records) ? (closureSurface as any).records : []);
  if (!baseRecords.length) { return null; }
  const base = (liveSurface && baseRecords === (liveSurface as any).records) ? liveSurface : closureSurface;
  return Object.assign({}, base, { activeRecordId: selected, records: baseRecords });
}


@Component({
  selector: 'app-agent-chat-panel',
  templateUrl: './agent-chat-panel.component.html',
  styles: [],
})
export class AgentChatPanelComponent implements AfterViewChecked, OnInit, OnDestroy {
  @Input() isOpen = false;
  @Input() appContext: Record<string, unknown> | null = null;
  @Input() hostContext: Record<string, unknown> | null = null;
  @Input() feeContext: Record<string, unknown> | null = null;
  @Input() entities: ChatEntity[] = [];
  @Input() students: Array<Record<string, unknown>> = [];
  @Input() navigationTabs: Array<{ name?: string; route?: string }> = [];

  @Output() agentEvent = new EventEmitter<Record<string, unknown>>();
  @Output() status = new EventEmitter<string>();
  @Output() panelWidthChange = new EventEmitter<number>();

  @ViewChild('messagesRef') messagesRef: ElementRef<HTMLDivElement> | null = null;
  @ViewChild('searchRef') searchRef: ElementRef<HTMLInputElement> | null = null;
  @ViewChild('composerRef') composerRef: ElementRef<HTMLTextAreaElement> | null = null;
  @ViewChild('panelRoot') panelRoot: ElementRef<HTMLElement> | null = null;
  @ViewChild('rightPanelContainer', { read: ViewContainerRef }) rightPanelContainer: ViewContainerRef | null = null;
  @ViewChild('activityPanelContainer', { read: ViewContainerRef }) activityPanelContainer: ViewContainerRef | null = null;

  messages: ConversationMessage[] = [];
  inputValue = '';
  panelWidth = 380;
  charLimit = 2000;
  readonly inFlightStatusText = 'Thinking...';
  currentAgentDisplay: string | null = null;
  isSearchOpen = false;
  searchTerm = '';
  isHistoryOpen = false;
  chatHistory: ChatHistoryItem[] = [];
  rightPanelVisible = false;
  rightPanelTitle = 'Workspace';
  rightPanelComputedWidth = 380;
  rightPanelComputedHeight = 0;
  private workspaceSize: { width: number; height: number } | null = null;
  private assemblerSize: { width: number; height: number } | null = null;
  rightPanelLeft = 0;
  rightPanelTop = 0;
  // P0-B2 result pane (separate from the work surface pane)
  /** M13: the pane's render state is derived from the STORE surface
   * (activityLog$) plus explicit user actions (⋮ open / close) — the
   * boolean flag is no longer the source of truth for pane content. */
  private assemblerPaneOpen = false;
  activityPanelWidth = 300;
  activityPanelHeight = 0;
  activityPanelLeft = 0;
  activityPanelTop = 0;
  /** M4-T2: Actions pane states — minimize collapses to a slim rail glued
   * to the Workspace panel's right edge (same top/height as Workspace);
   * maximize swaps columns: Workspace itself collapses to a slim rail and
   * Actions takes the remaining width. Reset whenever the pane is hidden so
   * a re-open starts at the default column. */
  activityPanelCollapsed = false;
  activityPanelMaximized = false;
  /** M7-T1: Workspace rail states — − collapses Workspace to the rail
   * (Actions collapses with it when visible); ⤢ widens Workspace over a
   * docked Actions rail. Same 52px rail geometry as Actions. */
  workspaceMinimized = false;
  workspaceMaximized = false;
  /** M5-T2: nine-dots menu on the Actions header (pane-level next steps). */
  activityMenuOpen = false;
  /** M7-T2: nine-dots menu on the full Workspace header (Open Actions). */
  workspaceMenuOpen = false;
  /** M5-T1: latest activity-log snapshot for next-step actions (Copy names). */
  private lastActivityLogSurface: ActivityLogSurface | null = null;
  /** M8-T4: restored enrol Workspace snapshot for the active conversation —
   * cached for reuse when a fresh empty enrol/buddy surface arrives; never
   * auto-opened on refresh or history click. */
  private restoredWorkspaceSurface: AgentSurface | null = null;

  private rightPanelComponentRef: ComponentRef<any> | null = null;
  private activeSurfaceSub: Subscription | null = null;
  private activityLogComponentRef: ComponentRef<any> | null = null;
  private activityLogSub: Subscription | null = null;
  private restoredWorkspaceSub: Subscription | null = null;
  private routerSub: Subscription | null = null;
  private lastNavigationUrl: string | null = null;

  /** M4-T2/M7-T1: per-state geometry — one shared rail width; layouts are
   * the default split, both rails (coupled −), or one wide + one rail
   * (whichever ⤢ was clicked). */
  /** Workspace column width: the shared rail when either panel minimizes
   * Workspace, the wide remainder under Workspace ⤢, else the anchored
   * default width. */
  private get maxWorkspaceWidthPx(): number {
    const viewportPadding = 16;
    const availableWidth = Math.max(280, window.innerWidth - this.rightPanelLeft - viewportPadding);
    if (!this.activityPanelVisible || this.activityPanelCollapsed) {
      return availableWidth;
    }
    const assemblerReserve = 240;
    return Math.min(availableWidth, Math.max(280, window.innerWidth - this.rightPanelLeft - assemblerReserve - 32));
  }

  get rightPanelWidthPx(): number {
    if (this.workspaceMinimized || this.activityPanelMaximized) {
      return this.activityRailWidthPx;
    }
    if (this.workspaceMaximized) {
      // Workspace ⤢ can widen, but never eats the full viewport while the
      // Assembler is open. Keeping a minimum reserve ensures both panes stay
      // usable and the Assembler never auto-closes.
      return Math.max(280, Math.min(this.maxWorkspaceWidthPx, Math.round(window.innerWidth - this.rightPanelLeft - 16)));
    }
    return this.rightPanelComputedWidth;
  }

  startPopupResize(event: MouseEvent, pane: 'workspace' | 'assembler', axis: 'horizontal' | 'vertical' | 'both'): void {
    event.preventDefault();
    event.stopPropagation();
    const workspace = pane === 'workspace';
    const left = workspace ? this.rightPanelLeft : this.activityPanelLeftPx;
    const top = workspace ? this.rightPanelTop : this.activityPanelTopPx;
    const startWidth = workspace ? this.rightPanelWidthPx : this.activityPanelWidthPx;
    const startHeight = workspace ? this.rightPanelComputedHeight : this.activityPanelHeight;
    const startX = event.clientX;
    const startY = event.clientY;
    const cursor = axis === 'both' ? 'nwse-resize' : axis === 'horizontal' ? 'ew-resize' : 'ns-resize';
    document.body.style.cursor = cursor;
    document.body.style.userSelect = 'none';

    const move = (pointer: MouseEvent) => {
      const maxWorkspaceWidth = workspace ? this.maxWorkspaceWidthPx : window.innerWidth - left - 8;
      const width = axis === 'vertical' ? startWidth : Math.max(240, Math.min(maxWorkspaceWidth, startWidth + pointer.clientX - startX));
      const height = axis === 'horizontal' ? startHeight : Math.max(240, Math.min(window.innerHeight - top - 8, startHeight + pointer.clientY - startY));
      if (workspace) {
        this.workspaceSize = { width, height };
        this.rightPanelComputedWidth = width;
        this.rightPanelComputedHeight = height;
        this.updateActivityPanelPosition();
      } else {
        this.assemblerSize = { width, height };
        this.activityPanelWidth = width;
        this.activityPanelHeight = height;
      }
    };
    const up = () => {
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  }

  get activityPanelLeftPx(): number {
    if (this.workspaceMaximized) {
      // M7-T1: the Actions rail docks at the window's right edge.
      return Math.max(0, Math.round(window.innerWidth) - this.activityRailWidthPx - 8);
    }
    if (this.workspaceMinimized && this.activityPanelVisible && !this.activityPanelCollapsed) {
      // M7-T1 geometry: with Workspace at its rail, dock Actions to the
      // rail's right edge — never the stale default-split anchor.
      return this.rightPanelLeft + this.activityRailWidthPx + 4;
    }
    if (this.activityPanelCollapsed) {
      if (this.workspaceMinimized) {
        // Both rails: Actions docks at the Workspace rail's right edge.
        return this.rightPanelLeft + this.activityRailWidthPx + 4;
      }
      // M4-T2: dock, do not overlay — the Actions rail starts at the
      // Workspace panel's right edge (+4px gap), so Workspace ✕ and the
      // enrol form's right edge stay fully visible.
      return this.rightPanelLeft + this.rightPanelComputedWidth + 4;
    }
    if (this.activityPanelMaximized) {
      return this.rightPanelLeft + this.activityRailWidthPx + 8;
    }
    return this.activityPanelLeft;
  }

  get activityPanelTopPx(): number {
    return this.activityPanelCollapsed ? this.rightPanelTop : this.activityPanelTop;
  }

  get activityPanelWidthPx(): number {
    if (this.activityPanelCollapsed) {
      return this.activityRailWidthPx;
    }
    if (this.activityPanelMaximized) {
      return Math.max(320, Math.round(window.innerWidth - (this.rightPanelLeft + 52) - 16));
    }
    return this.activityPanelWidth;
  }

  get activityPanelHeightPx(): number | null {
    if (this.activityPanelCollapsed || this.activityPanelMaximized) {
      return this.rightPanelComputedHeight;
    }
    return this.activityPanelHeight;
  }

  conversationId = this.createId('conv');
  inFlightRequestId: string | null = null;
  activeRequestSub: Subscription | null = null;
  canRetryRequestId: string | null = null;

  private activeRequests = new Map<
    string,
    {
      request: ChatRequest;
      requestType: 'user_message' | 'emit_event';
      assistantMessageId: string | null;
      userMessageId: string;
      emitEventName?: string;
      /** BW-T6: buddy-workspace record id correlated with this save. */
      recordId?: string;
      /** M5-T4 follow-up: post-save harness authoring hop (already settled). */
      activityAuthoring?: boolean;
    }
  >();

  private lastMessageCount = 0;
  private historyListRequestVersion = 0;

  private dragging = false;
  private startX = 0;
  private startWidth = 380;
  private readonly submittedForms: Record<string, boolean> = {};
  private readonly actedConfirmations: Record<string, boolean> = {};
  private readonly formDraftValues: Record<string, Record<string, unknown>> = {};
  /** M10-T1: intro bubbles never belong in the harness thread history. */
  private readonly introMessageIds = new Set<string>();
  /** M10-T2: cap the harness thread history at the newest N entries
   * (default 20 ≈ 10 pairs); override via env.AGENT_CHAT_HISTORY_MAX. */
  private readonly maxHistoryEntries = Number((environment as any).AGENT_CHAT_HISTORY_MAX) > 0
    ? Number((environment as any).AGENT_CHAT_HISTORY_MAX)
    : 20;
  private readonly activeConversationStorageKey = 'ctng4.agent-chat.activeConversationId';
  private readonly chatStatePort: AgentChatStatePort;
  private readonly chatResponsePort: AgentChatResponsePort;
  private readonly surfacePlugins: AgentChatSurfacePluginPort[];
  private readonly allowedNavigationHrefs = new Set([
    '/home',
    '/fees',
    '/fees/transactions',
    '/fees/transactions/add',
    '/fees/add',
    '/admin/inst',
    '/connect/marksCardRecipients',
  ]);

  /** M4-T2: one rail width shared by the Actions-min rail and the
   * Workspace-max rail. */
  private readonly activityRailWidthPx = 52;

  /** Actions −: collapses Actions only (default column OR maximized state
   * both become the compact rail on Workspace's right edge; Workspace
   * returns to full width — never stays Max). */
  collapseActions(): void {
    this.activityPanelCollapsed = true;
    this.activityPanelMaximized = false;
  }

  /** Back to the default three-column split — the wide headers' restore
   * control; also the way out when both panes sit at rails. */
  restoreDefaultSplit(): void {
    this.workspaceMinimized = false;
    this.workspaceMaximized = false;
    this.activityPanelCollapsed = false;
    this.activityPanelMaximized = false;
  }

  /** Actions ⤢ (expand): Workspace becomes the rail, Actions goes wide. */
  maximizeActions(): void {
    this.workspaceMaximized = false;
    this.activityPanelMaximized = true;
    this.activityPanelCollapsed = false;
  }

  /** M7-T1: Workspace − (full header only) — collapses Workspace ONLY; a
   * visible Actions keeps its own state (collapse it with its own −). */
  collapseWorkspace(): void {
    this.workspaceMaximized = false;
    this.workspaceMinimized = true;
  }

  /** M7-T1: Workspace ⤢ — Actions becomes the rail, Workspace takes the
   * remaining width (mirror of Actions ⤢). */
  maximizeWorkspace(): void {
    this.activityPanelMaximized = false;
    this.workspaceMaximized = true;
    this.workspaceMinimized = false;
    // Never auto-close the Assembler while widening the Workspace; keep both
    // panes available and let the shared width cap reserve room for the
    // visible Assembler panel.
    this.activityPanelCollapsed = false;
  }

  /** M7-T1: Workspace rail click expands Workspace to its default column
   * ONLY. When Actions is wide over this rail, the click restores the
   * default split — the wide pane never yields to a rail (the wide
   * header's restore control also returns both columns). */
  expandWorkspaceFromRail(): void {
    if (this.activityPanelMaximized) {
      this.restoreDefaultSplit();
      return;
    }
    this.workspaceMinimized = false;
  }

  /** M7-T1: Actions rail click — expand Actions ONLY. When Workspace is
   * wide over this rail, the click restores the default split — the wide
   * pane never yields to a rail. */
  expandActionsFromRail(): void {
    if (this.workspaceMaximized) {
      this.restoreDefaultSplit();
      return;
    }
    this.activityPanelCollapsed = false;
  }

  /** M5-T2: toggle the Actions header nine-dots menu. */
  toggleActivityMenu(): void {
    this.activityMenuOpen = !this.activityMenuOpen;
  }

  /** M7-T2: toggle the Workspace header nine-dots menu (full header only). */
  toggleWorkspaceMenu(): void {
    this.workspaceMenuOpen = !this.workspaceMenuOpen;
  }

  /**
   * M7-T2/M8-T2: Workspace ⋮ → Open Actions. Chrome only — when Actions is
   * already visible, close the menu and do nothing (no second pane);
   * otherwise show the existing Actions host (header + nine-dots) with the
   * current in-memory log if any. With an empty in-memory log, restore
   * THIS conversation's stored log first (M8-T2; same token headers) and
   * fall back to the EMPTY list on 404/empty — no demo / fallback row.
   * The pane never auto-opens anywhere else.
   */
  openActionsFromWorkspaceMenu(event: Event): void {
    event.stopPropagation();
    this.workspaceMenuOpen = false;
    if (this.activityPanelVisible || !this.rightPanelVisible) {
      return;
    }
    const cached = this.lastActivityLogSurface;
    if (cached && Array.isArray(cached.items) && cached.items.length) {
      this.assemblerPaneOpen = true;
      this.updateActivityPanelPosition();
      this.mountActivityListComponent();
      return;
    }
    this.assemblerPaneOpen = true;
    this.updateActivityPanelPosition();
    this.mountActivityListComponent();
    // M9-T2: the component only dispatches — the effect owns the GET →
    // SetActivityLog round-trip (404/empty keeps the empty pane).
    this.chatStatePort.loadActivityLog(this.conversationId);
  }

  /**
   * M5-T3: whole-pane overflow catalog — payload-driven. When the incoming
   * activity-log surface carries menuActions (even []), render exactly that;
   * only when the payload omitted the field does the host supply the demo
   * fallback (one "Copy all saved names" item). No host merging on top.
   */
  get activityMenuActions(): ActivityAction[] {
    const surface = this.lastActivityLogSurface;
    if (surface && Array.isArray(surface.menuActions)) {
      return surface.menuActions;
    }
    // M13: the demo menu fallback lives behind the plugin seam.
    return assemblerFallbackMenuActions();
  }

  /** M5-T3: kebab menu click — same executor as per-row actions; menu items
   * carry no row item. The menu closes after the click is handled. */
  onMenuActionClick(event: Event, action: ActivityAction): void {
    event.stopPropagation();
    this.handleActivityAction(null, action);
    this.activityMenuOpen = false;
  }

  /** M5-T2: any click outside the menu/header closes it. */
  @HostListener('document:click')
  closeActivityMenuOnOutsideClick(): void {
    if (this.activityMenuOpen) {
      this.activityMenuOpen = false;
    }
    if (this.workspaceMenuOpen) {
      this.workspaceMenuOpen = false;
    }
  }

  /** M5-T2/T3: copy-all executor — clipboard only; names come from THIS
   * Actions log's saved lines (recordId via the open workspace, else the
   * line's own "Saved <name>." text). No CT API calls. */
  private copyAllSavedNamesFromLog(): void {
    const workspaceInstance = this.rightPanelComponentRef && this.rightPanelComponentRef.instance;
    const workspaceSurface = workspaceInstance && (workspaceInstance as any).surface;
    const records = (workspaceSurface && workspaceSurface.records) || [];
    const names: string[] = [];
    ((this.lastActivityLogSurface && this.lastActivityLogSurface.items) || []).forEach((logged) => {
      if (!logged || logged.kind !== 'success') {
        return;
      }
      const savedId = String(logged.recordId || '').trim();
      const fallbackName = String(logged.text || '')
        .replace(/^Saved\s+/i, '')
        .replace(/[.\s]+$/, '')
        .trim();
      let name = fallbackName;
      if (savedId) {
        const record = records.filter((candidate: any) => candidate && candidate.id === savedId)[0];
        name = (record ? String((record.values || {})['name'] || '').trim() : '') || fallbackName;
      }
      if (name && names.indexOf(name) < 0) {
        names.push(name);
      }
    });
    const clipboard = (navigator as any).clipboard;
    if (names.length && clipboard && typeof clipboard.writeText === 'function') {
      clipboard.writeText(names.join(', ')).catch(() => {
        console.warn('[agent-chat] Copy all saved names failed (clipboard unavailable).');
      });
    }
  }



  constructor(
    private readonly componentFactoryResolver: ComponentFactoryResolver,
    private readonly chatFacade: ChatFacade,
    private readonly chatResponseForwarder: ChatResponseForwarder,
    private readonly router: Router,
    private readonly ctBotHostService: CtBotHostService,
    @Optional() @Inject(AGENT_CHAT_STATE_PORT) chatStatePort: AgentChatStatePort | null,
    @Optional() @Inject(AGENT_CHAT_RESPONSE_PORT) chatResponsePort: AgentChatResponsePort | null,
    @Optional() @Inject(AGENT_CHAT_SURFACE_PLUGINS) surfacePlugins: AgentChatSurfacePluginPort[] | null
  ) {
    // Keep current runtime behavior by default while allowing host-level portability overrides.
    this.chatStatePort = chatStatePort || this.chatFacade as any;
    this.chatResponsePort = chatResponsePort || this.chatResponseForwarder as any;
    this.surfacePlugins = Array.isArray(surfacePlugins) ? surfacePlugins.slice() : [];
  }

  ngOnInit(): void {
    this.messages = [this.createIntroMessage()];
    this.chatStatePort.setMessages(this.messages);
    this.chatStatePort.setConversationId(this.conversationId);
    // keep local messages in sync with store (effect-driven responses will update the store)
    this.chatStatePort.messages$.subscribe((msgs) => {
      if (!msgs) { return; }
      // M9-T2d: compare by REFERENCE, not length — a history restore with
      // the same number of messages (chips added to assistant replies)
      // must still replace the local thread.
      if (msgs !== this.messages) {
        this.messages = msgs.slice();
        this.scrollToBottomSoon();
      }
    });

    // keep conversation list and id in sync with store
    this.chatStatePort.conversationList$.subscribe((list) => {
      if (!Array.isArray(list)) { return; }
      this.chatHistory = list.map((item: any) => ({ id: item.id, title: item.title || 'New chat', updatedAt: item.updatedAt }));
    });
    this.chatStatePort.conversationId$.subscribe((id) => {
      if (!id) {
        return;
      }
      if (id !== this.conversationId) {
        // M9-T2f: the Workspace follows the active conversation — a
        // conversation switch (history restore or New chat) drops the
        // previous thread's surface and closes the panel; the snapshot
        // effect rehydrates it only when the NEW conversation has a
        // buddy/enrol snapshot with content.
        this.closeRightPanel();
        this.chatStatePort.clearSurface();
        this.conversationId = id;
        this.setActiveConversationId(id);
        return;
      }
      // M11-T1c: the SAME conversation id was re-set (history list
      // refresh, re-click, post-turn bookkeeping) — keep the open panel
      // and its surface; only New chat, a DIFFERENT conversation, or an
      // explicit close may clear it.
      this.conversationId = id;
      this.setActiveConversationId(id);
    });
    // M9-T2: the restored enrol Workspace snapshot is fetched by the
    // SET_CONVERSATION_ID effect — the panel only SELECTs the store cache
    // (never auto-opened; fresh-empty reuse stays in the surface handler).
    this.restoredWorkspaceSub = this.chatStatePort.restoredWorkspaceSurface$.subscribe((surface: AgentSurface | null) => {
      this.restoredWorkspaceSurface = surface;
    });

    // subscribe to forwarded transport responses (effects will forward responses here)
    this.chatResponsePort.responses$.subscribe((response) => this.handleResponse(response));
    this.chatResponsePort.transportErrors$.subscribe(({ requestId, details }) => this.handleTransportError(requestId, details));
    this.activeSurfaceSub = this.chatStatePort.activeSurface$.subscribe((surface: AgentSurface | null) => {
      if (!surface) {
        this.closeRightPanel();
        return;
      }

      // M8-T4: a fresh EMPTY enrol/buddy surface reuses the restored
      // snapshot instead of wiping the user's restored Workspace; with no
      // snapshot, today's new-surface behaviour stays.
      const restorable = this.restorableWorkspaceSnapshot(surface);
      if (restorable) {
        // D6.2: re-dispatch the stamped restored snapshot so the panel
        // re-opens the stored workspace (with the saved records) instead
        // of the hollow fresh open.
        this.chatStatePort.openSurface(Object.assign({}, restorable, { conversationId: this.conversationId }));
        return;
      }

      if (this.tryRenderSurface(surface)) {
        return;
      }

      this.closeRightPanel();
    });
    // P0-B2: result pane host; independent of the work-surface lifecycle.
    this.activityLogSub = this.chatStatePort.activityLog$.subscribe((log: any) => {
      this.renderActivityLog(log as ActivityLogSurface | null);
    });
    this.lastNavigationUrl = this.router.url;
    // v1 lifecycle: any route change closes the open surface; surfaces are
    // intentionally not persisted across routes (revisit only if a ticket asks).
    this.routerSub = this.router.events.subscribe((event) => {
      if (!(event instanceof NavigationEnd)) {
        return;
      }
      const nextUrl = event.urlAfterRedirects;
      if (nextUrl === this.lastNavigationUrl) {
        return;
      }
      this.lastNavigationUrl = nextUrl;
      this.closeRightPanel();
      this.chatStatePort.clearActivityLog();
    });
    this.chatStatePort.loadConversations(true);
  }

  startNewChat(): void {
    if (this.inFlightRequestId) {
      this.cancelActiveRequest();
    }

    this.activeRequests.clear();
    this.canRetryRequestId = null;
    this.conversationId = this.createId('conv');
    this.messages = [this.createIntroMessage()];
    this.chatStatePort.setConversationId(this.conversationId);
    this.chatStatePort.setMessages(this.messages);
    this.setActiveConversationId(this.conversationId);
    this.clearInteractiveState();
    this.closeRightPanel();
    this.lastMessageCount = 0;
    this.inputValue = '';
    this.clearSearch();
    this.isHistoryOpen = false;
    this.chatStatePort.clearSurface();
    this.chatStatePort.clearActivityLog();
    // M9-T2f: New chat is LOCAL until the first user prompt — no
    // createConversation / POST /v1/conversations. The first user_message
    // turn upserts the conversation in the harness (title from the first
    // prompt), which is when the row appears in Recent chats; the list
    // refreshes as today after that first persisted turn.
    this.restoreComposerFocus();
  }

  get filteredMessages(): ConversationMessage[] {
    const term = this.searchTerm.trim().toLowerCase();
    if (!term) {
      return this.messages;
    }

    return this.messages.filter((message) => {
      const searchableText = message.blocks
        .map((block) => [block.text, block.markdown, block.message, block.label, block.details].filter(Boolean).join(' '))
        .join(' ')
        .toLowerCase();
      return searchableText.indexOf(term) >= 0;
    });
  }

  toggleSearch(): void {
    this.isSearchOpen = !this.isSearchOpen;
    if (!this.isSearchOpen) {
      this.clearSearch();
      return;
    }

    setTimeout(() => {
      if (this.searchRef) {
        this.searchRef.nativeElement.focus();
      }
    });
  }

  clearSearch(): void {
    this.searchTerm = '';
  }

  toggleHistory(): void {
    this.isHistoryOpen = !this.isHistoryOpen;
    if (this.isHistoryOpen) {
      this.isSearchOpen = false;
      this.clearSearch();
      this.loadConversationList(false);
    }
  }

  getHistoryTitle(item: ChatHistoryItem): string {
    return item.title || 'Untitled chat';
  }

  restoreConversation(item: ChatHistoryItem): void {
    this.restoreConversationById(item.id);
  }

  private restoreConversationById(conversationId: string): void {
    if (this.inFlightRequestId) {
      this.cancelActiveRequest();
    }
    // P0-B2: restored conversations start without a result pane.
    this.chatStatePort.clearActivityLog();
    this.chatStatePort.restoreConversationById(conversationId);
  }

  ngAfterViewChecked(): void {
    if (this.messages.length !== this.lastMessageCount) {
      this.lastMessageCount = this.messages.length;
      this.scrollToBottomSoon();
    }
  }

  get contextLabel(): string {
    const app = String(this.appContext && this.appContext['app'] || 'Application');
    const screen = String(this.appContext && this.appContext['screen'] || 'current-screen');
    return `${app} / ${screen}`;
  }

  get contextTabDetail(): string | null {
    const screen = String(this.appContext && this.appContext['screen'] || 'current-screen');
    if (screen === 'current-screen') {
      return null;
    }

    const tab = this.appContext && this.appContext['tab'];
    return tab ? String(tab) : null;
  }

  get isPending(): boolean {
    return this.inFlightRequestId !== null;
  }

  onComposerKeydown(event: KeyboardEvent): void {
    if (event.key !== 'Enter') {
      return;
    }

    if (event.shiftKey || event.altKey) {
      return;
    }

    if (event.ctrlKey || event.metaKey || (!event.shiftKey && !event.altKey)) {
      event.preventDefault();
      this.send();
    }
  }

  startResize(event: MouseEvent): void {
    this.dragging = true;
    this.startX = event.clientX;
    this.startWidth = this.panelWidth;
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';

    const move = (e: MouseEvent) => {
      if (!this.dragging) {
        return;
      }
      const deltaX = e.clientX - this.startX;
      const nextWidth = this.startWidth + deltaX;
      this.panelWidth = Math.max(300, Math.min(1000, nextWidth));
      this.panelWidthChange.emit(this.panelWidth);
      this.updateRightPanelPosition();
    };

    const up = () => {
      this.dragging = false;
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };

    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  }

  send(): void {
    if (this.inFlightRequestId) {
      return;
    }

    const rawPrompt = this.inputValue;
    const trimmedForValidation = rawPrompt.trim();
    if (!trimmedForValidation) {
      return;
    }

    if (rawPrompt.length > this.charLimit) {
      this.appendSystemMessage([{ type: 'error', message: `Message exceeds ${this.charLimit} characters. Please shorten and try again.` }]);
      return;
    }

    // M11-T1: the derived chip rule hides every visible chip row as soon
    // as the user turn lands (before the Thinking... placeholder).
    // M10-T1: snapshot the eligible thread BEFORE the current prompt is
    // appended — history excludes the message being sent.
    const history = this.buildChatHistory();
    const messageId = this.appendUser(rawPrompt);

    if (this.handleLocalPrompt(rawPrompt, messageId)) {
      this.inputValue = '';
      this.scrollToBottomSoon();
      return;
    }

    const request = this.buildRequest(rawPrompt, messageId, history);
    this.dispatchRequest(request);
    this.inputValue = '';
    this.scrollToBottomSoon();
  }

  cancelActiveRequest(): void {
    if (!this.inFlightRequestId) {
      return;
    }

    const requestId = this.inFlightRequestId;
    if (this.activeRequestSub) {
      this.activeRequestSub.unsubscribe();
    }
    this.activeRequestSub = null;
    this.inFlightRequestId = null;
    this.chatStatePort.cancelRequest(requestId);
    this.chatStatePort.setStatus('idle');
    this.chatStatePort.setActiveRequestId(null);

    const tracked = this.activeRequests.get(requestId);
    if (tracked) {
      if (tracked.assistantMessageId) {
        this.patchMessage(tracked.assistantMessageId, {
          status: 'cancelled',
          blocks: [
            { type: 'status', level: 'info', text: 'Request cancelled.' },
            this.retrySuggestionBlock(requestId),
          ],
        });
      }
      this.canRetryRequestId = requestId;
    }

    this.status.emit('Request cancelled.');
    this.restoreComposerFocus();
  }

  retryLastFailed(): void {
    if (!this.canRetryRequestId || this.inFlightRequestId) {
      return;
    }

    const tracked = this.activeRequests.get(this.canRetryRequestId);
    if (!tracked || tracked.requestType !== 'user_message') {
      return;
    }

    this.dispatchRequest(tracked.request, true);
  }

  runSuggestion(action: ChatSuggestionAction): void {
    if (action.action && action.action.payload && action.action.payload['type'] === 'navigate') {
      return;
    }
    this.runAction(action.action);
  }

  runAction(action: ChatAction): void {
    const payload = action.payload;
    if (!payload || typeof payload !== 'object') {
      return;
    }

    const content = payload as Record<string, unknown>;
    const type = String(content.type || '');
    if (type === 'internal.retry') {
      this.retryLastFailed();
      return;
    }

    if (type === 'internal.prompt') {
      const prompt = String(content.prompt || '');
      if (!prompt || this.inFlightRequestId) {
        return;
      }
      this.inputValue = prompt;
      this.send();
      return;
    }

    if (type === 'navigate') {
      const href = typeof content.href === 'string'
        ? content.href.trim()
        : String(content.route || '').trim();
      if (!this.isAllowlistedInternalHref(href)) {
        console.warn('[agent-chat] Ignoring unsafe navigate action:', href);
        return;
      }
      this.chatStatePort.navigate(this.normalizeInternalHref(href));
      return;
    }

    if (type === 'list_tabs') {
      this.showNavigationTabs();
      return;
    }

    if (type === 'change_state') {
      console.log('[ct-bot-host] change_state is not implemented in Phase 2.', content['patch'] || {});
      return;
    }

    if (type === 'open_help_center') {
      // Insert help suggestions into the chat as prompt suggestions
      const helpItems = [
        {
          id: 'help_1',
          label: 'Institute info',
          action: { id: 'help_prompt_1', label: 'Institute info', payload: { type: 'internal.prompt', prompt: 'Institute info' } },
        },
        {
          id: 'help_2',
          label: 'Take me to fees page',
          action: { id: 'help_prompt_2', label: 'Take me to fees page', payload: { type: 'internal.prompt', prompt: 'Take me to fees page' } },
        },
        {
          id: 'help_3',
          label: 'Collect fees',
          action: { id: 'help_prompt_3', label: 'Collect fees', payload: { type: 'internal.prompt', prompt: 'Collect fees' } },
        },
        {
          id: 'help_4',
          label: 'Send marks cards for FA1',
          action: { id: 'help_prompt_4', label: 'Send marks cards for FA1', payload: { type: 'internal.prompt', prompt: 'Send marks cards for FA1' } },
        },
        {
          id: 'help_5',
          label: 'Add organization',
          action: { id: 'help_prompt_5', label: 'Add organization', payload: { type: 'internal.prompt', prompt: 'add organization' } },
        },
        {
          id: 'help_6',
          label: 'Enroll student',
          action: { id: 'help_prompt_6', label: 'Enroll student', payload: { type: 'internal.prompt', prompt: 'enroll student' } },
        },
      ];

      this.appendAssistant([
        { type: 'text', text: 'Here are some help prompts you can use:' },
        { type: 'suggestions', items: helpItems },
      ]);

      return;
    }

    this.agentEvent.emit(content);
  }

  private handleLocalPrompt(_prompt: string, _userMessageId: string): boolean {
    return false;
  }

  private isOrgAddIntent(prompt: string): boolean {
    const normalized = String(prompt || '').trim().toLowerCase();
    if (!normalized) {
      return false;
    }
    return /(^|\b)(add\s+org|add\s+organization|add\s+organisation)(\b|$)/.test(normalized);
  }

  private isStudentEnrollIntent(prompt: string): boolean {
    const normalized = String(prompt || '').trim().toLowerCase();
    if (!normalized) {
      return false;
    }
    return /(^|\b)(enroll\s+student|enrol\s+student|add\s+student|student\s+enrollment|student\s+enrolment)(\b|$)/.test(normalized);
  }

  private showNavigationTabs(): void {
    const tabs = this.navigationTabs
      .filter((tab) => !!tab && !!tab.name && !!tab.route)
      .map((tab, index) => ({
        id: `navigation_tab_${index}`,
        label: String(tab.name),
        action: {
          id: `navigate_to_${index}`,
          label: String(tab.name),
          payload: { type: 'internal.prompt', prompt: `open ${String(tab.name)}` },
        },
      }));

    this.appendAssistant(
      tabs.length
        ? [{ type: 'text', text: 'Choose a tab to open:' }, { type: 'suggestions', items: tabs }]
        : [{ type: 'text', text: 'No sidebar tabs are available right now.' }]
    );
  }

  isSubmitDisabled(): boolean {
    return this.inFlightRequestId !== null || this.inputValue.trim().length === 0;
  }

  trackByMessage(_: number, item: ConversationMessage): string {
    return item.id;
  }

  isSuggestionHidden(message: ConversationMessage): boolean {
    // M11-T1: chips render only on the LATEST completed transcript
    // assistant message, and only while no newer user/in-flight turn has
    // started. Derived from the current thread — works the same in live
    // replies and after RestoreConversation; user send / in-flight
    // placeholders hide every chip row immediately.
    const visibleId = this.visibleSuggestionMessageId();
    return message.id !== visibleId;
  }

  private visibleSuggestionMessageId(): string | null {
    for (let index = this.messages.length - 1; index >= 0; index--) {
      const candidate = this.messages[index];
      if (candidate.role === 'user') {
        // A newer user turn started — hide all chips until its reply lands.
        return null;
      }
      if (candidate.role === 'assistant') {
        if (String(candidate.status || '') !== 'completed') {
          // In-flight Thinking... placeholder — no chips yet.
          return null;
        }
        // The latest completed transcript assistant reply carries the only
        // visible chips (when it has a suggestions block).
        return this.hasSuggestionItems(candidate) ? candidate.id : null;
      }
      // system rows never affect chip visibility.
    }
    return null;
  }

  private hasSuggestionItems(message: ConversationMessage): boolean {
    return Array.isArray(message.blocks)
      && message.blocks.some((block) => block.type === 'suggestions'
        && Array.isArray((block as any).items)
        && (block as any).items.length > 0);
  }

  trackByBlock(index: number): number {
    return index;
  }

  isFormSubmitted(message: ConversationMessage, blockIndex: number): boolean {
    return this.submittedForms[this.blockKey(message, blockIndex)] === true;
  }

  isConfirmationActed(message: ConversationMessage, blockIndex: number): boolean {
    return this.actedConfirmations[this.blockKey(message, blockIndex)] === true;
  }

  getFormFieldValue(message: ConversationMessage, blockIndex: number, fieldId: string): any {
    const key = this.blockKey(message, blockIndex);
    const draft = this.formDraftValues[key] || {};
    return draft[fieldId];
  }

  setFormFieldValue(message: ConversationMessage, blockIndex: number, fieldId: string, value: any): void {
    const key = this.blockKey(message, blockIndex);
    if (!this.formDraftValues[key]) {
      this.formDraftValues[key] = {};
    }
    this.formDraftValues[key][fieldId] = value;
  }

  submitFormBlock(message: ConversationMessage, block: ChatBlock, blockIndex: number): void {
    const correlationId = String(block.correlationId || '');
    const action = String(block.submitAction || '');
    if (!correlationId || !action || this.inFlightRequestId || this.isFormSubmitted(message, blockIndex)) {
      return;
    }

    const values = this.buildFormValues(message, block, blockIndex);
    const validationError = this.validateFormValues(block, values);
    if (validationError) {
      this.appendSystemMessage([{ type: 'error', message: validationError }]);
      return;
    }

    this.submittedForms[this.blockKey(message, blockIndex)] = true;
    this.dispatchEmitEvent({
      requestId: this.createId('req'),
      messageId: this.createId('msg_event'),
      conversationId: this.conversationId,
      correlationId: correlationId,
      event: 'form_submit',
      action: action,
      values: values,
      context: this.buildHostEventContext()
    });
  }

  confirmBlockAction(message: ConversationMessage, block: ChatBlock, blockIndex: number, confirm: boolean): void {
    const correlationId = String(block.correlationId || '');
    const action = confirm ? String(block.confirmAction || '') : String(block.cancelAction || '');
    if (!correlationId || !action || this.inFlightRequestId || this.isConfirmationActed(message, blockIndex)) {
      return;
    }

    this.actedConfirmations[this.blockKey(message, blockIndex)] = true;
    this.dispatchEmitEvent({
      requestId: this.createId('req'),
      messageId: this.createId('msg_event'),
      conversationId: this.conversationId,
      correlationId: correlationId,
      event: confirm ? 'confirm' : 'cancel',
      action: action,
      values: {},
      context: this.buildHostEventContext()
    });
  }

  getBlockText(block: ChatBlock): string {
    return block.text || '';
  }

  getBlockMarkdown(block: ChatBlock): string {
    return block.markdown || '';
  }

  getBlockMessage(block: ChatBlock): string {
    return block.message || 'Unknown response block.';
  }

  getBlockLabel(block: ChatBlock): string {
    return block.label || 'Open link';
  }

  getBlockHref(block: ChatBlock): string {
    return block.href || '#';
  }

  isLinkDisabled(block: ChatBlock): boolean {
    return !this.hasValidInternalHref(block);
  }

  onLinkClick(block: ChatBlock): void {
    if (!this.hasValidInternalHref(block)) {
      console.warn('[agent-chat] Ignoring malformed internal link block:', block);
      return;
    }
    const href = String(block.href).trim();
    this.chatStatePort.navigate(this.normalizeInternalHref(href));
  }

  @HostListener('window:resize')
  onWindowResize(): void {
    this.updateRightPanelPosition();
  }

  closeRightPanel(): void {
    if (this.rightPanelComponentRef) {
      this.rightPanelComponentRef.destroy();
      this.rightPanelComponentRef = null;
    }
    this.rightPanelVisible = false;
    this.rightPanelTitle = 'Workspace';
    this.chatStatePort.clearSurface();
    // M9-T2b: hiding the pane no longer wipes the store activity log —
    // Workspace ⋮ → Open Actions re-SELECTs the cached log first and only
    // dispatches LoadActivityLog when the store log is empty.
    // M4-T4: hide Actions deterministically (no store round-trip) and reset
    // its chrome state so a re-open is the default three-column split.
    this.resetActivityPane();
  }

  /**
   * M4-T1: close the Actions pane using the same hide path the store-driven
   * activity render uses (destroy the hosted component + hide the pane).
   * No second close stack: the activity log store is untouched, so new
   * activity items simply re-open the pane; server history is never cleared.
   */
  closeActivityPanel(): void {
    // M4-T4: Actions ✕ hides and resets only the Actions pane (Workspace
    // stays open with its current surface). M9-T2b: the store activity log
    // is kept — kebab Open Actions re-SELECTs the cached log first and
    // only dispatches LoadActivityLog when the store log is empty.
    this.resetActivityPane();
  }

  private resetActiveFormSubmitting(): void {
    const instance = this.rightPanelComponentRef && this.rightPanelComponentRef.instance;
    if (!instance) {
      return;
    }
    if (typeof instance.resetSubmitting === 'function') {
      instance.resetSubmitting();
    }
    if (typeof instance.resetParsing === 'function') {
      instance.resetParsing();
    }
    // H-validate: settle the Check hop (right or wrong) so the buttons re-enable.
    if (typeof instance.resetValidating === 'function') {
      instance.resetValidating();
    }
  }

  private tryRenderSurface(surface: AgentSurface): boolean {
    if (!surface || !surface.type) {
      return false;
    }

    const plugin = this.surfacePlugins.find((candidate) => candidate && candidate.type === surface.type);
    if (!plugin) {
      return false;
    }

    this.rightPanelVisible = true;
    this.rightPanelTitle = 'Workspace';
    this.updateRightPanelPosition();

    // The container lives behind *ngIf="rightPanelVisible"; when the surface arrives
    // outside a change-detection turn (e.g. console fixture hook) the view may not be
    // attached yet, so retry briefly instead of giving up silently.
    const attemptRender = (attempt: number) => {
      if (!this.rightPanelVisible) {
        return;
      }

      if (!this.rightPanelContainer) {
        if (attempt < 10) {
          setTimeout(() => attemptRender(attempt + 1), 10);
        } else {
          console.warn('[agent-chat] Surface container did not become available; not rendering:', surface.type);
        }
        return;
      }

      // Same-surface rebind: a parse reply / openSurface payload that echoes
      // the open workspace's id rebinds the instance in place and re-inits,
      // so the returned records[] render as chips. This branch is NEVER a
      // Check echo — buddy_validate turns are patched in handleResponse via
      // mergeValidationEcho and never reach the store/openSurface path.
      if (this.rightPanelComponentRef) {
        const openInstance = this.rightPanelComponentRef.instance;
        const openSurface = openInstance && (openInstance as any).surface;
        const openSurfaceId = openSurface ? String(openSurface.id || '') : '';
        if (openSurface && openSurface.type === surface.type
            && openSurface.id && String(openSurface.id) === String(surface.id)
            && typeof (openInstance as any).initFromSurface === 'function') {
          (openInstance as any).surface = surface;
          (openInstance as any).initFromSurface();
          this.rightPanelComponentRef.changeDetectorRef.detectChanges();
          return;
        }
        this.rightPanelComponentRef.destroy();
      }

      const factory = this.componentFactoryResolver.resolveComponentFactory(plugin.component);
      this.rightPanelComponentRef = this.rightPanelContainer.createComponent(factory);

      if (plugin.bind) {
        plugin.bind(surface, this.rightPanelComponentRef.instance, {
          emitFormSubmit: (activeSurface: AgentSurface, payload: any, defaultAction: string) => {
            this.emitSurfaceFormSubmit(activeSurface, payload, defaultAction);
          },
          // BW-T1: generic surface-event path (buddy_parse / record_selected, ...).
          emitEvent: (activeSurface: AgentSurface, event: string, action: string, values?: Record<string, unknown>) => {
            this.emitSurfaceEvent(activeSurface, event, action, values);
          },
        });
      }

      // Plugin bind runs after component creation; give rebindable surfaces a
      // deterministic init pass, then refresh the detached view.
      const instance = this.rightPanelComponentRef.instance;
      if (instance && typeof instance.initFromSurface === 'function') {
        instance.initFromSurface();
      }
      this.rightPanelComponentRef.changeDetectorRef.detectChanges();

      if (instance && instance.formContinue && instance.formContinue.subscribe) {
        instance.formContinue.subscribe((payload: any) => {
          this.emitSurfaceFormContinue(surface, payload);
        });
      }
    };

    setTimeout(() => attemptRender(0));

    return true;
  }

  private emitSurfaceFormSubmit(surface: AgentSurface, payload: any, defaultAction: string): void {
    if (!payload || this.inFlightRequestId) {
      return;
    }

    this.dispatchEmitEvent({
      requestId: this.createId('req'),
      messageId: this.createId('msg_event'),
      conversationId: this.conversationId,
      correlationId: String(payload.correlationId || surface.id || ''),
      event: 'form_submit',
      action: String(payload.action || defaultAction),
      values: payload.values || {},
      // BW-T6: buddy-workspace submits carry formId + recordId so the save
      // effect keeps the surface open and the outcome correlates with the chip.
      formId: payload.formId ? String(payload.formId) : undefined,
      recordId: payload.recordId ? String(payload.recordId) : undefined,
      context: this.buildHostEventContext(),
    });
  }

  private emitSurfaceEvent(surface: AgentSurface, event: string, action: string, values?: Record<string, unknown>): void {
    if (!event || !action || this.inFlightRequestId) {
      return;
    }

    // M12 follow-up 5: chip select dispatches an UPDATED store surface
    // (new object with activeRecordId set) in the same turn, so the next
    // "what do you see?" names the highlighted chip on the first try.
    if ((event === 'record_selected' || action === 'student.enrol.select')
      && surface
      && String(surface.type || '') === 'buddy-enrol-workspace') {
      const selectedRecordId = String((values || {}).recordId || '').trim();
      const openInstance = this.rightPanelComponentRef && this.rightPanelComponentRef.instance;
      const liveSurface = openInstance ? (openInstance as any).surface : null;
      const selectedSurface = selectRecordSurface(surface, liveSurface, selectedRecordId);
      if (selectedSurface) {
        this.chatStatePort.openSurface(selectedSurface);
      }
    }
    // D6.4-fix: parse hops carry the open workspace fields (ids + order)
    // from the STORE surface — a plain pass-through, no invention.
    const parseFields = (event === 'buddy_parse' || action === 'student.enrol.parse')
      && surface
      && String(surface.type || '') === 'buddy-enrol-workspace'
      && Array.isArray((surface as any).fields)
      ? ((surface as any).fields as Array<any>).map((field: any) => {
        const passed: any = {
          id: String(field.id || ''),
          label: field.label !== undefined ? String(field.label) : undefined,
          type: field.type !== undefined ? String(field.type) : undefined,
          required: field.required === true
        };
        // D6.4 fix: keep the store surface's select options (Gender
        // Female/Male, Course options) on the pass-through.
        if (Array.isArray(field.options) && field.options.length) {
          passed.options = field.options;
        }
        return passed;
      })
      : undefined;

    this.dispatchEmitEvent({
      requestId: this.createId('req'),
      messageId: this.createId('msg_event'),
      conversationId: this.conversationId,
      correlationId: String(surface && surface.id || ''),
      event: event,
      action: action,
      values: values || {},
      fields: parseFields,
      context: this.buildHostEventContext(),
    });
  }

  private emitSurfaceFormContinue(surface: AgentSurface, payload: any): void {
    if (!payload || this.inFlightRequestId) {
      return;
    }

    const surfaceType = String(surface && surface.type || '');
    const defaultAction = surfaceType === 'student-enrol-form'
      ? 'student.enrol.continue'
      : 'org.add.continue';

    this.dispatchEmitEvent({
      requestId: this.createId('req'),
      messageId: this.createId('msg_event'),
      conversationId: this.conversationId,
      correlationId: String(payload.correlationId || surface.id || ''),
      event: 'form_continue',
      action: String(payload.action || defaultAction),
      values: payload.values || {},
      context: this.buildHostEventContext(),
    });
  }

  private updateRightPanelPosition(): void {
    if (!this.rightPanelVisible || !this.panelRoot) {
      return;
    }
    const bounds = this.panelRoot.nativeElement.getBoundingClientRect();
    this.rightPanelLeft = Math.round(bounds.right);
    this.rightPanelTop = Math.round(bounds.top);
    const maxWidth = this.maxWorkspaceWidthPx;
    this.rightPanelComputedWidth = this.workspaceSize
      ? Math.max(240, Math.min(this.workspaceSize.width, maxWidth))
      : Math.max(280, Math.min(420, maxWidth));
    this.rightPanelComputedHeight = this.workspaceSize
      ? Math.max(240, Math.min(this.workspaceSize.height, window.innerHeight - this.rightPanelTop - 8))
      : Math.max(240, Math.round(bounds.height));
    this.updateActivityPanelPosition();
  }

  /**
   * P0-B2 layout: dock the result pane to the RIGHT of the work pane so
   * [chat] [work] [results] read left-to-right; falls back to the chat's right
   * edge when the work pane is closed. Never overlaps `.agent-thread`.
   */
  private updateActivityPanelPosition(): void {
    if (!this.activityPanelVisible || !this.panelRoot) {
      return;
    }
    const bounds = this.panelRoot.nativeElement.getBoundingClientRect();
    const panelRight = Math.round(bounds.right);
    const anchorLeft = this.rightPanelVisible
      ? this.rightPanelLeft + this.rightPanelComputedWidth + 8
      : panelRight;
    this.activityPanelLeft = Math.max(0, anchorLeft);
    this.activityPanelWidth = this.assemblerSize
      ? Math.max(240, Math.min(this.assemblerSize.width, window.innerWidth - this.activityPanelLeft - 8))
      : Math.max(240, Math.min(300, window.innerWidth - this.activityPanelLeft - 8));
    this.activityPanelTop = Math.round(bounds.top);
    this.activityPanelHeight = this.assemblerSize
      ? Math.max(240, Math.min(this.assemblerSize.height, window.innerHeight - this.activityPanelTop - 8))
      : Math.max(240, Math.round(bounds.height));
  }



  /**
   * P0-B2 result pane host; independent of the work-surface lifecycle.
   * M4-T4 lifecycle rules:
   * - a null surface (New chat / route change / any close that clears the
   *   log) hides Actions and resets min/max — a re-open is the default
   *   three-column split, never a leftover rail;
   * - a surface WITH items renders the activity list as today;
   * - a surface with NO items shows one clerk line instead of an empty list
   *   (still gated on Workspace visibility — Actions never mounts alone).
   */
  /** M4-T4: hide Actions and reset its chrome state (min/max/empty flag) and
   * the hosted list — used by every close path and the empty/workspace-hidden
   * branches; never touches the activity store (callers clear it). */
  /** M13: visibility now derives from the store content (activityLog$)
   * and the explicit user open — the flag is render state only. */
  get activityPanelVisible(): boolean {
    return this.assemblerPaneOpen && this.rightPanelVisible;
  }

  private resetActivityPane(): void {
    this.assemblerPaneOpen = false;
    this.activityPanelCollapsed = false;
    this.activityPanelMaximized = false;
    this.workspaceMinimized = false;
    this.workspaceMaximized = false;
    this.activityMenuOpen = false;
    this.workspaceMenuOpen = false;
    if (this.activityLogComponentRef) {
      this.activityLogComponentRef.destroy();
      this.activityLogComponentRef = null;
    }
  }

  /** M8-T3/M9-T2: the surface counts as persisted/restorable when the thin
   * form carries data or the buddy workspace carries records. */
  private surfaceHasSnapshotContent(surface: AgentSurface | null): boolean {
    const type = String(surface && surface.type || '');
    if (type === 'buddy-enrol-workspace') {
      const records = (surface as any).records;
      return Array.isArray(records) && records.length > 0;
    }
    if (type === 'student-enrol-form') {
      return Object.keys((surface as any).data || {}).length > 0;
    }
    return false;
  }

  /**
   * M8-T4: reuse rule — only a FRESH EMPTY enrol/buddy surface is replaced
   * by the restored snapshot (same surface type; the snapshot comes from
   * the SET_CONVERSATION_ID effect via the store cache); a surface with
   * content (a parse reply, an edit) renders as today, and with no
   * snapshot the incoming surface wins. Never auto-opens anything by
   * itself.
   */
  private restorableWorkspaceSnapshot(incoming: AgentSurface | null): AgentSurface | null {
    const restored = this.restoredWorkspaceSurface;
    if (!incoming || !restored) {
      return null;
    }
    // D6.3: the reuse cache is a BUDDY WORKSPACE WITH RECORDS only —
    // student-enrol-form / org-add-form snapshots are never a reuse source.
    if (String(restored.type || '') !== 'buddy-enrol-workspace') {
      return null;
    }
    if (!Array.isArray((restored as any).records) || (restored as any).records.length === 0) {
      return null;
    }
    // M11-T5c fix: a surface with CONTENT — records or a parse summary —
    // is a real parse/save reply and renders as-is; never swap in the
    // restored snapshot for it.
    if (this.surfaceHasSnapshotContent(incoming) || (incoming as any).parse) {
      return null;
    }
    if (String(incoming.type || '') !== String(restored.type || '')) {
      return null;
    }
    // D6.2: the snapshot must belong to THIS conversation — another
    // conversation's buddy never reopens (other conversations stay empty).
    const pinned = String((restored as any).conversationId || '').trim();
    if (pinned && pinned !== this.conversationId) {
      return null;
    }
    // The in-session cache holds the last persisted buddy snapshot
    // (parse + save) — re-dispatching it re-opens the workspace WITH the
    // saved records instead of the hollow fresh open.
    return restored;
  }

  private renderActivityLog(surface: ActivityLogSurface | null): void {
    // M5-T1: cache the current log for next-step actions (Copy names reads
    // this row's record). Never a CT API call.
    // M5-T3: payload items render their own actions; only items missing the
    // field get the demo fallback stamped before caching + rendering.
    this.lastActivityLogSurface = surface ? this.normalizeActivityLogItems(surface) : null;
    // An EMPTY log never opens Actions: items arrive only after a save —
    // no placeholder clerk line, no empty pane (M4-T4 rule, unchanged).
    if (!surface || !Array.isArray(surface.items) || !surface.items.length) {
      this.resetActivityPane();
      return;
    }

    // M4-T2 hierarchy: Actions may render only while the Workspace pane is
    // visible — never mounted alone; closing Workspace hides Actions too
    // (closeRightPanel already clears the activity log, which lands here).
    this.assemblerPaneOpen = this.rightPanelVisible;
    if (!this.activityPanelVisible) {
      this.resetActivityPane();
      return;
    }
    this.updateActivityPanelPosition();

    this.mountActivityListComponent();
  }

  /**
   * M7-T2: mount the activity list host for the currently cached log —
   * shared by renderActivityLog and the Workspace ⋮ open (the latter allows
   * an EMPTY list; the cached surface may be null and the list renders no
   * rows for it). Retries briefly when the emission lands outside a
   * change-detection turn (console fixture hook).
   */
  private mountActivityListComponent(): void {
    if (this.activityLogComponentRef) {
      this.activityLogComponentRef.destroy();
      this.activityLogComponentRef = null;
    }

    const attemptRender = (attempt: number) => {
      if (!this.activityPanelVisible) {
        return;
      }

      if (!this.activityPanelContainer) {
        if (attempt < 10) {
          setTimeout(() => attemptRender(attempt + 1), 10);
        } else {
          console.warn('[agent-chat] Activity log container did not become available; not rendering.');
        }
        return;
      }

      if (this.activityLogComponentRef) {
        this.activityLogComponentRef.destroy();
      }

      // M13: the Assembler mounts through the AGENT_CHAT_SURFACE_PLUGINS
      // registry (same host seam as institute / enrol / buddy) — the
      // hardcoded ActivityLogListComponent factory is gone.
      const assemblerPlugin = this.surfacePlugins.find((candidate) => candidate && candidate.type === 'activity-log');
      if (!assemblerPlugin) {
        console.warn('[agent-chat] No activity-log surface plugin registered; Assembler not rendered.');
        return;
      }
      const factory = this.componentFactoryResolver.resolveComponentFactory(assemblerPlugin.component);
      this.activityLogComponentRef = this.activityPanelContainer.createComponent(factory);
      // M5-T3 follow-up: the list renders the NORMALIZED log (the same
      // surface the kebab getter and the cached next-step actions read) —
      // payload items keep their own actions, omitted ones get the demo
      // fallback stamped exactly once.
      this.activityLogComponentRef.instance.surface = this.lastActivityLogSurface;
      // P0-B4: forward action clicks (focus_record, ...) from result lines.
      if (this.activityLogComponentRef.instance.actionClick && this.activityLogComponentRef.instance.actionClick.subscribe) {
        this.activityLogComponentRef.instance.actionClick.subscribe((payload: { item: ActivityItem; action: ActivityAction }) => {
          this.handleActivityAction(payload && payload.item, payload && payload.action);
        });
      }
      this.activityLogComponentRef.changeDetectorRef.detectChanges();
    };

    setTimeout(() => attemptRender(0));
  }

  getDataItems(block: ChatBlock): Array<{ key: string; value: string }> {
    if (!Array.isArray(block.items)) {
      return [];
    }

    const items: any[] = block.items as any[];
    return items.filter((item: any): item is { key: string; value: string } => {
      if (!item || typeof item !== 'object') {
        return false;
      }

      const candidate = item as Record<string, unknown>;
      return typeof candidate.key === 'string' && typeof candidate.value === 'string';
    });
  }

  getSuggestionItems(block: ChatBlock): ChatSuggestionAction[] {
    if (!Array.isArray(block.items)) {
      return [];
    }

    const items: any[] = block.items as any[];
    return items.filter((item: any): item is ChatSuggestionAction => {
      if (!item || typeof item !== 'object') {
        return false;
      }

      const candidate = item as Record<string, unknown>;
      return typeof candidate.label === 'string' && typeof candidate.id === 'string' && typeof candidate.action === 'object';
    });
  }

  showsDynamicSurfaceHint(action: ChatSuggestionAction): boolean {
    if (!action || !action.action || !action.action.payload) {
      return false;
    }

    const payload = action.action.payload as Record<string, unknown>;
    const type = String(payload.type || '').toLowerCase();
    if (type !== 'internal.prompt') {
      return false;
    }

    const prompt = String(payload.prompt || '').toLowerCase().trim();
    if (!prompt) {
      return false;
    }

    return this.isOrgAddIntent(prompt)
      || this.isStudentEnrollIntent(prompt)
      || /(^|\b)institute\s+info(\b|$)/.test(prompt);
  }

  private dispatchRequest(request: ChatRequest, isRetry = false): void {
    if (this.inFlightRequestId) {
      return;
    }

    const tracked = this.activeRequests.get(request.requestId);
    let assistantMessageId = tracked && tracked.assistantMessageId;
    const userMessageId = tracked && tracked.userMessageId || request.messageId;

    if (!assistantMessageId) {
      assistantMessageId = this.appendAssistant(
        [
          { type: 'status', level: 'loading', text: this.inFlightStatusText },
        ],
        'completed',
        request.requestId,
        request.messageId
      );
    } else {
      this.patchMessage(assistantMessageId, {
        status: 'completed',
        blocks: [
          { type: 'status', level: 'loading', text: this.inFlightStatusText },
        ],
      });
    }

    this.activeRequests.set(request.requestId, { request, requestType: 'user_message', assistantMessageId, userMessageId });
    this.inFlightRequestId = request.requestId;
    this.canRetryRequestId = null;
    this.chatStatePort.sendRequest(request.requestId, request);
    this.chatStatePort.setActiveRequestId(this.inFlightRequestId);
    this.chatStatePort.setStatus('inFlight');
    this.status.emit(isRetry ? 'Retry started.' : 'Message sent.');
    // transport will be performed by effects; activeRequestSub remains null for user_message
  }

  private dispatchEmitEvent(eventRequest: ChatEmitEventRequest): void {
    const isChromeEvent = this.isChromeAckEvent(String(eventRequest.event || ''));

    // Chrome acks (record_selected / field_patched) are host-local UI state:
    // no inFlight/status, no placeholder, no composer lock, so chip clicks
    // never flash "Thinking..." or scroll the thread. Skipped while a real
    // request is in flight (the transport is single-pending anyway); acks and
    // their failures are handled silently in handleResponse/handleTransportError.
    if (isChromeEvent) {
      if (this.inFlightRequestId) {
        return;
      }
      this.trackEmitEvent(eventRequest, null);
      this.chatStatePort.emitEvent(eventRequest);
      return;
    }

    if (this.inFlightRequestId) {
      return;
    }

    const assistantMessageId = this.appendAssistant(
      [
        { type: 'status', level: 'loading', text: this.inFlightStatusText },
      ],
      'completed',
      eventRequest.requestId,
      eventRequest.messageId
    );

    this.trackEmitEvent(eventRequest, assistantMessageId);
    this.inFlightRequestId = eventRequest.requestId;
    this.canRetryRequestId = null;
    this.chatStatePort.sendRequest(eventRequest.requestId, this.trackedRequest(eventRequest));
    this.chatStatePort.setActiveRequestId(this.inFlightRequestId);
    this.chatStatePort.setStatus('inFlight');

    // dispatch emit event to be handled by effects
    this.chatStatePort.emitEvent(eventRequest);
  }

  private trackedRequest(eventRequest: ChatEmitEventRequest): ChatRequest {
    return {
      schemaVersion: '1.0.0',
      requestId: eventRequest.requestId,
      conversationId: eventRequest.conversationId,
      messageId: eventRequest.messageId,
      prompt: '[emit_event:' + eventRequest.event + ']',
      context: this.buildContextSnapshot(),
      client: { appId: 'ct-bot-host' }
    };
  }

  private trackEmitEvent(eventRequest: ChatEmitEventRequest, assistantMessageId: string | null): void {
    this.activeRequests.set(eventRequest.requestId, {
      request: this.trackedRequest(eventRequest),
      requestType: 'emit_event',
      assistantMessageId: assistantMessageId,
      userMessageId: eventRequest.messageId,
      emitEventName: String(eventRequest.event || ''),
      recordId: eventRequest.recordId ? String(eventRequest.recordId) : undefined,
      activityAuthoring: !!eventRequest.activityAuthoring
    });
  }

  /**
   * BW-T6: surface form_submit turns settle through handleResponse /
   * handleTransportError. When the active surface implements the hook (buddy
   * workspace), report the save outcome BEFORE resetSubmitting() so the
   * component marks the chip saved/failed and then continues its queue with
   * the result known. Thin enrol / org-add instances lack the hook — no-op.
   */
  private notifySurfaceSaveOutcome(succeeded: boolean, recordId?: string, activity?: HarnessSaveActivity): void {
    const instance = this.rightPanelComponentRef && this.rightPanelComponentRef.instance;
    if (instance && typeof instance.notifySubmitSettled === 'function') {
      instance.notifySubmitSettled({ succeeded: succeeded, recordId: recordId });
      // M9-T2c: copy the live record fields (saved chips / failed saves /
      // validation flags) onto the store surface BEFORE the persist, so
      // the snapshot carries the saved chips; the persist happens AFTER
      // the settle, never on the emit that starts the save.
      const liveSurface = instance && (instance as any).surface;
      if (liveSurface) {
        const persistedSurface = Object.assign({}, liveSurface);
        persistedSurface.records = typeof instance.withPersistedRecordFlags === 'function'
          ? instance.withPersistedRecordFlags()
          : persistedSurface.records;
        this.chatStatePort.openSurface(persistedSurface);
      }
      // M8-T3/M9-T2: the component only dispatches; the effect owns the PUT
      // (the store surface object now carries the saved-chip flags).
      this.chatStatePort.requestWorkspaceSnapshotPersist();
      if (!succeeded) {
        return;
      }
      // M5-T4 follow-up: buddy saves persist via CTApi XHR only — the mock
      // harness never saw the submit, so its authored catalog never
      // arrived. After a SUCCESSFUL save, emit the existing form_submit
      // event (recordId + name) so the harness authors the Actions line;
      // its response flows through handleResponse →
      // appendActivitySaveOutcome(response.activity). Failed XHR: no emit,
      // no Actions line. Never a second save — the effect skips the
      // persist intercept for this authoring hop.
      this.dispatchSaveActivityAuthoring(recordId);
    }
  }

  /**
   * M5-T4 follow-up: post-save authoring hop to the mock harness, silently
   * (no placeholder, no inFlight lock, no composer lock — the save already
   * settled the chip and its queue). The harness ack carries
   * response.activity; the host demo fallback survives via the silent
   * response/error branches below.
   */
  private dispatchSaveActivityAuthoring(recordId?: string): void {
    const instance = this.rightPanelComponentRef && this.rightPanelComponentRef.instance;
    const surface = instance && (instance as any).surface;
    if (!surface || surface.type !== 'buddy-enrol-workspace') {
      return;
    }
    // M12 follow-up 5: the save-time payload (name / human course label /
    // dob when on the record) rides the authoring emit so the harness
    // stamps the Assembler item fully — never name-only when the course
    // is known.
    const request: ChatEmitEventRequest = {
      requestId: this.createId('req'),
      messageId: this.createId('msg_event'),
      conversationId: this.conversationId,
      correlationId: String(surface.id || ''),
      event: 'form_submit',
      action: String(surface.submitAction || 'student.enrol.submit'),
      values: this.resolveBuddyRecordPayload(recordId) || { name: '' },
      recordId: recordId ? String(recordId) : undefined,
      activityAuthoring: true,
      context: this.buildHostEventContext()
    };
    this.trackEmitEvent(request, null);
    this.chatStatePort.emitEvent(request);
  }

  /**
   * P0-B3: append (never replace) one result line per settled buddy save.
   * Uses the record name from the open buddy workspace when cheap; otherwise
   * the generic "student" wording — never invented ids. Save appends only:
   * parse / record_selected / field_patched / chrome acks stay silent.
   */
  /**
   * M5-T1: Actions is the post-commit accumulator (enroll only) — one clerk
   * line per SAVED student ("Saved Ada Lovelace.") with next-step actions:
   * Focus (kept from P0-B4) plus a harmless "Copy names" stub (clipboard
   * only, no CT API calls). Failed saves stay a Workspace line
   * ("Save failed: <name> — fix the values and retry.") and never appear in
   * Actions. No activity is authored for enroll/Prepare/Check turns, and
   * Actions never opens on an empty log.
   */
  private appendActivitySaveOutcome(succeeded: boolean, recordId?: string, activity?: HarnessSaveActivity): void {
    if (!succeeded) {
      return;
    }
    // M5-T4: the harness (mock harness) is the author for enroll-save
    // activity — when its payload carries the item catalog, render exactly
    // that (actions even [], never merged with host extras); the host demo
    // line below stays only for older turns / omitted catalogs.
    const authoredItem = activity && activity.item;
    if (authoredItem) {
      const authoredKind = authoredItem.kind === 'success' || authoredItem.kind === 'info'
        || authoredItem.kind === 'warning' || authoredItem.kind === 'error'
        ? authoredItem.kind
        : 'success';
      const authoredActivityItem: ActivityItem = {
        id: this.createId('act'),
        kind: authoredKind,
        text: String(authoredItem.text || '').trim() || 'Saved student.',
      };
      const authoredRecordId = String(authoredItem.recordId || recordId || '').trim();
      if (authoredRecordId) {
        authoredActivityItem.recordId = authoredRecordId;
      }
      // M12: the authoring hop's save-time payload (name/course/dob as
      // known at save) rides on the item for draft composition.
      if (authoredItem.payload && typeof authoredItem.payload === 'object') {
        authoredActivityItem.payload = authoredItem.payload;
      }
      if (Array.isArray(authoredItem.actions)) {
        authoredActivityItem.actions = authoredItem.actions;
      } else {
        authoredActivityItem.actions = this.buddyDemoRowActions(authoredActivityItem);
      }
      const menuActions = activity && Array.isArray(activity.menuActions) ? activity.menuActions : undefined;
      this.chatStatePort.appendActivityItem(authoredActivityItem, menuActions, this.conversationId);
      return;
    }
    const name = this.resolveBuddyRecordName(recordId);
    const item: ActivityItem = {
      id: this.createId('act'),
      kind: 'success',
      text: name ? `Saved ${name}.` : 'Saved student.',
    };
    if (recordId) {
      item.recordId = recordId;
    }
    // M12 follow-up 3: EVERY success item carries the save-time payload
    // so the Compose child can draft a notice for every saved row.
    // Prefer the full record payload (name/course/dob) over name-only.
    const fallbackPayload = this.resolveBuddyRecordPayload(recordId);
    if (fallbackPayload) {
      item.payload = fallbackPayload;
    } else if (name) {
      item.payload = { name: name };
    }
    // M5-T3: host-appended save lines never carry payload actions — the
    // demo fallback stamps Focus + Copy names (payload items keep theirs).
    item.actions = this.buddyDemoRowActions(item);
    this.chatStatePort.appendActivityItem(item, undefined, this.conversationId);
  }

  /**
   * M5-T3 demo fallback for the per-row catalog: used ONLY when an incoming
   * payload item omitted `actions` (the field is absent). Focus (kept from
   * P0-B4, only when the line links a record) plus the harmless "Copy names"
   * clipboard stub. Items that carry actions — even [] — render as-is; the
   * host never merges extra buttons on top.
   */
  private buddyDemoRowActions(item: ActivityItem): ActivityAction[] {
    // M13: demo row actions live behind the plugin seam.
    return assemblerFallbackRowActions(item);
  }


  /**
   * M5-T3: normalize a payload-driven log for rendering — items that carry
   * actions render exactly those; items missing the field get the demo
   * fallback stamped (Focus + Copy names).
   */
  private normalizeActivityLogItems(surface: ActivityLogSurface): ActivityLogSurface {
    // M13: the demo row-action defaults moved behind the plugin seam —
    // the panel delegates; used ONLY when the payload omits item actions.
    return normalizeAssemblerSurface(surface) as ActivityLogSurface;
  }

  /** Cheap lookup of the record name from the currently open buddy workspace. */
  private resolveBuddyRecordName(recordId?: string): string | null {
    const instance = this.rightPanelComponentRef && this.rightPanelComponentRef.instance;
    const surface = instance && (instance as any).surface;
    if (!recordId || !surface || !Array.isArray(surface.records)) {
      return null;
    }
    const record = surface.records.find((candidate: any) => candidate && candidate.id === recordId);
    const name = record && record.values ? String(record.values['name'] || '').trim() : '';
    return name || null;
  }

  /**
   * M12 follow-up 5: resolve the record's save-time payload from the open
   * workspace surface — name, course (HUMAN label via record.labels /
   * the current course select options), and dob when those values exist
   * on the record. Never name-only when the course is known. Generic
   * display lookup — no CampusTrack field list beyond what the surface
   * itself carries.
   */
  private resolveBuddyRecordPayload(recordId?: string): Record<string, unknown> | undefined {
    const instance = this.rightPanelComponentRef && this.rightPanelComponentRef.instance;
    const surface = instance && (instance as any).surface;
    if (!recordId || !surface || !Array.isArray(surface.records)) {
      return undefined;
    }
    const record = surface.records.filter((candidate: any) => candidate && candidate.id === recordId)[0];
    if (!record) {
      return undefined;
    }
    const payload: Record<string, unknown> = {};
    const name = record.values ? String(record.values['name'] || '').trim() : '';
    if (name) { payload.name = name; }
    const courseLabel = this.readBuddyCourseLabel(record, surface);
    if (courseLabel) { payload.course = courseLabel; }
    const dob = record.values ? String(record.values['dob'] || '').trim() : '';
    if (dob) { payload.dob = dob; }
    return Object.keys(payload).length ? payload : undefined;
  }

  /**
   * Human course label for a workspace row. Order:
   * labels.courseId (if not a raw id) → option match on values.courseId
   * by value OR label → already-human values.courseId → rejected course text
   * that matches an option / looks human. Never emit a UUID as `course`.
   */
  private readBuddyCourseLabel(record: any, surface: any): string {
    const labeled = record && record.labels && record.labels['courseId']
      ? String(record.labels['courseId']).trim()
      : '';
    if (labeled && !this.looksLikeRawId(labeled)) {
      return labeled;
    }
    const raw = record && record.values ? String(record.values['courseId'] || '').trim() : '';
    const fromOptions = this.matchCourseOptionLabel(raw, surface);
    if (fromOptions) {
      return fromOptions;
    }
    if (raw && !this.looksLikeRawId(raw)) {
      return raw;
    }
    const rejected = record && Array.isArray(record.rejected) ? record.rejected : [];
    for (let i = 0; i < rejected.length; i++) {
      const fieldId = String(rejected[i] && rejected[i].fieldId || '').trim();
      const text = String(rejected[i] && rejected[i].text || '').trim();
      if (fieldId !== 'courseId' || !text) {
        continue;
      }
      const rejectedMatch = this.matchCourseOptionLabel(text, surface);
      if (rejectedMatch) {
        return rejectedMatch;
      }
      if (!this.looksLikeRawId(text)) {
        return text;
      }
    }
    return '';
  }

  private matchCourseOptionLabel(raw: string, surface: any): string {
    const value = String(raw || '').trim();
    if (!value) {
      return '';
    }
    const fields = surface && Array.isArray(surface.fields) ? surface.fields : [];
    const field = fields.filter((candidate: any) => candidate && candidate.id === 'courseId')[0];
    const options = field && Array.isArray(field.options) ? field.options : [];
    const norm = value.toLowerCase();
    for (let i = 0; i < options.length; i++) {
      const option = options[i];
      const optValue = String(option && option.value || '').trim();
      const optLabel = String(option && option.label || '').trim();
      if (optValue === value || optLabel === value
        || optValue.toLowerCase() === norm || optLabel.toLowerCase() === norm) {
        return optLabel || optValue;
      }
    }
    return '';
  }

  private looksLikeRawId(value: string): boolean {
    const text = String(value || '').trim();
    if (!text) {
      return true;
    }
    if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(text)) {
      return true;
    }
    if (/^[0-9a-f]{16,}$/i.test(text)) {
      return true;
    }
    return false;
  }

  /** Every saved workspace row as a draft item — kebab drafts the whole log. */
  private collectAssemblerDraftItems(): Array<Record<string, unknown>> {
    const instance = this.rightPanelComponentRef && this.rightPanelComponentRef.instance;
    const surface = instance && (instance as any).surface;
    if (!surface || !Array.isArray(surface.records)) {
      return [];
    }
    const savedIds = (instance && (instance as any).savedIds) || {};
    const items: Array<Record<string, unknown>> = [];
    surface.records.forEach((record: any) => {
      if (!record || !record.id) {
        return;
      }
      const saved = record.saved === true || !!(savedIds && savedIds[record.id]);
      if (!saved) {
        return;
      }
      const payload = this.resolveBuddyRecordPayload(record.id);
      if (payload) {
        items.push(payload);
      }
    });
    return items;
  }

  /**
   * P0-B4: result-line actions. focus_record selects the record in the open
   * buddy workspace (saved records included) without touching Results or the
   * work pane lifecycle.
   * M5-T3: the catalog is payload-driven (items[].actions + recordId per
   * row; menuActions[] whole-pane). The host executes KNOWN types only —
   * focus_record, copy_names, copy_all_names — and no-ops with a warn for
   * anything else (internal.prompt / navigate included). Menu items pass
   * no row item (null); copy_all_names works from the pane's saved lines.
   */
  private handleActivityAction(item: ActivityItem | null, action: ActivityAction): void {
    if (!action) {
      return;
    }

    // M12: the Assembler menu drafts a parent message — the host only
    // dispatches through the existing emitEvent path (ChatEffects forwards
    // it to the harness, which replies with the model/agent-authored
    // draft). recordId rides along for a row click; the kebab drafts from
    // the whole log.
    if (action.type === 'draft_parent_message') {
      const menuPayload = (action.payload || {}) as Record<string, unknown>;
      const draftRecordId = String(menuPayload.recordId || (item && item.recordId) || '').trim();
      this.dispatchEmitEvent({
        requestId: this.createId('req'),
        messageId: this.createId('msg_event'),
        conversationId: this.conversationId,
        correlationId: String(draftRecordId || ''),
        event: 'draft_parent_message',
        action: 'assembler.draft',
        values: { assemblerItems: this.collectAssemblerDraftItems() },
        recordId: draftRecordId || undefined,
        context: this.buildHostEventContext()
      });
      return;
    }

    // M5-T1 follow-up: Copy names is PER ROW — the button on
    // "Saved Ada Lovelace." copies only Ada Lovelace (from the line's
    // recordId / item text name). Never joins every saved name on the log.
    // Clipboard only; no CT API calls.
    if (action.type === 'copy_names') {
      const savedId = String((item && item.recordId) || '').trim();
      const fallbackName = String((item && item.text) || '')
        .replace(/^Saved\s+/i, '')
        .replace(/[.\s]+$/, '')
        .trim();
      const workspaceInstance = this.rightPanelComponentRef && this.rightPanelComponentRef.instance;
      const workspaceSurface = workspaceInstance && (workspaceInstance as any).surface;
      const records = (workspaceSurface && workspaceSurface.records) || [];
      const record = savedId ? records.filter((candidate: any) => candidate && candidate.id === savedId)[0] : null;
      const name = (record ? String((record.values || {})['name'] || '').trim() : '') || fallbackName;
      const clipboard = (navigator as any).clipboard;
      if (name && clipboard && typeof clipboard.writeText === 'function') {
        clipboard.writeText(name).catch(() => {
          console.warn('[agent-chat] Copy names failed (clipboard unavailable).');
        });
      }
      return;
    }

    // M5-T3: whole-pane copy-all from the overflow menu (or a per-row
    // payload item of the same type).
    if (action.type === 'copy_all_names') {
      this.copyAllSavedNamesFromLog();
      return;
    }

    if (action.type !== 'focus_record') {
      // M5-T3: unknown catalog types (including legacy internal.prompt /
      // navigate) are host no-ops with a warn — never guessed.
      console.warn('[agent-chat] Unsupported activity action:', action.type);
      return;
    }

    const payload = (action.payload || {}) as Record<string, unknown>;
    const recordId = String(payload.recordId || (item && item.recordId) || '');
    const instance = this.rightPanelComponentRef && this.rightPanelComponentRef.instance;
    const surface = instance && (instance as any).surface;
    const hasRecord = !!instance
      && typeof instance.focusRecord === 'function'
      && !!surface
      && surface.type === 'buddy-enrol-workspace'
      && Array.isArray(surface.records)
      && surface.records.some((candidate: any) => candidate && candidate.id === recordId);

    if (!hasRecord) {
      console.warn('[agent-chat] Focus ignored: buddy workspace not open or unknown record:', recordId);
      return;
    }

    instance.focusRecord(recordId);
  }

  private handleResponse(response: ChatResponse): void {
    // capture agent info from response, if present — attach to the assistant message
    let agentInfo: { id?: string; name?: string } | null = null;
    if ((response as any).agent) {
      const agent = (response as any).agent;
      const displayName = agent.name || agent.displayName || null;
      agentInfo = { id: agent.id || undefined, name: displayName || undefined };
      const name = displayName || agent.id || null;
      this.currentAgentDisplay = name ? String(name) : null;
    }
    const requestId = response.requestId;
    const tracked = this.activeRequests.get(requestId);
    if (!tracked) {
      return;
    }

    // Chip-select / field-patch acks: bookkeeping only. They never print,
    // broadcast status, steal focus, or reload history — chip clicks are
    // host-local; the harness still acks via buddy-chrome-canned. A
    // surface-bearing chrome response (future) still renders normally.
    if (tracked.requestType === 'emit_event' && !response.surface
      && this.isChromeAckEvent(tracked.emitEventName)) {
      return;
    }

    // M5-T4 follow-up: the post-save authoring ack — the save already
    // settled chip + queue with the local completed response, so this
    // response only APPENDS the harness-authored activity line (or the
    // host demo fallback when the payload omits the fields). It never
    // prints, never re-settles the chip, and never opens a surface.
    if (tracked.requestType === 'emit_event' && tracked.activityAuthoring) {
      this.appendActivitySaveOutcome(String(response.status || '') === 'completed', tracked.recordId, response.activity);
      return;
    }

    this.activeRequestSub = null;
    this.inFlightRequestId = null;
    const isEmitEventRequest = tracked.requestType === 'emit_event';
    // BW-T6: report the save outcome to the surface (buddy workspace marks its
    // chip) BEFORE re-enabling submit, so the queue continues with the result.
    if (isEmitEventRequest && tracked.emitEventName === 'form_submit') {
      this.notifySurfaceSaveOutcome(String(response.status || '') === 'completed', tracked.recordId, response.activity);
    }
    // Re-enable surface controls (submit/parse) whether the turn succeeded or failed;
    // success paths that clear the surface simply destroy the instance afterwards.
    this.resetActiveFormSubmitting();

    const autoNavigateHref = this.getAutoNavigateHref(response.actions);
    const safeBlocks = this.ensureRenderableBlocks(
      this.filterNavLinkBlocks(response.blocks, autoNavigateHref, tracked.request.prompt)
    );
    const failedBlocks = isEmitEventRequest ? safeBlocks : safeBlocks.concat([this.retrySuggestionBlock(requestId)]);
    if (tracked.assistantMessageId) {
      this.patchMessage(tracked.assistantMessageId, {
        status: response.status,
        blocks: response.status === 'completed' ? safeBlocks : failedBlocks,
        timestamp: new Date().toISOString(),
        agent: agentInfo,
      });
    }

    if (response.status !== 'completed' && !isEmitEventRequest) {
      this.canRetryRequestId = requestId;
    }

    // update facade state
    if (response.status === 'completed') {
      this.chatStatePort.sendSuccess(requestId);
      this.chatStatePort.setStatus('idle');
      this.chatStatePort.setActiveRequestId(null);
    } else {
      this.chatStatePort.sendFailure(requestId, `Response ${response.status}`);
      this.chatStatePort.setStatus('error');
      this.chatStatePort.setActiveRequestId(null);
    }

    this.runAssistantResponseActions(response.actions);

    if (response.contextPatch) {
      this.agentEvent.emit({
        type: 'chat_context_patch',
        patch: response.contextPatch,
        requestId: response.requestId,
      });
    }

    this.setActiveConversationId(this.conversationId);

    // If the assistant response carries a surface payload, publish it to the store
    // Note: do not auto-clear the surface when responses lack a surface. Clearing is left
    // to explicit user actions or future tickets (T7/T8). Here we only set when present.
    // H-validate: a Check turn is a flag patch, NOT a new workspace — never
    // openSurface its echo; patch the live panel's records in place (the
    // echo carries the same surface.id) so buddy text / saved chips / focus
    // survive. Parse and the first workspace open still use openSurface.
    if ((response as any).surface) {
      if (isEmitEventRequest && tracked.emitEventName === 'buddy_validate') {
        const instance = this.rightPanelComponentRef && this.rightPanelComponentRef.instance;
        if (instance && typeof instance.mergeValidationEcho === 'function') {
          instance.mergeValidationEcho((response as any).surface);
        } else {
          this.chatStatePort.openSurface((response as any).surface);
        }
      } else {
        try {
          this.chatStatePort.openSurface((response as any).surface);
        } catch (e) {
          console.warn('[agent-chat] Failed to open surface from response:', e);
        }
      }
    }

    if (response.status === 'completed') {
      this.loadConversationList(false);
    }

    this.status.emit(`Response ${response.status}.`);
    this.restoreComposerFocus();
  }

  private handleTransportError(requestId: string, details: string): void {
    const tracked = this.activeRequests.get(requestId);
    if (!tracked) {
      return;
    }

    // Chip acks fail silently: they are host-local UI state, so no error
    // bubble, status broadcast, or focus steal.
    if (tracked.requestType === 'emit_event' && this.isChromeAckEvent(tracked.emitEventName)) {
      return;
    }

    // M5-T4 follow-up: a failed AUTHORING hop never means a failed save —
    // the XHR already succeeded and the chip/queue settled. Fall back to
    // the host demo line so Actions still records the save.
    if (tracked.requestType === 'emit_event' && tracked.activityAuthoring) {
      this.appendActivitySaveOutcome(true, tracked.recordId);
      return;
    }

    this.activeRequestSub = null;
    this.inFlightRequestId = null;
    // BW-T6: a save that never got a reply counts as failed (surface marks the
    // chip, queue continues) BEFORE re-enabling submit.
    if (tracked.requestType === 'emit_event' && tracked.emitEventName === 'form_submit') {
      this.notifySurfaceSaveOutcome(false, tracked.recordId);
    }
    this.resetActiveFormSubmitting();
    const isEmitEventRequest = tracked.requestType === 'emit_event';
    if (!isEmitEventRequest) {
      this.canRetryRequestId = requestId;
    }

    if (tracked.assistantMessageId) {
      this.patchMessage(tracked.assistantMessageId, {
        status: 'failed',
        blocks: isEmitEventRequest ? [
          {
            type: 'error',
            message: 'Something went wrong while processing that action.',
          }
        ] : [
          {
            type: 'error',
            message: 'Something went wrong while getting a response.',
          },
          this.retrySuggestionBlock(requestId),
        ],
        timestamp: new Date().toISOString(),
      });
    }
    console.warn('[agent-chat] Request failed:', details);

    // update facade state
    this.chatStatePort.sendFailure(requestId, details);
    this.chatStatePort.setStatus('error');
    this.chatStatePort.setActiveRequestId(null);

    this.status.emit(isEmitEventRequest
      ? 'Action failed. Please try again.'
      : 'Something went wrong. You can retry your last message.');
    this.restoreComposerFocus();
  }

  private retrySuggestionBlock(requestId: string): ChatBlock {
    return {
      type: 'suggestions',
      items: [
        {
          id: `retry_${requestId}`,
          label: 'Retry',
          action: { id: `retry_action_${requestId}`, label: 'Retry', payload: { type: 'internal.retry', requestId } },
        },
      ],
    };
  }

  private isChromeAckEvent(eventName?: string): boolean {
    return eventName === 'record_selected' || eventName === 'field_patched';
  }

  private patchMessage(messageId: string, patch: Partial<ConversationMessage>): void {
    const index = this.messages.findIndex((message) => message.id === messageId);
    if (index < 0) {
      return;
    }

    this.messages[index] = {
      ...this.messages[index],
      ...patch,
    };
    this.scrollToBottomSoon();
    this.chatStatePort.setMessages(this.messages);
  }

  private appendUser(text: string): string {
    const id = this.createId('msg_user');
    this.messages.push({
      id,
      role: 'user',
      blocks: [{ type: 'text', text }],
      timestamp: new Date().toISOString(),
      status: 'completed',
    });
    this.scrollToBottomSoon();
    this.chatStatePort.setMessages(this.messages);
    return id;
  }

  private appendAssistant(
    blocks: ChatBlock[],
    status: ChatResponseStatus = 'completed',
    requestId?: string,
    userMessageId?: string
  ): string {
    const id = this.createId('msg_assistant');
    this.messages.push({
      id,
      role: 'assistant',
      blocks,
      timestamp: new Date().toISOString(),
      status,
      requestId,
      userMessageId,
    });
    this.scrollToBottomSoon();
    this.chatStatePort.setMessages(this.messages);
    return id;
  }

  private appendSystemMessage(blocks: ChatBlock[]): void {
    this.messages.push({
      id: this.createId('msg_system'),
      role: 'system',
      blocks,
      timestamp: new Date().toISOString(),
      status: 'completed',
    });
    this.scrollToBottomSoon();
    this.chatStatePort.setMessages(this.messages);
  }

  private loadConversationList(restoreActiveConversation: boolean): void {
    // request effect to load conversations; effect will dispatch SetConversationList
    this.historyListRequestVersion++; // maintain request version semantics for possible future comparisons
    this.chatStatePort.loadConversations(restoreActiveConversation);
  }

  private applyRestoredConversation(conversation: ConversationDetailResponse): void {
    this.activeRequests.clear();
    this.canRetryRequestId = null;
    this.conversationId = conversation.id;
    this.chatStatePort.setConversationId(this.conversationId);
    this.setActiveConversationId(this.conversationId);
    this.messages = this.mapPersistedConversationMessages(conversation.messages);
    if (!this.messages.length) {
      this.messages = [this.createIntroMessage()];
    }
    this.chatStatePort.setMessages(this.messages);
    this.clearInteractiveState();
    this.isHistoryOpen = false;
    this.clearSearch();
    this.lastMessageCount = 0;
    this.scrollToBottomSoon();
  }

  private mapPersistedConversationMessages(messages: PersistedConversationMessage[]): ConversationMessage[] {
    if (!Array.isArray(messages)) {
      return [];
    }
    return messages
      .map((message: PersistedConversationMessage) => this.mapPersistedConversationMessage(message))
      .filter((message: ConversationMessage | null): message is ConversationMessage => message !== null);
  }

  private mapPersistedConversationMessage(message: PersistedConversationMessage): ConversationMessage | null {
    if (!message || typeof message !== 'object') {
      return null;
    }
    if (message.role === 'user') {
      const text = typeof message.text === 'string' ? message.text : '';
      if (!text.trim()) {
        return null;
      }
      return {
        id: message.id || this.createId('msg_user'),
        role: 'user',
        blocks: [{ type: 'text', text }],
        timestamp: message.createdAt || new Date().toISOString(),
        status: 'completed',
        userMessageId: message.userMessageId,
      };
    }
    if (message.role === 'assistant') {
      const assistantPayload = message.assistant || null;
      // M9-T2c: restore suggestions AND links exactly like the live path
      // does — mapStoredAssistantBlocks maps suggestion / link blocks;
      // text-only restore was the regression.
      const msgs = assistantPayload && Array.isArray(assistantPayload.messages) ? assistantPayload.messages : [];
      const blocks = this.ctBotHostService.mapStoredAssistantBlocks(
        msgs,
        assistantPayload ? assistantPayload.correlationId || null : null
      );
      return {
        id: message.id || this.createId('msg_assistant'),
        role: 'assistant',
        blocks: blocks.length ? blocks : [{ type: 'text', text: 'No renderable content was returned.' }],
        timestamp: message.createdAt || new Date().toISOString(),
        status: 'completed',
      };
    }
    return null;
  }

  private createIntroMessage(): ConversationMessage {
    const intro: ConversationMessage = {
      id: this.createId('msg_intro'),
      role: 'assistant',
      blocks: [
        {
          type: 'text',
          text: 'I’m ready to help. Tell me what you need, and I’ll take it from there.',
        },
        {
          type: 'suggestions',
          items: [
            {
              id: 's2',
              label: 'Open help',
              action: { id: 'a2', label: 'Open help', payload: { type: 'open_help_center' } },
            },
          ],
        },
      ],
      timestamp: new Date().toISOString(),
      status: 'completed',
    };
    // M10-T1: the intro bubble never enters the harness thread history.
    this.introMessageIds.add(intro.id);
    return intro;
  }

  private getActiveConversationId(): string {
    try {
      return String(localStorage.getItem(this.activeConversationStorageKey) || '').trim();
    } catch (error) {
      return '';
    }
  }

  private setActiveConversationId(conversationId: string): void {
    const value = String(conversationId || '').trim();
    if (!value) {
      return;
    }
    try {
      localStorage.setItem(this.activeConversationStorageKey, value);
    } catch (error) {
      // ignore storage failures
    }
  }

  private ensureRenderableBlocks(blocks: ChatBlock[]): ChatBlock[] {
    const filtered = blocks.filter((block) => {
      if (this.isKnownBlockType(block.type)) {
        return true;
      }
      console.warn('[ct-bot-host] Skipping unsupported block type:', block.type);
      return false;
    });

    return filtered.length ? filtered : [{ type: 'text', text: 'No renderable content was returned.' }];
  }

  private filterNavLinkBlocks(blocks: ChatBlock[], autoNavigateHref: string, prompt: string): ChatBlock[] {
    return (Array.isArray(blocks) ? blocks : []).filter((block) => {
      if (!block || block.type !== 'link') {
        return true;
      }
      const href = typeof block.href === 'string' ? this.normalizeInternalHref(block.href) : '';
      const target = String(block.target || 'internal').toLowerCase();
      if (target !== 'internal') {
        return true;
      }
      if (href === '/admin/inst') {
        return false;
      }
      if (!autoNavigateHref && this.isUnsupportedNavigationPrompt(prompt)) {
        return false;
      }
      return href !== autoNavigateHref;
    });
  }

  private isUnsupportedNavigationPrompt(prompt: string): boolean {
    const normalized = String(prompt || '').toLowerCase();
    if (!/(take me|go to|open|navigate|bring me|show me)/.test(normalized)) {
      return false;
    }
    return !/(fees?|home|institute|inst|marks?\s*cards?|markscard|connect)/.test(normalized);
  }

  private isKnownBlockType(type: string): boolean {
    return ['text', 'markdown', 'status', 'data', 'suggestions', 'form', 'confirmation', 'link', 'error'].includes(type);
  }

  private hasValidInternalHref(block: ChatBlock): boolean {
    if (String(block.target || 'internal').toLowerCase() !== 'internal') {
      return false;
    }
    const href = typeof block.href === 'string' ? block.href.trim() : '';
    return this.hasValidInternalHrefValue(href);
  }

  private hasValidInternalHrefValue(href: string): boolean {
    return this.isAllowlistedInternalHref(href);
  }

  private isAllowlistedInternalHref(href: string): boolean {
    const normalizedHref = this.normalizeInternalHref(href);
    if (!normalizedHref || normalizedHref.charAt(0) !== '/' || /^https?:\/\//i.test(normalizedHref)) {
      return false;
    }

    return Array.from(this.allowedNavigationHrefs).some((allowedHref) => {
      return normalizedHref === allowedHref
        || normalizedHref.indexOf(allowedHref + '?') === 0
        || normalizedHref.indexOf(allowedHref + '#') === 0;
    });
  }

  private normalizeInternalHref(href: string): string {
    const trimmed = typeof href === 'string' ? href.trim() : '';
    if (!trimmed) {
      return '';
    }

    const queryIndex = trimmed.indexOf('?');
    const hashIndex = trimmed.indexOf('#');
    let cutIndex = -1;
    if (queryIndex >= 0 && hashIndex >= 0) {
      cutIndex = Math.min(queryIndex, hashIndex);
    } else {
      cutIndex = queryIndex >= 0 ? queryIndex : hashIndex;
    }

    const withoutQuery = cutIndex >= 0 ? trimmed.slice(0, cutIndex) : trimmed;
    return withoutQuery.length > 1 ? withoutQuery.replace(/\/+$/, '') : withoutQuery;
  }

  ngOnDestroy(): void {
    if (this.activeSurfaceSub) {
      this.activeSurfaceSub.unsubscribe();
      this.activeSurfaceSub = null;
    }
    if (this.activityLogSub) {
      this.activityLogSub.unsubscribe();
      this.activityLogSub = null;
    }
    if (this.routerSub) {
      this.routerSub.unsubscribe();
      this.routerSub = null;
    }
    if (this.activityLogComponentRef) {
      this.activityLogComponentRef.destroy();
      this.activityLogComponentRef = null;
    }
  }

  private getAutoNavigateHref(actions: ChatAction[] | undefined): string {
    if (!Array.isArray(actions) || !actions.length) {
      return '';
    }

    for (const action of actions) {
      const payload = action && action.payload && typeof action.payload === 'object'
        ? action.payload as Record<string, unknown>
        : null;
      if (!payload || String(payload.type || '') !== 'navigate') {
        continue;
      }

      const href = typeof payload.href === 'string'
        ? payload.href
        : typeof payload.route === 'string'
          ? payload.route
          : '';
      const normalizedHref = this.normalizeInternalHref(href);
      if (this.isAllowlistedInternalHref(normalizedHref)) {
        return normalizedHref;
      }
    }

    return '';
  }

  private runAssistantResponseActions(actions: ChatAction[] | undefined): void {
    if (!Array.isArray(actions) || !actions.length) {
      return;
    }

    let navigated = false;
    for (const action of actions) {
      const payload = action && action.payload && typeof action.payload === 'object'
        ? action.payload as Record<string, unknown>
        : null;
      if (payload && String(payload.type || '') === 'navigate') {
        if (navigated) {
          continue;
        }
        const href = typeof payload.href === 'string'
          ? payload.href.trim()
          : String(payload.route || '').trim();
        if (!this.isAllowlistedInternalHref(href)) {
          console.warn('[agent-chat] Ignoring unsafe response navigate action:', href);
          continue;
        }
        navigated = true;
        this.chatStatePort.navigate(this.normalizeInternalHref(href));
        continue;
      }
      this.runAction(action);
    }
  }


  /**
   * M10-T1/M10-T2: prior-turn history for the harness — the current thread
   * (the same list the UI shows), this conversation only, chronological:
   * - user messages → their text block
   * - assistant messages with status completed → text/markdown blocks only,
   *   trimmed, empties skipped (no suggestion labels, links, forms,
   *   surfaces, errors, in-flight placeholders)
   * - intro bubbles, system/error bubbles and payloads never appear;
   *   never invents turns. Large threads drop the OLDEST eligible turns
   *   first (keep the newest maxHistoryEntries; ~10 pairs), then drop one
   *   extra leading assistant line so the window STARTS on a user line
   *   (a single assistant line is kept).
   */
  private buildChatHistory(): Array<{ role: 'user' | 'assistant'; text: string }> {
    const history: Array<{ role: 'user' | 'assistant'; text: string }> = [];
    (this.messages || []).forEach((message) => {
      if (!message || this.introMessageIds.has(message.id)) {
        return;
      }
      if (message.role === 'user') {
        const text = (message.blocks || [])
          .filter((block: any) => block && block.type === 'text' && typeof block.text === 'string')
          .map((block: any) => block.text.trim())
          .filter((part: string) => !!part)
          .join('\n');
        if (text) {
          history.push({ role: 'user', text: text });
        }
        return;
      }
      if (message.role === 'assistant' && String(message.status || '') === 'completed') {
        const text = (message.blocks || [])
          .filter((block: any) => block && (block.type === 'text' || block.type === 'markdown'))
          .map((block: any) => String((block as any).text !== undefined ? (block as any).text : (block as any).markdown || '').trim())
          .filter((part: string) => !!part)
          .join('\n');
        if (text) {
          history.push({ role: 'assistant', text: text });
        }
      }
    });
    // M10-T2 cap, M11-T2 user-start adjust: keep the newest entries, drop
    // the oldest eligible turns first; then, if the window would START on
    // an assistant line, drop that one extra entry so the window begins on
    // a user line (a single assistant line is kept — never empty the
    // window). Never invents or mixes conversations.
    if (history.length > this.maxHistoryEntries) {
      const window = history.slice(history.length - this.maxHistoryEntries);
      if (window.length > 1 && window[0].role === 'assistant') {
        window.shift();
      }
      return window;
    }
    return history;
  }

  private buildRequest(prompt: string, messageId: string, history: Array<{ role: 'user' | 'assistant'; text: string }>): ChatRequest {
    const appName = String(this.appContext && this.appContext['app'] || 'web-host');
    const normalizedAppId = appName.toLowerCase().replace(/[^a-z0-9_-]+/g, '-').replace(/(^-|-$)/g, '') || 'web-host';

    return {
      schemaVersion: '1.0.0',
      requestId: this.createId('req'),
      conversationId: this.conversationId,
      messageId,
      prompt,
      history: history.length ? history : undefined,
      context: this.buildContextSnapshot(),
      capabilities: [
        'blocks.text',
        'blocks.markdown',
        'blocks.status',
        'blocks.data',
        'blocks.suggestions',
        'blocks.link',
        'blocks.error',
      ],
      client: {
        appId: normalizedAppId,
        appVersion: 'ui-shared-1',
        locale: 'en',
      },
    };
  }

  private buildContextSnapshot(): ChatContext {
    const hostPayload = this.hostContext || this.feeContext;

    return {
      app: this.sanitizeContext(this.appContext),
      host: this.sanitizeContext(hostPayload),
      catalog: {
        itemCount: this.entities.length || this.students.length,
      },
    };
  }

  private buildHostEventContext(): { route?: string; persona?: string } {
    const hostPayload: Record<string, unknown> = this.hostContext || this.feeContext || {};
    const persona = typeof hostPayload['persona'] === 'string' ? String(hostPayload['persona']) : '';
    const routerUrl = this.router && this.router.url ? String(this.router.url) : '';
    return {
      route: routerUrl || '/',
      persona: persona || 'unknown',
    };
  }

  private buildFormValues(message: ConversationMessage, block: ChatBlock, blockIndex: number): Record<string, unknown> {
    const key = this.blockKey(message, blockIndex);
    const draft = this.formDraftValues[key] || {};
    const values: Record<string, unknown> = {};

    (block.fields || []).forEach((field) => {
      const raw = draft[field.id];
      if (field.type === 'number') {
        values[field.id] = raw === undefined || raw === null || raw === '' ? '' : Number(raw);
      } else {
        values[field.id] = raw === undefined || raw === null ? '' : String(raw);
      }
    });

    return values;
  }

  private validateFormValues(block: ChatBlock, values: Record<string, unknown>): string {
    const fields = block.fields || [];
    for (const field of fields) {
      if (!field.required) {
        continue;
      }

      const value = values[field.id];
      if (field.type === 'number') {
        const numeric = Number(value);
        if (!isFinite(numeric) || value === '' || numeric <= 0) {
          return field.label + ' is required.';
        }
      } else if (String(value || '').trim() === '') {
        return field.label + ' is required.';
      }
    }

    return '';
  }

  private blockKey(message: ConversationMessage, blockIndex: number): string {
    return message.id + '__' + String(blockIndex);
  }

  private clearInteractiveState(): void {
    this.clearRecord(this.submittedForms);
    this.clearRecord(this.actedConfirmations);
    this.clearRecord(this.formDraftValues);
  }

  private clearRecord(record: Record<string, any>): void {
    Object.keys(record).forEach((key) => delete record[key]);
  }

  private sanitizeContext(input: Record<string, unknown> | null): Record<string, unknown> {
    if (!input) {
      return {};
    }

    const clone = { ...input };
    const secretLikeKeys = ['password', 'secret', 'token', 'apikey', 'auth'];
    for (const key of Object.keys(clone)) {
      const normalizedKey = key.toLowerCase();
      if (secretLikeKeys.some((entry) => normalizedKey.includes(entry))) {
        delete clone[key];
      }
    }
    return clone;
  }

  private createId(prefix: string): string {
    return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
  }

  private restoreComposerFocus(): void {
    const active = document.activeElement;
    const activeIsMessageArea = active === document.body || (this.messagesRef && active === this.messagesRef.nativeElement);
    if (activeIsMessageArea) {
      if (this.composerRef) {
        this.composerRef.nativeElement.focus();
      }
    }
  }

  private scrollToBottomSoon(): void {
    setTimeout(() => {
      const el = this.messagesRef && this.messagesRef.nativeElement;
      if (el) {
        el.scrollTop = el.scrollHeight;
      }
    });

    requestAnimationFrame(() => {
      const el = this.messagesRef && this.messagesRef.nativeElement;
      if (el) {
        el.scrollTop = el.scrollHeight;
      }
    });
  }
}
