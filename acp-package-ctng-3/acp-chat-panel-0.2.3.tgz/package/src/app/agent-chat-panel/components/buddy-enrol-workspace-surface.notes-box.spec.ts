import { BuddyEnrolWorkspaceSurfaceComponent, buddyNotesTextFromSurface } from './buddy-enrol-workspace-surface.component';

const CLEANED = 'Anita Rao, 01/02/2014, Female, PUC I Commerce A\nRavi K, 03/05/2013, Male, PUC II Science B';
const PASTE = 'anita rao 1/2/14 f puc1\nravi k 3/5/13 m puc2';

describe('buddy workspace notes box on an applied parse surface (M15-T3 follow-up)', function () {
  function makeComponent(): BuddyEnrolWorkspaceSurfaceComponent {
    const component = new BuddyEnrolWorkspaceSurfaceComponent({} as any);
    // Open turn: fresh workspace, empty box.
    component.surface = {
      type: 'buddy-enrol-workspace',
      id: 'surface_buddy_ws',
      buddy: { text: '' },
      records: [],
      activeRecordId: null,
      fields: [{ id: 'name', label: 'Name', type: 'text' }]
    } as any;
    component.initFromSurface();
    // Clerk pastes into the control.
    component.buddyText = PASTE;
    return component;
  }

  it('a same-id parse echo applies its buddy.text — the box shows the cleaned lines', () => {
    const component = makeComponent();
    component.surface = Object.assign({}, component.surface, {
      buddy: { text: CLEANED },
      records: [
        { id: 'b1', values: { name: 'Anita Rao' } },
        { id: 'b2', values: { name: 'Ravi K' } }
      ]
    } as any);
    component.initFromSurface();

    expect(component.buddyText).toBe(CLEANED);
    expect(component.buddyText.indexOf('anita rao 1/2/14')).toBe(-1);
    expect(component.records.length).toBe(2);
  });

  it('a fresh-id parse surface applies its buddy.text too', () => {
    const component = makeComponent();
    component.surface = {
      type: 'buddy-enrol-workspace',
      id: 'surface_parse_2',
      buddy: { text: CLEANED },
      records: [{ id: 'b1', values: { name: 'Anita Rao' } }]
    } as any;
    component.initFromSurface();

    expect(component.buddyText).toBe(CLEANED);
    expect(component.buddyText.indexOf('anita rao 1/2/14')).toBe(-1);
  });

  it('a reply without buddy.text leaves the box as it is (echo and fresh id)', () => {
    const component = makeComponent();
    component.surface = Object.assign({}, component.surface, {
      buddy: undefined,
      records: [{ id: 'b1', values: { name: 'Anita Rao' } }]
    } as any);
    component.initFromSurface();
    expect(component.buddyText).toBe(PASTE);

    const fresh = makeComponent();
    fresh.surface = {
      type: 'buddy-enrol-workspace',
      id: 'surface_parse_3',
      records: [{ id: 'b1', values: { name: 'Ravi K' } }]
    } as any;
    fresh.initFromSurface();
    expect(fresh.buddyText).toBe(PASTE);
  });

  it('writer edge cases: empty-string buddy.text preserves; blank lines do not invent lines', () => {
    expect(buddyNotesTextFromSurface({ buddy: { text: CLEANED } }, PASTE)).toBe(CLEANED);
    expect(buddyNotesTextFromSurface({ buddy: { text: '' } }, PASTE)).toBe(PASTE);
    expect(buddyNotesTextFromSurface({ buddy: { text: '   ' } }, PASTE)).toBe(PASTE);
    expect(buddyNotesTextFromSurface({}, PASTE)).toBe(PASTE);
    expect(buddyNotesTextFromSurface(null as any, PASTE)).toBe(PASTE);
  });
});
