import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild, ViewContainerRef } from '@angular/core';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs/Subscription';

import * as rootReducer from '../../rootReducer';
import { StudentService } from '../../student/service/service';
import { Course } from '../../student/store/reducer';
import {
  StudentEnrolFieldOption,
  StudentEnrolFieldSchema,
} from './student-enrol-field.component';
import { StudentEnrolSurfaceRendererService } from '../services/student-enrol-surface-renderer.service';

interface StudentEnrolSchema {
  fields?: StudentEnrolFieldSchema[];
}

@Component({
  selector: 'app-student-enrol-form-surface',
  template: `
    <div class="student-enrol-surface">
      <div class="student-enrol-surface-head">
        <h3>{{ title || 'Enroll Student' }}</h3>
        <p>Fill in the required details, then submit to save, or continue in the full form.</p>
      </div>

      <div class="student-enrol-form">
        <ng-container #fieldHost></ng-container>
      </div>

      <div class="student-enrol-actions">
        <button type="button" class="student-enrol-save-btn" [disabled]="!canSave()" (click)="onSubmit()">
          {{ submitted ? 'Saving...' : 'Submit' }}
        </button>
        <button type="button" class="student-enrol-continue-btn" [disabled]="submitted" (click)="onContinue()" title="Continue in full form">
          Continue in full form
        </button>
      </div>
    </div>
  `,
  styles: [`` +
    `.student-enrol-surface {
      padding: 18px;
      color: #243447;
      background: #fff;
      font-size: 14px;
    }
    .student-enrol-surface-head {
      margin-bottom: 14px;
    }
    .student-enrol-surface-head h3 {
      margin: 0 0 6px;
      font-size: 20px;
      line-height: 1.2;
    }
    .student-enrol-surface-head p {
      margin: 0;
      color: #5a6b7b;
      font-size: 12px;
      line-height: 1.4;
    }
    .student-enrol-form {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 12px;
    }
    .student-enrol-actions {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      padding-top: 10px;
    }
    .student-enrol-save-btn {
      background: #2f9e44;
      border: 0;
      border-radius: 6px;
      color: #fff;
      font-weight: 600;
      padding: 8px 12px;
      cursor: pointer;
    }
    .student-enrol-save-btn[disabled],
    .student-enrol-continue-btn[disabled] {
      opacity: 0.65;
      cursor: not-allowed;
    }
    .student-enrol-continue-btn {
      background: #fff;
      border: 1px solid #ced8e3;
      border-radius: 6px;
      color: #243447;
      font-weight: 600;
      padding: 8px 12px;
      cursor: pointer;
    }
    @media (max-width: 360px) {
      .student-enrol-form {
        grid-template-columns: 1fr;
      }
    }`],
  providers: [StudentService]
})
export class StudentEnrolFormSurfaceComponent implements OnInit, OnDestroy {
  @ViewChild('fieldHost', { read: ViewContainerRef }) fieldHost: ViewContainerRef | null = null;

  @Input() title: string | null = null;
  @Input() initialValues: Record<string, any> | null = null;
  @Input() schema: StudentEnrolSchema | null = null;
  @Input() formId: string | null = null;
  @Input() submitAction: string | null = null;
  @Input() correlationId: string | null = null;
  @Output() formSubmit = new EventEmitter<{
    formId?: string;
    action: string;
    correlationId: string;
    values: Record<string, any>;
  }>();
  @Output() formContinue = new EventEmitter<{
    formId?: string;
    action: string;
    correlationId: string;
    values: Record<string, any>;
  }>();

  private coursesSub: Subscription | null = null;
  private courseOptions: StudentEnrolFieldOption[] = [];
  private fields: StudentEnrolFieldSchema[] = [];
  draft: Record<string, any> = {};
  submitted = false;

  constructor(
    private readonly service: StudentService,
    private readonly store: Store<rootReducer.State>,
    private readonly renderer: StudentEnrolSurfaceRendererService
  ) {}

  ngOnInit(): void {
    this.fields = this.resolveFields();
    this.draft = this.createInitialDraft(this.fields, this.initialValues || {});
    if (this.needsCourseLookup()) {
      this.service.getCourses();
      this.coursesSub = this.store.select(rootReducer.get_courses_for_students).subscribe((courses: Course[]) => {
        this.courseOptions = this.mapCourseOptions(courses || []);
        this.renderFields();
      });
    }

    setTimeout(() => this.renderFields());
  }

  ngOnDestroy(): void {
    if (this.coursesSub) {
      this.coursesSub.unsubscribe();
      this.coursesSub = null;
    }
    this.renderer.clearAllComponents();
  }

  canSave(): boolean {
    if (this.submitted) {
      return false;
    }
    return this.fields
      .filter((field) => !!field.required)
      .every((field) => !!this.toText(this.draft[field.id]).trim());
  }

  resetSubmitting(): void {
    this.submitted = false;
  }

  onSubmit(): void {
    if (!this.canSave()) {
      return;
    }
    this.submitted = true;
    this.formSubmit.emit(this.buildFormPayload(this.submitAction || 'student.enrol.submit'));
  }

  onContinue(): void {
    if (this.submitted) {
      return;
    }
    this.formContinue.emit(this.buildFormPayload('student.enrol.continue'));
  }

  private buildFormPayload(defaultAction: string): {
    formId?: string;
    action: string;
    correlationId: string;
    values: Record<string, any>;
  } {
    const action = (this.submitAction && String(this.submitAction).trim()) || defaultAction;
    const correlationId = (this.correlationId && String(this.correlationId).trim())
      || (this.formId && String(this.formId).trim())
      || 'student-enrol-thin';
    return {
      formId: this.formId || undefined,
      action: action,
      correlationId: correlationId,
      values: this.collectValues()
    };
  }

  private collectValues(): Record<string, any> {
    const values: Record<string, any> = {};
    this.fields.forEach((field) => {
      values[field.id] = this.toText(this.draft[field.id]);
    });
    return values;
  }

  private renderFields(): void {
    if (!this.fieldHost) {
      return;
    }

    this.renderer.renderFields(
      this.fields,
      this.draft,
      this.fieldHost,
      (field) => this.resolveFieldOptions(field),
      (fieldId, value) => {
        this.draft[fieldId] = value;
      }
    );
  }

  private needsCourseLookup(): boolean {
    return this.fields.some((field) => {
      const isCourseField = field.optionsSource === 'courses'
        || (field.id === 'courseId' && field.type === 'select');
      if (!isCourseField) {
        return false;
      }
      return !(field.options && field.options.length);
    });
  }

  private resolveFields(): StudentEnrolFieldSchema[] {
    if (this.schema && Array.isArray(this.schema.fields) && this.schema.fields.length) {
      return this.schema.fields;
    }

    return [
      { id: 'name', label: 'Name', type: 'text', required: true, maxLength: 50 },
      { id: 'dob', label: 'Date of Birth', type: 'date', required: true },
      { id: 'gender', label: 'Gender', type: 'select', required: true, optionsSource: 'gender' },
      { id: 'courseId', label: 'Course', type: 'select', required: true, optionsSource: 'courses' },
      { id: 'studentId', label: 'Student ID', type: 'text', maxLength: 50 },
      { id: 'doa', label: 'Date of Admission', type: 'date' },
      { id: 'admissionNo', label: 'Admission No', type: 'text', maxLength: 50 },
      { id: 'applicationNo', label: 'Application No', type: 'text', maxLength: 50 },
      { id: 'email', label: 'Email', type: 'email', maxLength: 50 },
      { id: 'mobile', label: 'Mobile', type: 'tel' },
      { id: 'aadharNo', label: 'Aadhar Number', type: 'text', maxLength: 15 },
      { id: 'uDID', label: 'UDID', type: 'text', maxLength: 20 },
      { id: 'fatherName', label: 'Father Name', type: 'text' },
      { id: 'fatherEmail', label: 'Father Email', type: 'email' },
      { id: 'fatherMobile', label: 'Father Mobile', type: 'tel' },
      { id: 'motherName', label: 'Mother Name', type: 'text' },
      { id: 'motherEmail', label: 'Mother Email', type: 'email' },
      { id: 'motherMobile', label: 'Mother Mobile', type: 'tel' },
    ];
  }

  private createInitialDraft(fields: StudentEnrolFieldSchema[], values: Record<string, any>): Record<string, any> {
    const draft: Record<string, any> = {};
    fields.forEach((field) => {
      draft[field.id] = this.toText(values && values[field.id]);
    });
    return draft;
  }

  private resolveFieldOptions(field: StudentEnrolFieldSchema): StudentEnrolFieldOption[] {
    const isGenderField = field.optionsSource === 'gender' || field.id === 'gender';
    if (isGenderField && !(field.options || []).some((option) => !!String(option && option.label || '').trim())) {
      return [
        { label: 'Female', value: 'Female' },
        { label: 'Male', value: 'Male' },
      ];
    }

    if (field.options && field.options.length) {
      return field.options;
    }

    if (isGenderField) {
      return [
        { label: 'Female', value: 'Female' },
        { label: 'Male', value: 'Male' },
      ];
    }

    if (field.optionsSource === 'courses'
      || (field.id === 'courseId' && field.type === 'select')) {
      return this.courseOptions;
    }

    return [];
  }

  private mapCourseOptions(courses: Course[]): StudentEnrolFieldOption[] {
    return courses
      .filter((course) => !!course && !!course.id)
      .map((course) => ({
        label: String(course.fullName || course.name || course.id),
        value: String(course.id)
      }));
  }

  private toText(value: any): string {
    if (value === null || value === undefined) {
      return '';
    }
    return String(value);
  }
}
