import { Component, EventEmitter, Input, Output } from '@angular/core';

export interface OrgAddFieldOption {
  label: string;
  value: string;
}

export interface OrgAddFieldSchema {
  id: string;
  label: string;
  type?: 'text' | 'select';
  required?: boolean;
  maxLength?: number;
  options?: OrgAddFieldOption[];
  optionsSource?: 'firstLevelOrgs' | 'modules';
  helperText?: string;
  placeholder?: string;
}

@Component({
  selector: 'app-org-add-field',
  template: `
    <div class="org-add-field" [class.has-error]="required && !asText(value).trim()">
      <label>{{ field.label }}</label>

      <input *ngIf="isText()"
        type="text"
        [ngModel]="value"
        [ngModelOptions]="{standalone: true}"
        (ngModelChange)="onValueChange($event)"
        [attr.maxlength]="field.maxLength || null"
      />

      <select *ngIf="!isText()"
        [ngModel]="value"
        [ngModelOptions]="{standalone: true}"
        (ngModelChange)="onValueChange($event)"
      >
        <option value="">{{ emptyOptionLabel() }}</option>
        <option *ngFor="let option of options" [ngValue]="option.value">{{ option.label }}</option>
      </select>

      <small *ngIf="field.helperText">{{ field.helperText }}</small>
    </div>
  `,
  styles: [`
    .org-add-field {
      display: grid;
      gap: 4px;
    }
    .org-add-field label {
      color: #5a6b7b;
      font-size: 12px;
      font-weight: 600;
      letter-spacing: .03em;
      text-transform: uppercase;
    }
    .org-add-field input,
    .org-add-field select {
      height: 36px;
      border: 1px solid #ced8e3;
      border-radius: 6px;
      padding: 0 10px;
      background: #fff;
    }
    .org-add-field.has-error input,
    .org-add-field.has-error select {
      border-color: #d9534f;
    }
    .org-add-field small {
      color: #6b7a89;
      font-size: 11px;
    }
  `]
})
export class OrgAddFieldComponent {
  @Input() field: OrgAddFieldSchema;
  @Input() value: any;
  @Input() options: OrgAddFieldOption[] = [];
  @Output() valueChange = new EventEmitter<any>();

  get required(): boolean {
    return !!(this.field && this.field.required);
  }

  isText(): boolean {
    return !this.field || this.field.type !== 'select';
  }

  emptyOptionLabel(): string {
    if (!this.field || this.field.placeholder === undefined || this.field.placeholder === null) {
      return 'Select...';
    }
    return this.field.placeholder;
  }

  onValueChange(value: any): void {
    this.value = value;
    this.valueChange.emit(value);
  }

  asText(value: any): string {
    if (value === null || value === undefined) {
      return '';
    }
    return String(value);
  }
}
