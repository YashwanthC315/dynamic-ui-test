import {
  AfterViewInit,
  Component,
  EventEmitter,
  Input,
  OnDestroy,
  Output,
  ViewChild,
  ViewContainerRef,
} from '@angular/core';

import {
  BuddyEnrolRecord,
  BuddyEnrolRejection,
  BuddyTextSpan,
  BuddyEnrolWorkspaceSurface,
} from '../services/surface-contracts';
import { StudentEnrolFieldOption, StudentEnrolFieldSchema } from './student-enrol-field.component';
import { StudentEnrolSurfaceRendererService } from '../services/student-enrol-surface-renderer.service';

const PAGE_SIZE = 5;

/**
 * BW-T1 buddy workspace panel: renders an agent-produced
 * `buddy-enrol-workspace` surface as JSON. No parsing, no course lookup, no
 * CTApi — buddy text, records, and field options all come from the surface.
 * Search / pager / active-record selection are host-local (no LLM); the Parse
 * button and record clicks surface as outputs for the plugin to forward.
 */
/**
 * M15-T3 follow-up: the function that writes the notes box. After
 * Prepare the box shows the buddy.text on the APPLIED workspace surface
 * (the cleaned lines) — never the paste still sitting in the control;
 * a reply without buddy.text leaves the box as it is. Lines are never
 * invented or rewritten.
 */
export function buddyNotesTextFromSurface(surface: any, preservedBuddyText: string): string {
  const incoming = surface && surface.buddy && typeof surface.buddy === 'object'
    ? String(surface.buddy.text || '')
    : '';
  return incoming.trim() ? incoming : String(preservedBuddyText || '');
}

@Component({
  selector: 'app-buddy-enrol-workspace-surface',
  template: `
    <div class="buddy-ws">
      <div class="buddy-ws-head">
        <h3>{{ surfaceTitleText }}</h3>
        <p>{{ helpText }}</p>
      </div>

      <div class="buddy-ws-buddy">
        <div class="buddy-ws-buddy-head">
          <button type="button" class="buddy-ws-btn" [disabled]="!buddyText.trim()" (click)="onParse()">
            {{ parseInFlight ? 'Thinking...' : prepareButtonLabel }}
          </button>
        </div>
        <textarea
          class="buddy-ws-textarea"
          rows="6"
          spellcheck="false"
          [placeholder]="inputPlaceholderText"
          [(ngModel)]="buddyText"
          [ngModelOptions]="{standalone: true}"
        ></textarea>
      </div>

      <div class="buddy-ws-picker">
        <input
          type="search"
          class="buddy-ws-search"
          placeholder="Search name, dob, course…"
          [(ngModel)]="query"
          [ngModelOptions]="{standalone: true}"
        />
        <div class="buddy-ws-strip">
          <button
            type="button"
            class="buddy-ws-chip"
            *ngFor="let entry of pageRecords; trackBy: trackByRecord"
            [class.active]="entry.record.id === activeRecordId"
            [class.saved]="isRecordSaved(entry.record.id)"
            [disabled]="isRecordSaved(entry.record.id)"
            (click)="selectRecord(entry.record.id)"
          >
            <span class="buddy-ws-chip-idx">{{ entry.index + 1 }}</span>
            <span class="buddy-ws-chip-label">{{ recordLabel(entry.record) }}</span>
            <span class="buddy-ws-chip-saved" *ngIf="isRecordSaved(entry.record.id)">✓ saved</span>
            <span class="buddy-ws-chip-warn" *ngIf="!isRecordSaved(entry.record.id) && !isRecordCheckedValid(entry.record)">⚠</span>
          </button>
          <p class="buddy-ws-empty" *ngIf="!filteredRecords.length">{{ emptyChipStripText }}</p>
        </div>
        <div class="buddy-ws-pager" *ngIf="totalPages > 1">
          <button type="button" [disabled]="page === 0" (click)="goToPage(page - 1)">‹ prev</button>
          <span>Page {{ page + 1 }} of {{ totalPages }} · {{ filteredRecords.length }} of {{ records.length }} students</span>
          <button type="button" [disabled]="page >= totalPages - 1" (click)="goToPage(page + 1)">next ›</button>
        </div>
        <div class="buddy-ws-pager" *ngIf="totalPages === 1 && records.length">
          <span>{{ filteredRecords.length }} of {{ records.length }} students</span>
        </div>
      </div>

      <p class="buddy-ws-bind-note">{{ bindNoteText }}</p>

      <div class="buddy-ws-grid">
        <ng-container #fieldHost></ng-container>
      </div>

      <div class="buddy-ws-status" *ngIf="statusLines.length">
        <div *ngFor="let line of statusLines">{{ line }}</div>
      </div>

      <div class="buddy-ws-actions">
        <button
          type="button"
          class="buddy-ws-btn"
          [disabled]="!records.length || checkInFlight || isSaveBusy() || parseInFlight"
          (click)="onCheck()"
        >
          {{ checkInFlight ? 'Thinking...' : 'Check' }}
        </button>
        <button type="button" class="buddy-ws-save" [disabled]="!canSubmit() || isSaveBusy() || checkInFlight" (click)="onSubmit()">
          {{ submitted || isSaveBusy() ? 'Saving...' : 'Submit active record' }}
        </button>
        <button
          type="button"
          class="buddy-ws-save buddy-ws-save-all"
          [disabled]="!allRecordsCheckedValid || isSaveBusy() || checkInFlight"
          (click)="onSubmitAll()"
        >
          {{ isSaveBusy() ? 'Saving...' : 'Submit all' }}
        </button>
      </div>
    </div>
  `,
  styles: [`
    .buddy-ws { padding: 16px; color: #243447; background: #fff; font-size: 13px; }
    .buddy-ws-head h3 { margin: 0 0 4px; font-size: 19px; line-height: 1.2; }
    .buddy-ws-head p { margin: 0 0 12px; color: #5a6b7b; font-size: 12px; }
    .buddy-ws-buddy { border: 1px solid #ced8e3; border-radius: 8px; padding: 10px 12px; background: #fbfcfe; margin-bottom: 12px; }
    .buddy-ws-buddy-head { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; }
    .buddy-ws-buddy-head strong { font-size: 13px; }
    .buddy-ws-buddy-head .buddy-ws-btn { margin-left: auto; }
    .buddy-ws-btn { border: 1px solid #ced8e3; background: #fff; border-radius: 6px; font-size: 11.5px;
      padding: 4px 10px; cursor: pointer; color: #243447; }
    .buddy-ws-btn:hover { border-color: #3568c4; color: #3568c4; }
    .buddy-ws-btn[disabled] { opacity: 0.55; cursor: not-allowed; }
    .buddy-ws-textarea { width: 100%; resize: vertical; border: 1px solid #ced8e3; border-radius: 6px; padding: 8px 10px;
      font: 12px/1.5 Consolas, Menlo, monospace; color: #243447; background: #fff; }
    .buddy-ws-textarea:focus { outline: none; border-color: #3568c4; }
    .buddy-ws-search { width: 100%; border: 1px solid #ced8e3; border-radius: 6px; padding: 7px 9px; font-size: 13px; margin-bottom: 8px; }
    .buddy-ws-search:focus { outline: none; border-color: #3568c4; }
    .buddy-ws-strip { display: flex; flex-direction: column; gap: 6px; }
    .buddy-ws-chip { display: flex; align-items: center; gap: 8px; width: 100%; text-align: left; border: 1px solid #ced8e3;
      background: #fff; border-radius: 8px; padding: 7px 11px; font-size: 12.5px; cursor: pointer; color: #243447; }
    .buddy-ws-chip:hover { border-color: #3568c4; }
    .buddy-ws-chip.active { background: #1b2a4a; border-color: #1b2a4a; color: #fff; }
    .buddy-ws-chip.saved { opacity: 0.6; cursor: default; }
    .buddy-ws-chip-saved { color: #2f9e44; font-weight: 600; font-size: 11px; }
    .buddy-ws-chip.active .buddy-ws-chip-saved { color: #7fd48f; }
    .buddy-ws-chip-idx { font-weight: 700; opacity: 0.7; min-width: 18px; }
    .buddy-ws-chip-label { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .buddy-ws-chip-warn { color: #a4700f; font-weight: 700; }
    .buddy-ws-chip.active .buddy-ws-chip-warn { color: #ffd479; }
    .buddy-ws-empty { color: #5a6b7b; font-style: italic; font-size: 12px; margin: 4px 2px; }
    .buddy-ws-pager { display: flex; align-items: center; gap: 10px; margin-top: 8px; font-size: 12px; color: #5a6b7b; }
    .buddy-ws-pager button { border: 1px solid #ced8e3; background: #fff; border-radius: 6px; font-size: 12px;
      padding: 4px 10px; cursor: pointer; color: #243447; }
    .buddy-ws-pager button[disabled] { opacity: 0.45; cursor: not-allowed; }
    .buddy-ws-bind-note { color: #5a6b7b; font-size: 11.5px; margin: 12px 0; }
    .buddy-ws-bind-note strong { color: #1b2a4a; }
    .buddy-ws-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px 15px; }
    .buddy-ws-status { margin-top: 12px; font-size: 11.5px; line-height: 1.6; color: #5a6b7b; }
    .buddy-ws-actions { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 14px; }
    .buddy-ws-save { background: #2f9e44; border: 0; border-radius: 6px; color: #fff; font-weight: 600;
      padding: 8px 14px; cursor: pointer; }
    .buddy-ws-save[disabled] { opacity: 0.55; cursor: not-allowed; }
    .buddy-ws-save-all { background: #3568c4; }
    @media (max-width: 360px) { .buddy-ws-grid { grid-template-columns: 1fr; } }
  `]
})
export class BuddyEnrolWorkspaceSurfaceComponent implements AfterViewInit, OnDestroy {
  @ViewChild('fieldHost', { read: ViewContainerRef }) fieldHost: ViewContainerRef | null = null;

  @Input() surface: BuddyEnrolWorkspaceSurface | null = null;

  /**
   * BW-T6: one emit per saved record; the host/plugin forwards each to
   * `emit_event` `form_submit` / `student.enrol.submit` (existing thin-enrol
   * save effect). `recordId` correlates the reply with the chip.
   */
  @Output() formSubmit = new EventEmitter<{
    formId?: string;
    action: string;
    correlationId: string;
    values: Record<string, string>;
    recordId?: string;
  }>();
  /** Plugin forwards to helpers.emitEvent('buddy_parse', 'student.enrol.parse'). */
  @Output() parseRequested = new EventEmitter<{ text: string }>();
  /** Plugin forwards to helpers.emitEvent('record_selected', 'student.enrol.select') when available. */
  @Output() recordSelected = new EventEmitter<{ recordId: string }>();
  /**
   * H-validate: Check runs the validation child hop — payload carries the
   * CURRENT fields[] + records[] (never buddy text); the reply echoes the
   * workspace surface (same surface id) with records[].valid applied, and the
   * submit buttons follow that result. No validation on keystroke.
   */
  @Output() checkRequested = new EventEmitter<{
    fields: StudentEnrolFieldSchema[];
    records: BuddyEnrolRecord[];
    surfaceId: string;
    activeRecordId: string;
    buddyText: string;
    parse: any;
  }>();

  buddyText = '';
  query = '';
  page = 0;
  activeRecordId: string | null = null;
  parseInFlight = false;
  submitted = false;
  /** H-validate: a Check hop is in flight (Check/submit buttons disabled). */
  checkInFlight = false;

  /** BW-T6: chips saved through the existing student-add save path. */
  savedIds: Record<string, boolean> = {};
  /** BW-T6: chips whose save failed — values kept, user fixes and retries. */
  failedSaveIds: Record<string, boolean> = {};

  private fields: StudentEnrolFieldSchema[] = [];
  private lastParseText = '';
  /** BW-T6: pending record ids for Submit all (one in-flight save at a time). */
  private saveQueue: string[] = [];
  private saveQueueActive = false;
  private currentSavingId: string | null = null;
  /** H-validate: surface id this instance is bound to (same-id Check echo rebinds in place). */
  private boundSurfaceId = '';

  constructor(private readonly renderer: StudentEnrolSurfaceRendererService) {}

  /** Clerk-facing copy: payload-driven (surface fields) with clerk-friendly
   * fallbacks when the payload omits a field. */
  get surfaceTitleText(): string {
    return (this.surface && this.surface.title) || 'Enroll students';
  }

  get helpText(): string {
    return (this.surface && this.surface.helpText)
      || 'Paste the list below, then click Prepare. Only the selected student is edited.';
  }

  get inputPlaceholderText(): string {
    return (this.surface && this.surface.inputPlaceholder)
      || 'Name, date of birth, gender, class — one student per line';
  }

  get prepareButtonLabel(): string {
    return (this.surface && this.surface.prepareLabel) || 'Prepare';
  }

  get records(): BuddyEnrolRecord[] {
    return (this.surface && Array.isArray(this.surface.records)) ? this.surface.records : [];
  }

  get activeRecord(): BuddyEnrolRecord | null {
    const id = this.activeRecordId;
    const found = this.records.find((record) => record.id === id);
    return found || this.records[0] || null;
  }

  get filteredRecords(): BuddyEnrolRecord[] {
    const term = this.query.trim().toLowerCase();
    if (!term) {
      return this.records;
    }
    return this.records.filter((record) => {
      const labels = record.labels || {};
      const hay = [
        record.values['name'],
        record.values['dob'],
        record.values['gender'],
        labels['courseId']
      ].map((value) => String(value || '').toLowerCase()).join(' ');
      return hay.indexOf(term) >= 0;
    });
  }

  get totalPages(): number {
    return Math.max(1, Math.ceil(this.filteredRecords.length / PAGE_SIZE));
  }

  get pageRecords(): Array<{ record: BuddyEnrolRecord; index: number }> {
    const filtered = this.filteredRecords;
    const safePage = Math.min(Math.max(this.page, 0), this.totalPages - 1);
    const slice = filtered.slice(safePage * PAGE_SIZE, safePage * PAGE_SIZE + PAGE_SIZE);
    return slice.map((record) => {
      const index = this.records.indexOf(record);
      return { record: record, index: index >= 0 ? index : 0 };
    });
  }

  /** M4-T5 clerk copy: bind note differs when the list is still empty. */
  get bindNoteText(): string {
    return this.records.length
      ? 'Changes apply to the selected student only.'
      : 'Paste the list and click Prepare.';
  }

  /** M4-T5 clerk copy for the chip strip: no rows yet vs no search hits. */
  get emptyChipStripText(): string {
    return this.records.length
      ? 'No match for that search.'
      : 'No students yet.';
  }

  /** M4-T5 clerk wording for one rejection: "Could not use "31/02/2014" as
   * a date." / "... as a class." / "... as a gender." — no Mapped / Rejected /
   * Active-# engineer copy. Field ids come from the payload; nothing invented. */
  private clerkRejectionLine(rejection: BuddyEnrolRejection): string {
    const text = String(rejection.text || '').trim();
    const fieldId = String(rejection.fieldId || '').trim().toLowerCase().replace('courseld', 'courseid');
    const field = this.fields.filter((candidate) => candidate.id.toLowerCase() === fieldId)[0];
    const label = (field ? field.label : '').toLowerCase();
    if (label.indexOf('date') >= 0 || fieldId === 'dob') {
      return 'Could not use “' + text + '” as a date.';
    }
    if (label.indexOf('course') >= 0 || label.indexOf('class') >= 0 || fieldId === 'courseid') {
      return 'Could not use “' + text + '” as a class.';
    }
    if (label.indexOf('gender') >= 0) {
      return 'Could not use “' + text + '” as a gender.';
    }
    return text ? 'Could not use “' + text + '”.' : 'Could not use that value.';
  }

  get statusLines(): string[] {
    const lines: string[] = [];
    const parse = this.surface && this.surface.parse;
    if (parse) {
      (parse.rejected || [])
        .filter((rejection) => !this.rejectionResolvedAfterCheck(rejection))
        .forEach((rejection) => lines.push(this.clerkRejectionLine(rejection)));
      (parse.leftovers || []).forEach((leftover) => lines.push('Skipped: “' + leftover + '”.'));
    }
    const active = this.activeRecord;
    if (active) {
      (active.rejected || [])
        .filter((rejection) => !this.rejectionResolvedAfterCheck(rejection, active))
        .forEach((rejection) => lines.push(this.clerkRejectionLine(rejection)));
      (active.leftovers || []).forEach((leftover) => lines.push('Skipped: “' + leftover + '”.'));
    }
    // BW-T6: save outcome per chip — saved stays saved, failed shows why and
    // keeps values so the user can fix and retry.
    const saved = this.records.filter((record) => this.isRecordSaved(record.id));
    if (saved.length) {
      lines.push('Saved: ' + saved.map((record) => this.recordName(record)).join(', '));
    }
    this.records
      .filter((record) => this.isSaveFailed(record.id))
      .forEach((record) => lines.push('Save failed: ' + this.recordName(record) + ' — fix the values and retry.'));
    return lines;
  }

  ngAfterViewInit(): void {
    this.initFromSurface();
  }

  ngOnDestroy(): void {
    this.renderer.clearAllComponents();
  }

  /**
   * Re-initializes from (new) surface JSON; called on init and when the
   * plugin/panel rebinds. A SAME-ID rebind (a parse reply echoing the open
   * workspace's id) refreshes records/fields in place — the returned
   * records[] render as chips — while PRESERVING the workspace session state
   * (saved/failed chips, save queue, in-flight save, focus); the textarea
   * follows the incoming notes when non-empty, else keeps the preserved
   * text. Check echoes never reach this path (handleResponse patches them
   * via mergeValidationEcho). A genuinely fresh surface id keeps today's
   * full reset.
   */
  initFromSurface(): void {
    const surfaceId = (this.surface && this.surface.id) || '';
    const sameSurface = !!surfaceId && surfaceId === this.boundSurfaceId;
    const preservedBuddyText = this.buddyText;
    const preservedSavedIds = this.savedIds;
    const preservedFailedIds = this.failedSaveIds;
    const preservedQueue = this.saveQueue;
    const preservedQueueActive = this.saveQueueActive;
    const preservedCurrentSaving = this.currentSavingId;
    const preservedSubmitted = this.submitted;
    const preservedLastParseText = this.lastParseText;
    this.boundSurfaceId = surfaceId;
    this.fields = (this.surface && this.surface.fields) || [];
    if (sameSurface) {
      // Same-id rebind: the echo's records/fields win (parse replies must
      // render as chips), while the textarea follows the incoming text —
      // non-empty incoming notes replace the textarea; a missing/empty echo
      // (e.g. a validation echo that omits buddy) keeps the preserved text.
      // Save state (keyed by the stable record ids) is preserved.
      this.buddyText = buddyNotesTextFromSurface(this.surface, preservedBuddyText);
      if (this.surface && this.surface.buddy) {
        (this.surface as any).buddy = { text: this.buddyText };
      }
      this.saveQueue = preservedQueue;
      this.saveQueueActive = preservedQueueActive;
      this.currentSavingId = preservedCurrentSaving;
      this.submitted = preservedSubmitted;
      this.lastParseText = preservedLastParseText;
      // Save state objects stay (keyed by the stable record ids echoed back).
      this.savedIds = preservedSavedIds;
      this.failedSaveIds = preservedFailedIds;
    } else {
      // M15-T3 follow-up: a fresh-id parse surface writes its buddy.text
      // (the cleaned lines); a reply WITHOUT buddy.text leaves the box as
      // it is — never wiped, never invented lines.
      this.buddyText = buddyNotesTextFromSurface(this.surface, preservedBuddyText);
      this.submitted = false;
      this.lastParseText = '';
      // BW-T6: a fresh surface (re-parse) carries new record objects — save
      // state is per-record-id on that surface and restarts with it.
      // M9-T2c: a RESTORED snapshot carries saved/saveFailed flags on the
      // records — seed the chip state from them so saved chips render.
      this.savedIds = {};
      this.failedSaveIds = {};
      (this.records || []).forEach((record) => {
        if (record.saved === true) {
          this.savedIds[record.id] = true;
        }
        if (record.saveFailed === true) {
          this.failedSaveIds[record.id] = true;
        }
      });
      this.saveQueue = [];
      this.saveQueueActive = false;
      this.currentSavingId = null;
    }
    if (sameSurface) {
      // Keep the user's focused row on a same-id echo.
      const focused = this.activeRecordId;
      this.activeRecordId = (focused && this.records.some((record) => record.id === focused))
        ? focused
        : (this.records[0] ? this.records[0].id : null);
    } else {
      const requested = this.surface && this.surface.activeRecordId;
      this.activeRecordId = (requested && this.records.some((record) => record.id === requested))
        ? requested
        : (this.records[0] ? this.records[0].id : null);
    }
    this.stampAllRecordFieldLabels();
    this.renderActiveFields();
  }

  trackByRecord(_: number, entry: { record: BuddyEnrolRecord; index: number }): string {
    return entry.record.id;
  }

  recordName(record: BuddyEnrolRecord): string {
    const name = String(record.values['name'] || '').trim();
    return name || 'record ' + record.id;
  }

  recordLabel(record: BuddyEnrolRecord): string {
    const labels = record.labels || {};
    const course = String(labels['courseId'] || record.values['courseId'] || '').trim();
    return [
      this.recordName(record),
      String(record.values['dob'] || '').trim() || '—',
      course || '—'
    ].join(' | ');
  }

  onParse(): void {
    if (this.parseInFlight || !this.buddyText.trim()) {
      return;
    }
    this.parseInFlight = true;
    this.lastParseText = this.buddyText;
    this.parseRequested.emit({ text: this.buddyText });
  }

  /** Plugin/host calls this when the parse turn settles, right or wrong. */
  resetParsing(): void {
    this.parseInFlight = false;
  }

  goToPage(nextPage: number): void {
    this.page = Math.min(Math.max(nextPage, 0), this.totalPages - 1);
  }

  selectRecord(recordId: string): void {
    if (!recordId || this.activeRecordId === recordId || this.isRecordSaved(recordId)) {
      // BW-T6: a saved record is done — its chip is disabled and stays saved.
      return;
    }
    this.activeRecordId = recordId;
    // M12 follow-up 4: chip selection writes activeRecordId onto the STORE
    // surface in the same turn (the surface object is shared by
    // reference through openSurface), so "what do you see?" names the
    // highlighted chip.
    if (this.surface) {
      (this.surface as any).activeRecordId = recordId;
    }
    this.submitted = false;
    this.renderActiveFields();
    this.recordSelected.emit({ recordId: recordId });
  }

  /**
   * P0-B4: result-pane Focus — select a record from the activity log,
   * including saved ones (their chips are disabled). Host-local only: no
   * record_selected emit, no workspace reload.
   */
  focusRecord(recordId: string): void {
    if (!recordId || !this.records.some((record) => record.id === recordId)) {
      return;
    }
    this.activeRecordId = recordId;
    this.renderActiveFields();
  }

  /**
   * H-validate: the agent's Check result gates submits — the focused row must
   * be checked AND valid from the LAST Check. Before a Check (or after an
   * edit clears the row) nothing submits; changing focus follows that row's
   * last Check flag.
   */
  isRecordCheckedValid(record: BuddyEnrolRecord | null): boolean {
    return !!record && record.validationChecked === true && record.valid === true;
  }

  canSubmit(): boolean {
    const active = this.activeRecord;
    if (!active || this.submitted || this.isSaveBusy() || this.checkInFlight || this.isRecordSaved(active.id)) {
      return false;
    }
    return this.isRecordCheckedValid(active);
  }

  /**
   * BW-T6 / H-validate: per-record safety filter for the save queue. The
   * agent's Check result is the gate (isRecordCheckedValid) — the host never
   * decides valid/invalid from a TypeScript required list.
   */
  canSubmitRecord(record: BuddyEnrolRecord): boolean {
    if (!record || this.isRecordSaved(record.id)) {
      return false;
    }
    return this.isRecordCheckedValid(record);
  }

  isRecordSaved(recordId: string): boolean {
    return !!recordId && !!this.savedIds[recordId];
  }

  isSaveFailed(recordId: string): boolean {
    return !!recordId && !!this.failedSaveIds[recordId];
  }

  /** BW-T6: one in-flight save at a time (single save or Submit all queue). */
  isSaveBusy(): boolean {
    return !!this.currentSavingId;
  }

  /**
   * H-validate: Submit all is enabled only when there is at least one record
   * and EVERY record is checked and valid from the last Check hop.
   */
  get allRecordsCheckedValid(): boolean {
    return this.records.length > 0 && this.records.every((record) => this.isRecordCheckedValid(record));
  }

  /** H-validate: run the validation child hop (no validation on keystroke).
   * The payload is a DEEP COPY of THIS instance's current state — every row's
   * current values/labels/rejected (not only the focused row) plus buddy.text
   * so the harness echo can carry the same notes back. */
  onCheck(): void {
    if (!this.records.length || this.checkInFlight || this.isSaveBusy() || this.parseInFlight) {
      return;
    }
    this.checkInFlight = true;
    this.checkRequested.emit({
      fields: JSON.parse(JSON.stringify(this.fields)),
      records: JSON.parse(JSON.stringify(this.records)),
      surfaceId: (this.surface && this.surface.id) || '',
      activeRecordId: this.activeRecordId || '',
      buddyText: this.buddyText,
      parse: this.surface && this.surface.parse ? JSON.parse(JSON.stringify(this.surface.parse)) : undefined
    });
  }

  /**
   * H-validate: apply a same-id Check echo as a FLAG PATCH — merge only
   * validationChecked / valid / validationReasons onto the matching record
   * ids of the LIVE records array. Never resets buddyText, records, values,
   * labels, savedIds, or focus; never replaces the records array; the
   * textarea keeps its text even when the echo omitted buddy.
   * Fail closed: EVERY live record id gets validationChecked = true after a
   * completed Check — a matching echo row supplies valid/reasons; a row the
   * echo does not mention is marked invalid ("Validation result missing.").
   */
  mergeValidationEcho(echo: any): void {
    const incoming = echo && Array.isArray(echo.records) ? echo.records : [];
    const byId: Record<string, BuddyEnrolRecord> = {};
    incoming.forEach((record: BuddyEnrolRecord) => {
      if (record && record.id) {
        byId[record.id] = record;
      }
    });
    this.records.forEach((record) => {
      const flags = byId[record.id];
      record.validationChecked = true;
      if (flags) {
        record.valid = flags.valid === true;
        record.validationReasons = Array.isArray(flags.validationReasons)
          ? flags.validationReasons
          : undefined;
      } else {
        record.valid = false;
        record.validationReasons = ['Validation result missing.'];
      }
    });
  }

  /** Panel calls this when the Check turn settles, right or wrong. */
  resetValidating(): void {
    this.checkInFlight = false;
  }

  onSubmit(): void {
    const active = this.activeRecord;
    if (!active || !this.canSubmit()) {
      return;
    }
    this.submitted = true;
    this.currentSavingId = active.id;
    this.submitRecord(active);
  }

  /**
   * BW-T6: save every record through the existing student-add save path — the
   * SAME form_submit contract as today's active submit, one emit per record.
   * Only the first emit fires now; the next one fires from resetSubmitting()
   * when the panel settles the previous save (the panel/emit path handles one
   * submit at a time), so N events are never dumped in one tick. The button
   * only enables when every record is checked-and-valid; rows that fail the
   * required-fields safety gate stay unsaved; their chips show why.
   */
  onSubmitAll(): void {
    if (this.isSaveBusy() || this.checkInFlight || !this.allRecordsCheckedValid) {
      return;
    }
    this.saveQueue = this.records
      .filter((record) => this.canSubmitRecord(record))
      .map((record) => record.id);
    if (!this.saveQueue.length) {
      return;
    }
    this.saveQueueActive = true;
    this.submitted = true;
    this.emitNextFromQueue();
  }

  private emitNextFromQueue(): void {
    while (this.saveQueue.length) {
      const id = this.saveQueue.shift() as string;
      const record = this.records.filter((candidate) => candidate.id === id)[0];
      if (!record || this.isRecordSaved(id) || !this.canSubmitRecord(record)) {
        continue;
      }
      this.failedSaveIds[id] = false;
      this.currentSavingId = id;
      this.submitRecord(record);
      return;
    }
    // Queue drained (or nothing left valid): clear in-flight state. Values of
    // failed records were never touched, so the user fixes and retries.
    this.saveQueueActive = false;
    this.currentSavingId = null;
    this.submitted = false;
  }

  /** Same form_submit contract as today's Submit active record — values only, no parse. */
  private submitRecord(record: BuddyEnrolRecord): void {
    const values: Record<string, string> = {};
    Object.keys(record.values).forEach((key) => {
      values[key] = String(record.values[key] || '');
    });
    this.formSubmit.emit({
      formId: (this.surface && this.surface.formId) || undefined,
      action: (this.surface && this.surface.submitAction) || 'student.enrol.submit',
      correlationId: (this.surface && (this.surface.correlationId || this.surface.id)) || 'student-enrol-buddy',
      values: values,
      recordId: record.id
    });
  }

  /**
   * BW-T6: panel calls this when the save turn settles (right or wrong),
   * before resetSubmitting(). Saves run strictly sequentially, so the outcome
   * applies to the in-flight record; recordId, when echoed, must match it.
   * Failed save: clear in-flight (resetSubmitting continues the queue), keep
   * values, show the error — the user fixes and retries.
   */
  notifySubmitSettled(outcome: { succeeded: boolean; recordId?: string }): void {
    const id = this.currentSavingId;
    if (!id || (outcome && outcome.recordId && outcome.recordId !== id)) {
      return;
    }
    if (outcome && outcome.succeeded) {
      this.savedIds[id] = true;
      this.failedSaveIds[id] = false;
    } else {
      this.failedSaveIds[id] = true;
    }
  }

  /**
   * M9-T2c: the saved-chip / failed-save state lives in component maps, so
   * a bare surface copy loses it. For the workspace snapshot, copy the
   * live record fields (saved / saveFailed; validation flags already sit
   * on the records) onto the records so the persisted snapshot and the
   * restored panel show saved chips.
   */
  withPersistedRecordFlags(): BuddyEnrolRecord[] {
    return (this.records || []).map((record) => Object.assign({}, record, {
      saved: this.savedIds[record.id] === true,
      saveFailed: this.failedSaveIds[record.id] === true
    }));
  }

  resetSubmitting(): void {
    this.submitted = false;
    this.currentSavingId = null;
    if (this.saveQueueActive) {
      // Next valid record after the save result — never N events in one tick.
      this.emitNextFromQueue();
    }
  }

  private renderActiveFields(): void {
    if (!this.fieldHost) {
      return;
    }
    const active = this.activeRecord;
    const values: Record<string, string> = active ? active.values : {};
    this.renderer.renderFields(
      this.fields,
      values,
      this.fieldHost,
      (field) => this.resolveFieldOptions(field),
      (fieldId, value) => this.onFieldValue(fieldId, value)
    );
  }

  private onFieldValue(fieldId: string, value: any): void {
    const active = this.activeRecord;
    if (!active) {
      return;
    }
    const nextValue = String(value === null || value === undefined ? '' : value);
    active.values[fieldId] = nextValue;

    // H-validate: an edit invalidates that row's last Check result — the row
    // becomes unchecked (⚠, submits off for it) until the next Check. No
    // validation runs on keystroke.
    active.validationChecked = false;
    active.valid = false;
    active.validationReasons = undefined;

    // BW-T5: keep the display label in sync with the id. `values.courseId`
    // stays the real course id for submit; `labels.courseId` (chip line,
    // search, summary) shows the human name, e.g. "PUC I PCME" — never the
    // UUID.
    // Always stamp the human label when known. A label-shaped value
    // (Grace's unresolved course left as "PUC II PCME A" in values.courseId)
    // used to skip this write because display === nextValue, so
    // labels.courseId stayed empty and Draft parent message dropped her course.
    const display = this.displayValueForField(fieldId, nextValue);
    if (display) {
      if (!active.labels) {
        active.labels = {};
      }
      active.labels[fieldId] = display;
    }

    // Write-back alignment: any field edit on the active record rebuilds that
    // record's line in buddy.text from the CURRENT surface (fields order +
    // current values/labels). No span splicing beside possibly-stale tokens,
    // no sanitize and no parse from this path.
    this.rebuildBuddyLineForRecord(active);
  }

  /**
   * Write-back alignment: rebuild the ACTIVE record's line in buddy.text from
   * the current workspace surface — by LINE, never by a raw span:
   * - buddy.text is split keeping `\n` / `\r\n` separators and only that
   *   record's line characters are replaced, so a span that swallowed a
   *   trailing newline (or reached into the next record) can never glue lines
   *   (`AAlan`) or drop a line break.
   * - The line is chosen from `source.record.start` → line index; when spans
   *   are missing or unusable, the record's index in the surface maps onto
   *   the matching non-blank line.
   * - Column order = `surface.fields` order (no hardcoded field ids and no
   *   hardcoded four-column CSV layout); values = the record's
   *   `values`/`labels` for those field ids (selects show their human label,
   *   e.g. "PUC II PCMB A", not the id); empty value → empty slot, the
   *   commas stay (one slot per field entry).
   * - The record's `source.record` / field spans are refreshed onto the new
   *   line; other records keep their lines byte for byte and only shift
   *   spans that sit after the replaced line (record spans still drive line
   *   selection for later edits).
   * - Rejected/leftover lists are never mutated, and no sanitize, parse, or
   *   LLM call happens here (no ngModelChange on programmatic sync).
   */
  private rebuildBuddyLineForRecord(record: BuddyEnrolRecord): void {
    if (!this.surface || !this.surface.buddy) {
      return;
    }
    const text = this.surface.buddy.text || '';
    if (!text) {
      return;
    }
    const fields = this.fields || [];
    if (!fields.length) {
      return;
    }

    // Split keeping the separators so the rejoin is separator-identical.
    const parts = text.split(/(\r\n|\n|\r)/);
    const lineParts: number[] = [];
    const lineStarts: number[] = [];
    const blankLines: boolean[] = [];
    let offset = 0;
    for (let index = 0; index < parts.length; index += 2) {
      const line = typeof parts[index] === 'string' ? parts[index] : '';
      lineParts.push(index);
      lineStarts.push(offset);
      blankLines.push(!line.trim());
      offset += line.length
        + (typeof parts[index + 1] === 'string' ? (parts[index + 1] as string).length : 0);
    }

    const source = record.source
      || (record.source = { record: { start: 0, end: 0 }, fields: {} });
    let lineIndex = -1;
    if (source.record && source.record.end > source.record.start
        && source.record.start >= 0 && source.record.start <= text.length) {
      for (let index = 0; index < lineParts.length; index++) {
        const candidateStart = lineStarts[index];
        const lineLength = (parts[lineParts[index]] || '').length;
        if (source.record.start >= candidateStart && source.record.start <= candidateStart + lineLength) {
          lineIndex = index;
          break;
        }
      }
      // A span that points at another person's line must never rewrite that
      // line with this record's values: when the record has a name and the
      // chosen line does not contain it, treat the span as wrong and fall
      // back to the record-index mapping below (never a garbled
      // "Male, Grade 6, Alan Turing…" line).
      const expectedName = String((record.values || {})['name'] || '').trim();
      if (lineIndex >= 0 && expectedName
          && ((parts[lineParts[lineIndex]] || '').indexOf(expectedName) < 0)) {
        lineIndex = -1;
      }
    }
    if (lineIndex < 0) {
      // Spans missing or unusable: map this record's index onto its line.
      const recordIndex = (this.surface.records || []).indexOf(record);
      if (recordIndex >= 0) {
        let seen = -1;
        for (let index = 0; index < lineParts.length; index++) {
          if (!blankLines[index]) {
            seen++;
            if (seen === recordIndex) {
              lineIndex = index;
              break;
            }
          }
        }
      }
    }
    if (lineIndex < 0) {
      return;
    }

    const oldLine = parts[lineParts[lineIndex]] || '';
    const lineStart = lineStarts[lineIndex];
    const slots: string[] = [];
    const slotSpans: Record<string, BuddyTextSpan> = {};
    let cursor = lineStart;
    fields.forEach((field, index) => {
      const raw = String(record.values[field.id] || '').trim();
      const display = raw ? this.displayValueForField(field.id, raw) : '';
      if (display) {
        slotSpans[field.id] = { start: cursor, end: cursor + display.length };
      }
      slots.push(display);
      cursor += display.length;
      if (index < fields.length - 1) {
        cursor += 2; // ", "
      }
    });
    const newLine = slots.join(', ');
    parts[lineParts[lineIndex]] = newLine;
    const newText = parts.join('');
    const oldLineEnd = lineStart + oldLine.length;
    const delta = newLine.length - oldLine.length;

    // Other records keep their lines byte for byte; only spans positioned
    // after the replaced line shift by the delta (record spans still drive
    // line selection for later edits).
    (this.surface.records || []).forEach((other) => {
      if (other === record) {
        return;
      }
      const otherSource = other.source;
      if (!otherSource) {
        return;
      }
      const otherRecordSpan = otherSource.record;
      if (otherRecordSpan.start >= oldLineEnd) {
        otherRecordSpan.start += delta;
        otherRecordSpan.end += delta;
      }
      if (otherSource.fields) {
        const otherFields = otherSource.fields;
        Object.keys(otherFields).forEach((key) => {
          const fieldSpan = otherFields[key];
          if (fieldSpan.start >= oldLineEnd) {
            fieldSpan.start += delta;
            fieldSpan.end += delta;
          }
        });
      }
    });

    source.record = { start: lineStart, end: lineStart + newLine.length };
    source.fields = slotSpans;

    this.surface.buddy.text = newText;
    // Programmatic buddyText sync; parsing only runs on an explicit Prepare click.
    this.buddyText = newText;
  }

  /** Select fields patch the notes with their human label (e.g. "Grade 6", not "g6"). */
  private displayValueForField(fieldId: string, value: string): string {
    const raw = String(value || '').trim();
    if (!raw) {
      return '';
    }
    const field = this.fields.filter((candidate) => candidate.id === fieldId)[0];
    if (field && field.options && field.options.length) {
      const norm = raw.toLowerCase();
      const match = field.options.filter((option) => {
        const optValue = String(option.value || '').trim();
        const optLabel = String(option.label || '').trim();
        return optValue === raw || optLabel === raw
          || optValue.toLowerCase() === norm
          || optLabel.toLowerCase() === norm;
      })[0];
      if (match) {
        return String(match.label || match.value || raw).trim() || raw;
      }
    }
    return raw;
  }

  /** After parse / surface apply, every row gets labels.courseId when the
   * course is known as an option id, an option label, or already-human text. */
  private stampAllRecordFieldLabels(): void {
    (this.records || []).forEach((record) => this.stampRecordFieldLabels(record));
  }

  private stampRecordFieldLabels(record: BuddyEnrolRecord): void {
    if (!record || !record.values) {
      return;
    }
    (this.fields || []).forEach((field) => {
      const raw = String(record.values[field.id] || '').trim();
      if (!raw) {
        return;
      }
      const display = this.displayValueForField(field.id, raw);
      if (!display) {
        return;
      }
      if (!record.labels) {
        record.labels = {};
      }
      if (!this.looksLikeRawId(display)) {
        record.labels[field.id] = display;
      } else if (field.id !== 'courseId') {
        record.labels[field.id] = display;
      }
    });
    // Unresolved parse leftover: rejected course text may still match an
    // option by label. Stamp labels.courseId only — do not invent values.courseId.
    if (!String((record.labels && record.labels['courseId']) || '').trim()) {
      const rejected = Array.isArray(record.rejected) ? record.rejected : [];
      for (let i = 0; i < rejected.length; i++) {
        const fieldId = String(rejected[i] && rejected[i].fieldId || '').trim();
        const text = String(rejected[i] && rejected[i].text || '').trim();
        if (fieldId !== 'courseId' || !text) {
          continue;
        }
        const display = this.displayValueForField('courseId', text);
        if (display && !this.looksLikeRawId(display)) {
          if (!record.labels) {
            record.labels = {};
          }
          record.labels['courseId'] = display;
          break;
        }
      }
    }
  }

  private looksLikeRawId(value: string): boolean {
    const text = String(value || '').trim();
    if (!text) {
      return true;
    }
    if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(text)) {
      return true;
    }
    if (/^[0-9a-f]{16,}$/i.test(text)) {
      return true;
    }
    return false;
  }

  private resolveFieldOptions(field: StudentEnrolFieldSchema): StudentEnrolFieldOption[] {
    // Options come from surface JSON only; no store or API lookup in this component.
    return (field.options || []).slice();
  }

  /**
   * H-validate status footer: a parse/record rejection line goes stale once a
   * Check has run and every relevant row's CURRENT value now resolves for
   * that field (same stale-rejected rule as VALIDATE_AGENT.md: non-empty
   * select matching an option by value or label, or a real date). Rejections
   * for still-empty / unresolved / invalid fields (Grace 31/02/2014) stay.
   * Never evaluated before a Check has run on this surface.
   */
  private rejectionResolvedAfterCheck(rejection: BuddyEnrolRejection, record?: BuddyEnrolRecord): boolean {
    if (!this.records.some((candidate) => candidate.validationChecked === true)) {
      return false;
    }
    const fieldId = String(rejection.fieldId || '').trim().toLowerCase();
    const text = String(rejection.text || '').trim();
    if (!fieldId) {
      return false;
    }
    const field = this.fields.filter((candidate) => String(candidate.id).toLowerCase() === fieldId)[0];
    if (!field) {
      return false;
    }
    const rows = record ? [record] : this.records.filter((candidate) => !this.isRecordSaved(candidate.id));
    if (!rows.length) {
      return false;
    }
    const sameRejection = (candidate: BuddyEnrolRecord): boolean =>
      (candidate.rejected || []).some((item) =>
        String(item.fieldId || '').trim().toLowerCase() === fieldId
        && String(item.text || '').trim() === text);
    return rows.every((candidate) => {
      const value = String(candidate.values[field.id] || '').trim();
      if (!value) {
        return !sameRejection(candidate);
      }
      if (field.type === 'select' && Array.isArray(field.options) && field.options.length) {
        return field.options.some((option) =>
          option.value.toLowerCase() === value.toLowerCase() || option.label.toLowerCase() === value.toLowerCase());
      }
      return true;
    });
  }

}
