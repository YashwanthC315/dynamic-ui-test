import { Component, EventEmitter, Input, Output } from '@angular/core';

export interface StudentEnrolFieldOption {
  label: string;
  value: string;
}

export interface StudentEnrolFieldSchema {
  id: string;
  label: string;
  type?: 'text' | 'email' | 'tel' | 'date' | 'select' | 'radio';
  required?: boolean;
  maxLength?: number;
  placeholder?: string;
  helperText?: string;
  options?: StudentEnrolFieldOption[];
  optionsSource?: 'courses' | 'gender';
}

@Component({
  selector: 'app-student-enrol-field',
  template: `
    <div class="student-enrol-field" [class.has-error]="required && !stringValue(value)">
      <label>{{ field.label }}</label>

      <input *ngIf="inputType() === 'date'"
        type="date"
        class="form-control"
        lang="en-GB"
        [ngModel]="isoDateValue()"
        [ngModelOptions]="{standalone: true}"
        (ngModelChange)="onIsoDateChange($event)"
      />

      <input *ngIf="inputType() !== 'select' && inputType() !== 'radio' && inputType() !== 'date'"
        [type]="inputType()"
        class="form-control"
        [placeholder]="field.placeholder || ''"
        [ngModel]="value"
        [ngModelOptions]="{standalone: true}"
        (ngModelChange)="onValueChange($event)"
        [attr.maxlength]="field.maxLength || null"
      />

      <div class="student-enrol-radios" *ngIf="inputType() === 'radio'">
        <label class="student-enrol-radio" *ngFor="let option of options">
          <input
            type="radio"
            [name]="'enrol_' + field.id"
            [checked]="stringValue(value) === option.value"
            (change)="onValueChange(option.value)"
          />
          {{ option.label }}
        </label>
      </div>

      <select *ngIf="inputType() === 'select'"
        class="form-control"
        [ngModel]="value"
        [ngModelOptions]="{standalone: true}"
        (ngModelChange)="onValueChange($event)"
      >
        <option value="">{{ emptyOptionLabel() }}</option>
        <option *ngFor="let option of options" [ngValue]="option.value">{{ option.label }}</option>
      </select>

      <small *ngIf="field.helperText">{{ field.helperText }}</small>
    </div>
  `,
  styles: [`
    .student-enrol-field {
      display: grid;
      gap: 4px;
      min-width: 0;
    }
    .student-enrol-field label {
      color: #333;
      font-size: 14px;
      font-weight: 600;
      letter-spacing: 0;
      text-transform: none;
      margin: 0;
    }
    .student-enrol-field small {
      color: #6b7a89;
      font-size: 11px;
    }
    .student-enrol-field.has-error input,
    .student-enrol-field.has-error select {
      border-color: #d9534f;
    }
    .student-enrol-radios {
      display: flex;
      flex-wrap: wrap;
      gap: 10px 14px;
    }
    .student-enrol-radio {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 13px;
      font-weight: 500;
      letter-spacing: 0;
      text-transform: none;
      color: #243447;
      margin: 0;
    }
  `]
})
export class StudentEnrolFieldComponent {
  @Input() field: StudentEnrolFieldSchema;
  @Input() value: any;
  @Input() options: StudentEnrolFieldOption[] = [];
  @Output() valueChange = new EventEmitter<any>();

  get required(): boolean {
    return !!(this.field && this.field.required);
  }

  inputType(): 'text' | 'email' | 'tel' | 'date' | 'select' | 'radio' {
    if (!this.field || !this.field.type) {
      return 'text';
    }
    return this.field.type;
  }

  isoDateValue(): string {
    const text = this.stringValue(this.value);
    if (!text) {
      return '';
    }
    const iso = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text);
    if (iso) {
      return text;
    }
    const dmy = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(text);
    if (dmy) {
      return dmy[3] + '-' + this.pad2(Number(dmy[2])) + '-' + this.pad2(Number(dmy[1]));
    }
    const parsed = new Date(text);
    if (isNaN(parsed.getTime())) {
      return '';
    }
    return parsed.getFullYear() + '-' + this.pad2(parsed.getMonth() + 1) + '-' + this.pad2(parsed.getDate());
  }

  onIsoDateChange(value: any): void {
    const iso = this.stringValue(value);
    if (!iso) {
      this.onValueChange('');
      return;
    }
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
    if (!match) {
      this.onValueChange(iso);
      return;
    }
    this.onValueChange(match[3] + '/' + match[2] + '/' + match[1]);
  }

  emptyOptionLabel(): string {
    if (!this.field || this.field.placeholder === undefined || this.field.placeholder === null) {
      return 'Select...';
    }
    return this.field.placeholder;
  }

  onValueChange(value: any): void {
    this.value = value;
    this.valueChange.emit(value);
  }

  private pad2(value: number): string {
    return (value < 10 ? '0' : '') + String(value);
  }

  stringValue(value: any): string {
    if (value === null || value === undefined) {
      return '';
    }
    return String(value).trim();
  }
}
