import { AfterViewInit, Component, Input, OnChanges, OnDestroy, SimpleChanges, ViewChild, ViewContainerRef } from '@angular/core';

import { InstituteFieldViewModel, InstituteSurfaceRendererService } from '../services/institute-surface-renderer.service';

interface InstituteSummaryFieldSchema {
  id: string;
  label: string;
  path?: string;
  type?: 'text' | 'link' | 'address' | 'academicYear' | 'status';
  wide?: boolean;
}

interface InstituteSummarySchema {
  titlePath?: string;
  subtitlePath?: string;
  fields?: InstituteSummaryFieldSchema[];
}

@Component({
  selector: 'app-institute-panel',
  template: `
    <div class="institute-panel">
      <div class="institute-panel-title">
        <h3>{{ panelTitle }}</h3>
        <span class="institute-short-name" *ngIf="panelSubtitle">{{ panelSubtitle }}</span>
      </div>

      <div class="institute-summary-grid">
        <ng-container #fieldHost></ng-container>
      </div>
    </div>
  `,
  styles: [`
    .institute-panel {
      padding: 18px;
      color: #243447;
      background: #fff;
      font-size: 14px;
    }
    .institute-panel-title {
      margin-bottom: 18px;
      padding-bottom: 12px;
      border-bottom: 1px solid #e6ebf0;
    }
    h3 {
      margin: 0 0 4px;
      font-size: 20px;
      line-height: 1.25;
    }
    .institute-short-name {
      color: #64748b;
      font-size: 13px;
    }
    .institute-summary-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 14px 16px;
    }
    .institute-field {
      min-width: 0;
    }
    .institute-field-wide {
      grid-column: 1 / -1;
    }
    .institute-label {
      display: block;
      margin-bottom: 3px;
      color: #64748b;
      font-size: 11px;
      font-weight: 600;
      letter-spacing: .04em;
      text-transform: uppercase;
    }
    .institute-value {
      display: block;
      overflow-wrap: anywhere;
      line-height: 1.4;
    }
    a.institute-value {
      color: #1565c0;
      text-decoration: none;
    }
    a.institute-value:hover {
      text-decoration: underline;
    }
    @media (max-width: 360px) {
      .institute-summary-grid {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class InstitutePanelComponent implements AfterViewInit, OnChanges, OnDestroy {
  @ViewChild('fieldHost', { read: ViewContainerRef }) fieldHost: ViewContainerRef | null = null;

  @Input() data: any;
  @Input() schema: InstituteSummarySchema | null = null;

  panelTitle = 'Institute overview';
  panelSubtitle = '';

  constructor(private readonly instituteSurfaceRenderer: InstituteSurfaceRendererService) {}

  ngAfterViewInit(): void {
    this.renderDynamicSurface();
  }

  ngOnChanges(_: SimpleChanges): void {
    this.renderDynamicSurface();
  }

  ngOnDestroy(): void {
    this.instituteSurfaceRenderer.clearAllComponents();
  }

  formatAddress(value: any): string {
    if (typeof value === 'string') {
      return value.trim();
    }
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
      return '';
    }
    const address = value as Record<string, unknown>;
    return [
      address['line1'] || address['Line1'] || address['line'],
      address['line2'] || address['Line2'],
      address['city'] || address['City'],
      address['state'] || address['State'],
      address['pincode'] || address['Pincode'] || address['pinCode'] || address['PinCode'] || address['postalCode'] || address['PostalCode'],
      address['country'] || address['Country'],
    ].map((part) => this.displayValue(part)).filter((part) => !!part).join(', ');
  }

  academicYearLabel(data: any): string {
    if (!data) {
      return '';
    }
    const from = data.academicYearFrom || data.academicYearStart || data.yearFrom;
    const to = data.academicYearTo || data.academicYearEnd || data.yearTo;
    if (from || to) {
      return [this.formatAcademicDate(from), this.formatAcademicDate(to)].filter((part) => !!part).join(' - ');
    }
    return this.displayValue(data.academicYear || data.academicYearRange);
  }

  formatStatus(value: any): string {
    const normalized = this.displayValue(value).toLowerCase();
    const knownLabels: { [key: string]: string } = {
      '1': 'Active',
      '0': 'Inactive',
      'active': 'Active',
      'inactive': 'Inactive',
      'enabled': 'Active',
      'disabled': 'Inactive',
    };
    return knownLabels[normalized] || this.displayValue(value);
  }

  private formatAcademicDate(value: any): string {
    const text = this.displayValue(value);
    if (!text) {
      return '';
    }
    if (/^\d{4}-\d{2}$/.test(text) || /^\d{4}\/\d{2}$/.test(text) || /^\d{4}-\d{2,4}$/.test(text)) {
      return text;
    }
    const parsed = new Date(text);
    if (isNaN(parsed.getTime())) {
      return text;
    }
    return parsed.toLocaleDateString(undefined, { month: 'short', year: 'numeric' });
  }

  private displayValue(value: any): string {
    if (value === null || value === undefined || typeof value === 'object') {
      return '';
    }
    return String(value).trim();
  }

  private renderDynamicSurface(): void {
    if (!this.fieldHost) {
      return;
    }

    const activeSchema = this.resolveSchema();
    this.panelTitle = this.resolvePanelTitle(activeSchema);
    this.panelSubtitle = this.resolvePanelSubtitle(activeSchema);
    this.instituteSurfaceRenderer.renderFields(this.buildFieldViewModels(activeSchema), this.fieldHost);
  }

  private resolveSchema(): InstituteSummarySchema {
    if (this.schema && Array.isArray(this.schema.fields) && this.schema.fields.length > 0) {
      return this.schema;
    }

    return {
      titlePath: 'name',
      subtitlePath: 'shortName',
      fields: [
        { id: 'address', label: 'Address', path: 'address', type: 'address', wide: true },
        { id: 'phone', label: 'Phone', path: 'phone', type: 'text' },
        { id: 'email', label: 'Email', path: 'email', type: 'text' },
        { id: 'website', label: 'Website', path: 'website', type: 'link' },
        { id: 'academicYear', label: 'Academic year', type: 'academicYear' },
        { id: 'status', label: 'Status', path: 'status', type: 'status' },
        { id: 'board', label: 'Board', path: 'board', type: 'text' },
      ]
    };
  }

  private buildFieldViewModels(schema: InstituteSummarySchema): InstituteFieldViewModel[] {
    const fields: InstituteFieldViewModel[] = [];
    (schema.fields || []).forEach((field) => {
      const model = this.mapFieldToViewModel(field);
      if (model.displayValue.length > 0) {
        fields.push(model);
      }
    });

    // M11-T1d: GENERIC render — every non-empty key on surface.data gets a
    // row (label humanized from the key, value as text), including keys the
    // fixed schema does not list. The agent/context owns the field set.
    const covered = new Set((schema.fields || []).map((field) => String(field.path || field.id || '')));
    const titleKey = String(schema.titlePath || 'name');
    const subtitleKey = String(schema.subtitlePath || 'shortName');
    const data = this.data && typeof this.data === 'object' && !Array.isArray(this.data) ? this.data : {};
    Object.keys(data).forEach((key) => {
      if (covered.has(key) || key === titleKey || key === subtitleKey) {
        return;
      }
      const value = data[key];
      let text = '';
      if (value && typeof value === 'object' && !Array.isArray(value)) {
        text = this.formatAddress(value);
      } else if (Array.isArray(value)) {
        text = value.map((entry: any) => this.displayValue(entry)).filter((part: string) => !!part).join(', ');
      } else {
        text = this.displayValue(value);
      }
      if (!text) {
        return;
      }
      fields.push({
        label: this.humanizeDataKey(key),
        displayValue: text,
        isLink: false,
        href: '',
        wide: false
      });
    });
    return fields;
  }

  /** M11-T1d: label from the key — camelCase/underscores become words. */
  private humanizeDataKey(key: string): string {
    const spaced = String(key || '')
      .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
      .replace(/[_-]+/g, ' ')
      .trim();
    if (!spaced) {
      return String(key || '');
    }
    return spaced.charAt(0).toUpperCase() + spaced.slice(1);
  }

  private mapFieldToViewModel(field: InstituteSummaryFieldSchema): InstituteFieldViewModel {
    const fieldType = field.type || 'text';
    const sourceValue = field.path ? this.readPath(this.data, field.path) : null;
    const displayValue = this.resolveFieldDisplayValue(fieldType, sourceValue);
    const href = fieldType === 'link' ? displayValue : '';

    return {
      label: field.label,
      displayValue: displayValue,
      isLink: fieldType === 'link',
      href: href,
      wide: !!field.wide
    };
  }

  private resolveFieldDisplayValue(type: string, sourceValue: any): string {
    if (type === 'address') {
      return this.formatAddress(sourceValue);
    }

    if (type === 'academicYear') {
      return this.academicYearLabel(this.data);
    }

    if (type === 'status') {
      return this.formatStatus(sourceValue);
    }

    return this.displayValue(sourceValue);
  }

  private resolvePanelTitle(schema: InstituteSummarySchema): string {
    const titleFromSchema = schema.titlePath ? this.displayValue(this.readPath(this.data, schema.titlePath)) : '';
    return titleFromSchema || this.displayValue(this.data && this.data.name) || 'Institute overview';
  }

  private resolvePanelSubtitle(schema: InstituteSummarySchema): string {
    const subtitleFromSchema = schema.subtitlePath ? this.displayValue(this.readPath(this.data, schema.subtitlePath)) : '';
    return subtitleFromSchema || this.displayValue(this.data && this.data.shortName);
  }

  private readPath(source: any, path: string): any {
    if (!source || !path) {
      return null;
    }

    const parts = path.split('.').filter((part) => !!part);
    let cursor = source;
    for (const part of parts) {
      if (cursor === null || cursor === undefined || typeof cursor !== 'object') {
        return null;
      }
      cursor = cursor[part];
    }
    return cursor;
  }
}
