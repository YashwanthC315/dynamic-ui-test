import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { Router } from '@angular/router';
import { Store, StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { take } from 'rxjs/operators';

import { CTApi } from '../../service/ct-api';
import { HostContextAdapter } from '../services/host-context-adapter.service';
import { AgentFileRunPort, AGENT_FILE_RUN_CONFIG, HttpAgentFileRunPort } from '../services/agent-file-run.port';
import { AgentFileRunEventsSocket } from '../services/agent-file-run-events.socket';
import { ChatResponseForwarder } from '../services/chat-response-forwarder.service';
import { ChatTransportAdapterService } from '../services/chat-transport-adapter.service';
import { CtBotConversationHistoryService } from '../services/ct-bot-conversation-history.service';
import { CtBotHostService } from '../services/ct-bot-host.service';
import { MockInstituteService } from '../services/mock-institute.service';
import { InstituteInfoForwarder } from '../services/institute-info-forwarder.service';
import { StudentFormPrefillService } from '../../student/service/student-form-prefill.service';
import { OrgFormPrefillService } from '../../org/service/org-form-prefill.service';
import * as chatActions from './action.chat';
import * as fromAgentChat from './reducer.chat';
import { ChatEffects } from './effects.chat';

/**
 * M15-T1 follow-up: an action starts the agent file run, ChatEffects
 * calls the port (POST-only), the reducer stores the 202 run_id under
 * the conversationId, and a selector reads it back. Fees and
 * buddy-parse turns both assert the strict two-key body on the way.
 */
import { EMPTY } from 'rxjs';
const EMPTY_SOCKET: any = EMPTY;

describe('agent file-run effect → reducer → select (M15-T1)', function () {
  const CONFIG = {
    baseUrl: 'http://file-run-host.test',
    bearerToken: 'file-run-token',
    agentPath: 'agents/ct_main.exs'
  };
  const RUNS_URL = 'http://file-run-host.test/api/playground/agent-file-runs';

  let http: HttpTestingController;
  let store: Store<any>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        StoreModule.forRoot({ agentChat: fromAgentChat.reducer }),
        EffectsModule.forRoot([ChatEffects])
      ],
      providers: [
        { provide: AGENT_FILE_RUN_CONFIG, useValue: CONFIG },
        { provide: AgentFileRunPort, useClass: HttpAgentFileRunPort },
        { provide: AgentFileRunEventsSocket, useValue: { open: () => EMPTY_SOCKET } },
        { provide: ChatTransportAdapterService, useValue: {} },
        { provide: ChatResponseForwarder, useValue: { publishResponse: () => {}, publishTransportError: () => {} } },
        { provide: CtBotConversationHistoryService, useValue: {} },
        { provide: CtBotHostService, useValue: {} },
        { provide: HostContextAdapter, useValue: {} },
        { provide: Router, useValue: {} },
        { provide: MockInstituteService, useValue: {} },
        { provide: InstituteInfoForwarder, useValue: {} },
        { provide: CTApi, useValue: {} },
        { provide: StudentFormPrefillService, useValue: { setDraft: () => {} } },
        { provide: OrgFormPrefillService, useValue: { setDraft: () => {} } }
      ]
    });
    http = TestBed.get(HttpTestingController);
    store = TestBed.get(Store);
  });

  afterEach(() => {
    http.verify();
  });

  function feesTurn(): chatActions.StartAgentFileRun {
    return new chatActions.StartAgentFileRun({
      conversationId: 'conv-1',
      turnText: 'what can you see?',
      history: [{ role: 'user', text: 'take me to fees transactions' }],
      context: {
        route: '/fees/transactions',
        view: { module: 'fees', screen: 'transactions', columns: ['id'], rows: [{ id: 't1' }] }
      } as any
    });
  }

  function buddyParseTurn(): chatActions.StartAgentFileRun {
    return new chatActions.StartAgentFileRun({
      conversationId: 'conv-1',
      turnText: 'Anita Rao 01/02/2014 female PUC I',
      context: {
        route: '/home',
        formOptions: { courses: [{ value: 'c1', label: 'PUC I Commerce A' }] }
      } as any
    });
  }

  function expectTwoKeyBody(req: any, turnMarker: string, contextMarker: string, contextIndex: number): void {
    expect(req.request.method).toBe('POST');
    expect(req.request.headers.get('Authorization')).toBe('Bearer file-run-token');
    expect(Object.keys(req.request.body)).toEqual(['agent_path', 'user_prompt']);
    expect(req.request.body['agent_path']).toBe('agents/ct_main.exs');
    expect(req.request.body['user_prompt'].indexOf(turnMarker)).toBeGreaterThan(0);
    // Index 0 only when the turn has no history (context JSON comes first).
    expect(req.request.body['user_prompt'].indexOf(contextMarker)).toBe(contextIndex);
    expect('system_prompt' in req.request.body).toBe(false);
  }

  function runIdsOnce(conversationId: string, assert: (ids: string[]) => void): void {
    store
      .select((state: any) => fromAgentChat.get_agent_file_run_ids_for(state.agentChat, conversationId))
      .take(1)
      .subscribe(assert);
  }

  it('fees turn: action → effect POST → 202 → run_id visible through the select', function (done) {
    store.dispatch(feesTurn());

    const req = http.expectOne(RUNS_URL);
    expectTwoKeyBody(req, 'what can you see?', '[host_context] {"route":"/fees/transactions"', 'user: take me to fees transactions\n'.length);
    req.flush({ run_id: 'run-fees-1' }, { status: 202, statusText: 'Accepted' });

    const labelReq = http.expectOne('http://file-run-host.test/api/playground/runs/run-fees-1');
    expect(labelReq.request.method).toBe('GET');
    expect(labelReq.request.headers.get('Authorization')).toBe('Bearer file-run-token');
    labelReq.flush({ label: 'CT-Bot Assistant' }, { status: 200, statusText: 'OK' });

    runIdsOnce('conv-1', (ids: string[]) => {
      expect(ids).toEqual(['run-fees-1']);
      done();
    });
  });

  it('buddy-parse turn: same flow; second run_id under the SAME conversationId', function (done) {
    store.dispatch(feesTurn());
    const first = http.expectOne(RUNS_URL);
    expectTwoKeyBody(first, 'what can you see?', '[host_context] {"route":"/fees/transactions"', 'user: take me to fees transactions\n'.length);
    first.flush({ run_id: 'run-fees-1' }, { status: 202, statusText: 'Accepted' });

    const firstLabel = http.expectOne('http://file-run-host.test/api/playground/runs/run-fees-1');
    firstLabel.flush({}, { status: 200, statusText: 'OK' });

    store.dispatch(buddyParseTurn());
    const second = http.expectOne(RUNS_URL);
    expectTwoKeyBody(second, 'Anita Rao 01/02/2014', '[host_context] {"route":"/home"', 0);
    second.flush({ run_id: 'run-buddy-2' }, { status: 202, statusText: 'Accepted' });

    const secondLabel = http.expectOne('http://file-run-host.test/api/playground/runs/run-buddy-2');
    secondLabel.flush({ label: 'Parse Agent' }, { status: 200, statusText: 'OK' });

    runIdsOnce('conv-1', (ids: string[]) => {
      expect(ids).toEqual(['run-fees-1', 'run-buddy-2']);
      done();
    });
  });

  it('a failed run stores nothing; other conversations stay empty', function (done) {
    store.dispatch(feesTurn());
    const req = http.expectOne(RUNS_URL);
    req.flush({ message: 'down' }, { status: 500, statusText: 'Server Error' });

    store
      .select((state: any) => state.agentChat.agentFileRunIds)
      .take(1)
      .subscribe((map: any) => {
        expect(map).toEqual({});
        done();
      });
  });
});
