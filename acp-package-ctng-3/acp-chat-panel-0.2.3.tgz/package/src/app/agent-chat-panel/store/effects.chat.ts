import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { createSelector } from '@ngrx/store';
import { Store } from '@ngrx/store';
import { mergeMap, map, catchError, take, tap, withLatestFrom, filter, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { of, EMPTY, from } from 'rxjs';
import * as chatActions from './action.chat';
import { ActionTypes } from './action.chat';
import { SendRequest, SendSuccess, SendFailure, LoadConversations, RestoreConversation, CreateConversation, LoadConversationsFailure, RestoreConversationFailure, CreateConversationFailure } from './action.chat';
import { ChatTransportAdapterService } from '../services/chat-transport-adapter.service';
import { ChatBlock, ChatRequest, ChatResponse, ChatEmitEventRequest } from '../services/chat-contracts';
import { ChatResponseForwarder } from '../services/chat-response-forwarder.service';
import { CtBotConversationHistoryService, ConversationListItem, ConversationDetailResponse, PersistedConversationMessage } from '../services/ct-bot-conversation-history.service';
import { CtBotHostService } from '../services/ct-bot-host.service';
import { Router } from '@angular/router';
import { MockInstituteService, InstituteInfo } from '../services/mock-institute.service';
import { InstituteInfoForwarder } from '../services/institute-info-forwarder.service';
import { AgentSurface, ActivityLogSurface } from '../services/surface-contracts';
import { CTApi } from '../../service/ct-api';
import { HostContextAdapter } from '../services/host-context-adapter.service';
import { AgentFileRunConfig, AGENT_FILE_RUN_CONFIG, AgentFileRunPort } from '../services/agent-file-run.port';
import { Inject } from '@angular/core';
import { AgentFileRunEventsSocket } from '../services/agent-file-run-events.socket';
import { HarnessAssistantResponse, hostProtocolVersion } from '../services/ct-bot-host-protocol';

/**
 * M15-T3 fix: agents sometimes answer with a fenced block —
 * ```json ... ``` / ``` ... ``` — around the assistant JSON
 * ({ messages, actions }). JSON.parse on the fence fails and the panel
 * would show the fence as text and never run the navigate action.
 * Strip ONE leading fence (```json or ```) and its closing fence, then
 * parse. A plain-text reply stays one text block; the reply is never
 * rewritten.
 */
export function stripCodeFence(rawResponse: string): string {
  let text = String(rawResponse || '');
  let trimmed = text.trim();
  // M15-T4 fence fix: agents also emit a blank line before the fence
  // ("\n```json\n...\n```"). Strip ONE fence that may sit after a
  // blank line — trim() already collapses leading whitespace, so the
  // trim-first path below covers it; after stripping, trim the inner
  // text too so a lone blank line inside the fence does not survive.
  if (trimmed.indexOf('```') === 0) {
    const closingIdx = trimmed.lastIndexOf('```');
    if (closingIdx > 0) {
      // Language cue on the opening fence (json), if any.
      const firstLineEnd = trimmed.indexOf('\n');
      const opener = firstLineEnd > 0 ? trimmed.slice(0, firstLineEnd) : '```';
      const fenceLang = opener.slice(3).trim().toLowerCase();
      if (closingIdx > 2 || fenceLang) {
        // The agent may leave a BLANK line inside the fence before the
        // payload ("```json\n\n{...}\n```") and blank lines around it —
        // trim the stripped inner text so JSON.parse sees clean JSON and
        // a plain-text block has no fence/blank-line wrapping.
        const inner = trimmed.slice(firstLineEnd > 0 ? firstLineEnd + 1 : 3, closingIdx).trim();
        text = inner;
      }
    }
  }
  return text;
}

/**
 * M15-T4 correction: Check validates EVERY workspace row (onCheck
 * deep-copies all records; the echo patches one flag per live record and
 * a missing row fails closed in mergeValidationEcho). The turn text
 * carries the workspace field list and EVERY record verbatim;
 * activeRecordId rides along as focus only. No verdict computed here —
 * the agent decides validity. The reply is expected to be a
 * buddy-enrol-workspace surface echo (same surface id, records[].valid
 * + reasons) so handleResponse runs the existing mergeValidationEcho.
 */
function buddyValidateTurnText(req: any): string {
  const values = req && req.values ? req.values : {};
  const fields = Array.isArray(values.fields) ? values.fields : [];
  const records = Array.isArray(values.records) ? values.records : [];
  return [
    'Validate these workspace records for the Check.',
    '[workspace fields] ' + JSON.stringify(fields),
    '[workspace records] ' + JSON.stringify(records),
    '[active record id] ' + String(values.activeRecordId || '')
  ].join('\n');
}

/**
 * M15-T7: the chips run's turn text — the compact suggestions input
 * (SUGGESTIONS.md): userText, lastAssistantText, recentHistory (up to 2
 * prior turns), route, optional surface facts. One JSON string; nothing
 * invented beyond what the turn carried.
 */
export function suggestionsRunTurnText(input: {
  userText: string;
  lastAssistantText: string;
  recentHistory: Array<{ role: 'user' | 'assistant'; text: string }>;
  route: string;
  surfaceType?: string;
  surfaceTitle?: string;
}): string {
  return JSON.stringify({
    userText: String(input.userText || ''),
    lastAssistantText: String(input.lastAssistantText || ''),
    recentHistory: (input.recentHistory || []).slice(-2),
    route: String(input.route || ''),
    ...(input.surfaceType ? { surfaceType: String(input.surfaceType) } : {}),
    ...(input.surfaceTitle ? { surfaceTitle: String(input.surfaceTitle) } : {})
  });
}

/** M15-T7: the assistant reply's text just composed (text/markdown blocks). */
export function assistantReplyText(payload: HarnessAssistantResponse): string {
  const messages = payload && Array.isArray(payload.messages) ? payload.messages : [];
  return messages
    .filter((message: any) => message && (message.type === 'text' || message.type === 'markdown'))
    .map((message: any) => String(message.type === 'text' ? message.text : message.markdown || '').trim())
    .filter((text: string) => !!text)
    .join(' ');
}

/**
 * M15-T7: map the suggestions agent's reply ({suggestions:[{label,text}]})
 * into an assistant suggestions message block (send_message chips). The
 * panel renders chips only through the existing block renderer; a reply
 * without suggestions yields no block (no chip invented).
 */
export function suggestionsPayloadToMessages(rawResponse: string): any[] {
  let parsed: any = null;
  try { parsed = JSON.parse(String(rawResponse || '')); } catch (e) { parsed = null; }
  const suggestions = parsed && typeof parsed === 'object' && Array.isArray(parsed.suggestions) ? parsed.suggestions : [];
  const items = suggestions
    .map((entry: any, index: number) => {
      const label = entry && typeof entry.label === 'string' ? entry.label.trim() : '';
      const text = entry && typeof entry.text === 'string' ? entry.text.trim() : '';
      if (!label || !text) { return null; }
      return { id: 'chip-' + (index + 1), label: label, action: 'send_message', payload: { text: text } };
    })
    .filter((item: any) => !!item);
  return items.length ? [{ type: 'suggestions', items: items }] : [];
}

function toHarnessAssistantPayload(rawResponse: string, conversationId: string): HarnessAssistantResponse {
  const unwrapped = stripCodeFence(rawResponse);
  let parsed: any = null;
  try { parsed = JSON.parse(unwrapped); } catch (e) { parsed = null; }
  // M15-T7 follow-up: a reply whose body is the SUGGESTIONS agent's shape
  // ({suggestions:[{label,text}]}) is CHIPS, not the reply text — the
  // bubble must never show that JSON. Map it to a suggestions message
  // block (the effect publishes/merges it as chips for the same request;
  // no chip when the list is empty). Labels come only from the agent.
  const isSuggestionsShape = !!(parsed && typeof parsed === 'object' && Array.isArray(parsed.suggestions));
  if (isSuggestionsShape) {
    return {
      type: 'assistant_response',
      hostProtocolVersion: hostProtocolVersion,
      conversationId: conversationId,
      correlationId: null,
      messages: suggestionsPayloadToMessages(unwrapped),
      actions: []
    } as HarnessAssistantResponse;
  }
  const isAssistantJson = !!(parsed && typeof parsed === 'object'
    && (Array.isArray(parsed.messages) || parsed.actions || parsed.surface || parsed.agent));
  if (isAssistantJson) {
    return parsed as HarnessAssistantResponse;
  }
  // M15-T4 fence fix: when the unwrapped text is NOT assistant JSON it
  // still stays ONE text block — of the STRIPPED text, so a stray or
  // unfenced-looking fence line never reaches the bubble. The verdict
  // (valid/invalid or the sentence) is the agent's; never rewritten.
  const salvaged = salvageMessagesSentence(unwrapped) || unwrapped;
  return {
    type: 'assistant_response',
    hostProtocolVersion: hostProtocolVersion,
    conversationId: conversationId,
    correlationId: null,
    messages: [{ type: 'text', text: salvaged }],
    actions: []
  } as HarnessAssistantResponse;
}

/**
 * M15-T4 fence fix: JSON.parse can still fail on a messages payload
 * (broken quote/edge chars). If the stripped text still looks like a
 * messages object, publish the FIRST text message's sentence VERBATIM —
 * never rewritten, never valid/invalid invented. '' when the text is
 * not recognizably a messages payload (caller falls back to its own
 * unmodified block).
 */
/**
 * M15-T6 follow-up: copy the host-sent courses list
 * (context.formOptions.courses) onto the surface's course select when
 * its options are missing or empty — only when the workspace/reply
 * surface is applied. A non-empty options list stays exactly as the
 * agent sent it; nothing is invented. The course field is identified by
 * the surface schema's own convention (optionsSource 'courses' or the
 * courseId select field of the enrol surface protocol) — never a
 * CampusTrack slice name.
 */
export function applyCourseOptionsToSurface(surface: any, courses: Array<{ value: string; label: string }>): void {
  if (!surface || typeof surface !== 'object' || !Array.isArray(courses) || !courses.length) { return; }
  const fields = Array.isArray(surface.fields) ? surface.fields
    : (surface.schema && Array.isArray(surface.schema.fields) ? surface.schema.fields : null);
  if (!fields) { return; }
  fields.forEach((field: any) => {
    if (!field || String(field.type || '') !== 'select') { return; }
    const isCourseField = String(field.optionsSource || '') === 'courses' || String(field.id || '') === 'courseId';
    if (!isCourseField) { return; }
    if (Array.isArray(field.options) && field.options.length) { return; }
    field.options = courses.map((option) => ({ value: String(option.value), label: String(option.label) }));
  });
}

export function salvageMessagesSentence(stripped: string): string {
  const text = String(stripped || '');
  if (text.indexOf('"messages"') === -1 || text.indexOf('"type"') === -1 || text.indexOf('"text"') === -1) {
    return '';
  }
  const messagesIdx = text.indexOf('"messages"');
  const after = text.slice(messagesIdx);
  const firstText = /"text"\s*:\s*"((?:[^"\\]|\\.)*)"/.exec(after);
  if (!firstText || !firstText[1].trim()) { return ''; }
  try {
    const sentence = JSON.parse('"' + firstText[1] + '"');
    return typeof sentence === 'string' ? sentence : '';
  } catch (e) {
    return '';
  }
}
import * as rootReducer from '../../rootReducer';
import * as studentAction from '../../student/store/action';
import { StudentFormPrefillService } from '../../student/service/student-form-prefill.service';
import { OrgFormPrefillService } from '../../org/service/org-form-prefill.service';
import * as fromAgent from './reducer.chat';

@Injectable()
export class ChatEffects {
  /** M9-T2b: the M8 effects SELECT the chat slice exactly like ChatFacade
   * does (createSelector over the root feature slice) — selecting the
   * feature selectors directly against the root store never emits, so the
   * PUTs would never run without this. */
  private selectAgentChatActivityLog = createSelector(rootReducer.getAgentChatState, fromAgent.get_activity_log);
  private selectAgentChatActiveSurface = createSelector(rootReducer.getAgentChatState, fromAgent.get_active_surface);
  private selectAgentChatConversationId = createSelector(rootReducer.getAgentChatState, fromAgent.get_conversation_id);
  private selectAgentChatRestoredWorkspace = createSelector(rootReducer.getAgentChatState, fromAgent.get_restored_workspace_surface);
  /**
   * M15-T3: the send path no longer POSTs the mock socket. The panel
   * still dispatches SendRequest (same bookkeeping); here the effect
   * builds the SAME context bag the socket path composed
   * (ctBotHostService.buildUserContextBag) and dispatches
   * StartAgentFileRun — history + turn text ride the panel's request
   * untouched. The reply does NOT come from here: it arrives on the
   * read-only events socket (T2) and agentFileRunReply$ publishes/
   * settles this turn (agentFileRunFailed$ settles failures).
   */
  @Effect() sendRequest$ = this.actions$
    .pipe(
      ofType<SendRequest>(ActionTypes.SEND_REQUEST),
      mergeMap((action) => {
        const req: ChatRequest | undefined = action.payload && action.payload.message;
        // ignore emit_event synthetic requests routed through same action (they use a special prompt prefix)
        if (!req || (typeof req.prompt === 'string' && req.prompt.indexOf('[emit_event:') === 0)) {
          return EMPTY;
        }
        const conversationId = req.conversationId || this.ctBotHostService.conversationFallbackId;
        return from(this.ctBotHostService.buildUserContextBag(req)).pipe(
          // The panel does not POST or open sockets — it created this
          // turn's history + context snapshot; this dispatch starts one
          // file run for the utterance. The effect emits no action here:
          // the run's reply/failure settles the turn.
          tap((bag) => this.store.dispatch(new chatActions.StartAgentFileRun({
            conversationId: conversationId,
            turnText: req.prompt,
            history: req.history,
            context: bag,
            requestId: req.requestId,
            messageId: req.messageId
          }))),
          mergeMap(() => EMPTY),
          catchError((err) => {
            const details = err && err.message ? err.message : 'Request failed';
            this.forwarder.publishTransportError(action.payload.requestId, details);
            return of(new SendFailure({ requestId: action.payload.requestId, error: details }));
          })
        );
      })
    );

  /**
   * M15-T8: the conversation list used to call the mock harness
   * (history.listConversations -> http://localhost:8787 /v1/conversations)
   * and failed on every session. The file-run harness has no
   * conversation-list route, so the effect stops that call: the action
   * still runs, and the list is honestly empty — no invented
   * conversations, no fake titles, no request to the mock base.
   */
  @Effect() loadConversations$ = this.actions$
    .pipe(
      ofType<LoadConversations>(ActionTypes.LOAD_CONVERSATIONS),
      mergeMap((action) => {
        return of(new chatActions.SetConversationList({ list: [] }));
      })
    );

  /**
   * M15-T1: agent file-run — an action starts the run, this effect calls
   * the port (the port only POSTs), the reducer stores the 202 run_id
   * under conversationId on the success action. Failures become
   * AgentFileRunFailed (M15-T3) so the panel turn settles via the
   * transportError path.
   */
  @Effect() startAgentFileRun$ = this.actions$
    .pipe(
      ofType<chatActions.StartAgentFileRun>(ActionTypes.START_AGENT_FILE_RUN),
      mergeMap((action) => {
        if (!action.payload || !action.payload.conversationId || !action.payload.turnText) {
          return EMPTY;
        }
        return this.agentFileRunPort.startFileRun(action.payload).pipe(
          map((runId: string) => new chatActions.StartAgentFileRunSuccess({
            conversationId: action.payload.conversationId,
            runId: runId,
            requestId: action.payload.requestId,
            messageId: action.payload.messageId,
            purpose: action.payload.purpose,
            userText: action.payload.turnText,
            history: action.payload.history,
            route: action.payload.context ? String((action.payload.context as any).route || '') : ''
          })),
          catchError((err) => {
            console.warn('[agent-chat] agent file run failed', err);
            return of(new chatActions.AgentFileRunFailed({
              requestId: action.payload.requestId || '',
              error: err && err.message ? String(err.message) : 'Agent file run failed',
              conversationId: action.payload.conversationId,
              purpose: action.payload.purpose
            }));
          })
        );
      })
    );

  /**
   * M15-T2: after StartAgentFileRunSuccess the effect opens the run's
   * READ-ONLY events socket ({base}/api/playground/runs/{run_id}/events/ws,
   * aetheris subprotocols), maps every llm_responded/text frame to the
   * reply action (later frames replace via the reducer), and stops on
   * control stream_end. The socket sends nothing; tool_call / spawn_agent
   * / child-run frames never reach the reducer. Do not send
   * system_prompt anywhere in this flow and never invent the reply.
   */
  @Effect() streamAgentFileRunEvents$ = this.actions$
    .pipe(
      ofType<chatActions.StartAgentFileRunSuccess>(ActionTypes.START_AGENT_FILE_RUN_SUCCESS),
      filter((action) => !!(action.payload && action.payload.conversationId && action.payload.runId)),
      switchMap((action) => this.agentFileRunEventsSocket.open(action.payload.runId).pipe(
        map((reply) => new chatActions.AgentFileRunReply({
          conversationId: action.payload.conversationId,
          rawResponse: reply.rawResponse,
          requestId: action.payload.requestId,
          messageId: action.payload.messageId,
          purpose: action.payload.purpose,
          userText: action.payload.userText,
          history: action.payload.history,
          route: action.payload.route
        })),
        catchError((err) => {
          console.warn('[agent-chat] agent file-run events socket failed', err);
          return EMPTY;
        })
      ))
    );

  /**
   * M15-T3: the run record's label (GET runs/{run_id}) — stored so the
   * reply publisher can copy it onto message.agent (agent byline).
   * Errors/absent labels fall back to CT-Bot Assistant downstream.
   */
  @Effect() agentFileRunLabel$ = this.actions$
    .pipe(
      ofType<chatActions.StartAgentFileRunSuccess>(ActionTypes.START_AGENT_FILE_RUN_SUCCESS),
      // M15-T7: chips runs carry no byline — never overwrite the chat
      // run's label.
      filter((action) => action.payload.purpose !== 'suggestions'),
      mergeMap((action) => this.agentFileRunPort.readRunLabel(action.payload.runId).pipe(
        map((label: string) => new chatActions.AgentFileRunLabel({
          conversationId: action.payload.conversationId,
          requestId: action.payload.requestId,
          label: label
        })),
        catchError(() => EMPTY)
      ))
    );

  /**
   * M15-T3: the file-run reply becomes a response the panel ALREADY
   * renders — the same ChatResponse builder the mock-socket path uses
   * (no second renderer). raw_response that is assistant JSON feeds
   * that path unchanged; plain text renders as one text block. The
   * byline is NOT in the raw_response: the run label is copied onto the
   * existing message.agent field (absent label -> CT-Bot Assistant
   * fallback). Publishing then settles the panel turn exactly like the
   * old transport.send path.
   */
  /**
   * M15-T3: the file-run reply becomes a response the panel ALREADY
   * renders — the same ChatResponse builder the mock-socket path uses
   * (no second renderer). M15-T7: a persisted assistant reply ALSO
   * requests chips from the suggestions agent file (a second file run,
   * started here); the chips reply merges onto the original blocks for
   * the SAME requestId. No chip when the suggestions run returns none.
   */
  @Effect() agentFileRunReply$ = this.actions$
    .pipe(
      ofType<chatActions.AgentFileRunReply>(ActionTypes.AGENT_FILE_RUN_REPLY),
      withLatestFrom(this.store.select(rootReducer.getAgentChatState)),
      mergeMap(([action, agentChatState]) => {
        const conversationId = action.payload && action.payload.conversationId;
        const rawResponse = action.payload && action.payload.rawResponse;
        const requestId = (action.payload && action.payload.requestId) || '';
        const userMessageId = (action.payload && action.payload.messageId) || '';
        if (!conversationId || !rawResponse) { return EMPTY; }
        if (!requestId) {
          // Older flows may not thread the envelope; nothing to render.
          console.warn('[agent-chat] agent file-run reply without requestId');
          return EMPTY;
        }
        if (action.payload.purpose === 'suggestions') {
          return this.publishSuggestionsReply(action, agentChatState as any, requestId, conversationId, userMessageId);
        }
        const response = this.ctBotHostService.buildAssistantChatResponse(
          toHarnessAssistantPayload(rawResponse, conversationId),
          { requestId: requestId, conversationId: conversationId, messageId: userMessageId }
        );
        // The byline is not in the JSON: copy the run label onto the
        // existing message.agent field when present.
        const label = fromAgent.get_agent_file_run_label_for(agentChatState as any, conversationId);
        if (label) {
          response.agent = {
            id: (response.agent && response.agent.id) || 'ct-bot-mock-harness',
            displayName: label
          };
        }
        // M15-T6 follow-up: the Course menu was empty after Prepare when
        // the model omitted options. The host already sent
        // context.formOptions.courses for this run — copy it onto the
        // reply surface's course select when missing/empty (never
        // inventing; a non-empty agent-sent list stays as sent).
        const courses = fromAgent.get_agent_file_run_course_options_for(agentChatState as any, conversationId);
        if (response.surface) {
          applyCourseOptionsToSurface(response.surface, courses);
        }
        this.forwarder.publishResponse(response);
        // M15-T3 fix: the reply's navigate actions must actually move the
        // page — the effect RETURNS NavigateRequested alongside
        // SendSuccess for each mapped navigate action (href already
        // allowlisted by the mapping); the existing navigate$ effect
        // performs the move. No store.dispatch inside the effect, no
        // new route list, nothing invented beyond the reply.
        const navigateOutputs = (response.actions || [])
          .filter((mapped) => !!(mapped && mapped.payload && String(mapped.payload['type'] || '') === 'navigate'))
          .map((mapped) => String(mapped.payload['href'] || '').trim())
          .filter((href: string) => !!href)
          .map((href: string) => new chatActions.NavigateRequested({ href: href }));
        const settle: chatActions.Actions[] = navigateOutputs;
        settle.push(new chatActions.SendSuccess({ requestId: requestId }));
        // M15-T7: request chips for this persisted reply — a second file
        // run with the suggestions agent path (host config); none when
        // unconfigured. The chips reply merges onto the original blocks
        // for the SAME requestId. A reply that is ALREADY the suggestions
        // shape (chips or an empty list) is chips, not text — no second
        // chips run for it.
        const chatPayload = toHarnessAssistantPayload(rawResponse, conversationId);
        let parsedChatShape: any = null;
        try { parsedChatShape = JSON.parse(stripCodeFence(rawResponse)); } catch (e) { parsedChatShape = null; }
        const replyIsSuggestionsShape = !!(parsedChatShape && typeof parsedChatShape === 'object' && Array.isArray(parsedChatShape.suggestions));
        const suggestionsAgentPath = this.fileRunConfig && String(this.fileRunConfig.suggestionsAgentPath || '').trim();
        if (suggestionsAgentPath && !replyIsSuggestionsShape) {
          settle.push(new chatActions.StartAgentFileRun({
            conversationId: conversationId,
            turnText: suggestionsRunTurnText({
              userText: action.payload.userText || '',
              lastAssistantText: assistantReplyText(chatPayload),
              recentHistory: action.payload.history || [],
              route: action.payload.route || '',
              surfaceType: chatPayload.surface ? String((chatPayload.surface as any).type || '') : undefined,
              surfaceTitle: chatPayload.surface ? String((chatPayload.surface as any).title || '') : undefined
            }),
            requestId: requestId,
            messageId: userMessageId,
            purpose: 'suggestions',
            agentPath: suggestionsAgentPath
          }));
        }
        return from(settle);
      })
    );

  /**
   * M15-T7: the chips reply renders through the SAME publish path — the
   * original chat blocks stay, the suggestions block is appended, and
   * the response is published for the ORIGINAL requestId so the panel
   * patches the existing assistant message (text + chips). No chips →
   * no publish, nothing else happens.
   */
  private publishSuggestionsReply(
    action: chatActions.AgentFileRunReply,
    agentChatState: any,
    requestId: string,
    conversationId: string,
    userMessageId: string
  ) {
    // The chat reply's raw_response (kept in the store; suggestions runs
    // never overwrite it) rebuilds the original blocks through the ONE
    // builder — then the chips block is appended for the SAME requestId.
    const chatRaw = fromAgent.get_agent_file_run_reply_for(agentChatState, conversationId);
    if (!chatRaw) {
      console.warn('[agent-chat] suggestions reply without a chat reply; no chips');
      return EMPTY;
    }
    const chatResponse = this.ctBotHostService.buildAssistantChatResponse(
      toHarnessAssistantPayload(chatRaw, conversationId),
      { requestId: requestId, conversationId: conversationId, messageId: userMessageId }
    );
    const chipMessages = suggestionsPayloadToMessages(action.payload.rawResponse);
    if (!chipMessages.length) {
      // No chip when the suggestions run returns none.
      return EMPTY;
    }
    const chipsResponse = this.ctBotHostService.buildAssistantChatResponse(
      { type: 'assistant_response', hostProtocolVersion: hostProtocolVersion, conversationId: conversationId, correlationId: null, messages: chipMessages, actions: [] },
      { requestId: requestId, conversationId: conversationId, messageId: userMessageId }
    );
    chatResponse.blocks = chatResponse.blocks.concat(chipsResponse.blocks);
    this.forwarder.publishResponse(chatResponse);
    return of(new chatActions.SendSuccess({ requestId: requestId }));
  }

  /**
   * M15-T3: file-run POST/context-build failure settles the panel turn
   * exactly like the old transport error path (transportError + SendFailure).
   */
  @Effect() agentFileRunFailed$ = this.actions$
    .pipe(
      ofType<chatActions.AgentFileRunFailed>(ActionTypes.AGENT_FILE_RUN_FAILED),
      // M15-T7: a failed chips run is not a turn failure — the reply was
      // already published; no chip comes back and nothing else happens.
      filter((action) => action.payload.purpose !== 'suggestions'),
      mergeMap((action) => {
        this.forwarder.publishTransportError(action.payload.requestId, action.payload.error);
        return of(new chatActions.SendFailure({ requestId: action.payload.requestId, error: action.payload.error }));
      })
    );

  @Effect() restoreConversation$ = this.actions$
    .pipe(
      ofType<RestoreConversation>(ActionTypes.RESTORE_CONVERSATION),
      mergeMap((action) => {
        return this.history.loadConversation(action.payload.conversationId).pipe(
          mergeMap((conversation: ConversationDetailResponse) => {
            // map persisted messages to ConversationMessage[] similar to component
            const mapped = this.mapPersistedConversationMessages(conversation.messages || []);
            const baseActions: any[] = [
              new chatActions.SetConversationId({ conversationId: conversation.id }),
              new chatActions.SetMessages({ messages: mapped })
            ];
            // D6: the workspace snapshot loads AFTER messages and lands as
            // SetActiveSurface from that payload (never a thin form when
            // none was stored); 404 → surface stays null.
            return this.history.loadWorkspaceSnapshot(conversation.id).pipe(
              mergeMap((storedSnapshot: any) => {
                const restoredSurface = storedSnapshot && storedSnapshot.surface;
                if (restoredSurface
                  && (restoredSurface.type === 'student-enrol-form' || restoredSurface.type === 'org-add-form' || restoredSurface.type === 'buddy-enrol-workspace')
                  && surfaceHasSnapshotContent(restoredSurface)) {
                  const stamped = Object.assign({}, restoredSurface, { conversationId: conversation.id });
                  baseActions.push(new chatActions.SetActiveSurface({ surface: stamped }));
                  baseActions.push(new chatActions.SetRestoredWorkspaceSurface({ surface: stamped }));
                }
                // M8-T2: restore the Actions log for THIS conversation alongside
                // the messages — with items, it re-enters the existing store
                // (SetActivityLog); the pane itself only shows when the
                // Workspace is visible (never auto-opened). 404/empty → no log
                // restore, and another conversation's log is never loaded.
                return this.history.loadActivityLog(conversation.id).pipe(
                  mergeMap((stored: any) => {
                    const restored = stored && stored.activityLog;
                    if (restored && restored.type === 'activity-log'
                      && Array.isArray(restored.items) && restored.items.length) {
                      // M8-T5: pin the owner with the log — the restored
                      // conversation id, so the persist write-back never uses
                      // a later active id.
                      baseActions.push(new chatActions.SetActivityLog({
                        surface: Object.assign({}, restored, { conversationId: conversation.id })
                      }));
                    }
                    return from(baseActions);
                  }),
                  catchError(() => from(baseActions))
                );
              }),
              catchError(() => from(baseActions))
            );
          }),
          catchError((err) => {
            console.warn('[agent-chat] Unable to restore conversation', err);
            return of(new RestoreConversationFailure({ error: (err && err.message) || 'Load failed' }));
          })
        );
      })
    );

  @Effect() createConversation$ = this.actions$
    .pipe(
      ofType<CreateConversation>(ActionTypes.CREATE_CONVERSATION),
      mergeMap((action) => {
        return this.history.createConversation(action.payload.conversationId, action.payload.title || 'New chat').pipe(
          mergeMap(() => {
            // reload list
            return from([new LoadConversations({ restoreActive: false })]);
          }),
          catchError((err) => {
            console.warn('[agent-chat] Unable to create conversation', err);
            return of(new CreateConversationFailure({ error: (err && err.message) || 'Create failed' }));
          })
        );
      })
    );

  /**
   * M9-T2: the effects own the harness REST I/O for the M8 activity-log
   * and workspace-snapshot persist/restore — the panel never calls
   * CtBotConversationHistoryService. Same URLs, same token headers, same
   * dual-owner rules; no behaviour change.
   */

  /** 1) Persist Actions log: ACTIVITY_LOG_SET / APPEND (non-empty) → PUT
   * /activity-log using the conversationId PINNED on the surface (M8-T5).
   * Empty/null logs are never persisted (M8-T1 no-op rule). */
  @Effect({ dispatch: false }) persistActivityLog$ = this.actions$
    .pipe(
      ofType<chatActions.SetActivityLog | chatActions.AppendActivityItem>(
        ActionTypes.ACTIVITY_LOG_SET,
        ActionTypes.ACTIVITY_LOG_APPEND
      ),
      withLatestFrom(this.store.select(this.selectAgentChatActivityLog as any)),
      map((pair: any[]) => pair[1] as ActivityLogSurface),
      filter((log) => !!log && Array.isArray(log.items) && log.items.length > 0),
      withLatestFrom(this.store.select(this.selectAgentChatConversationId as any)),
      mergeMap((pair: any[]) => {
        const log = pair[0] as ActivityLogSurface;
        // M8-T5/M9-T2b: the owner is the PINNED conversationId, falling
        // back to the store's active conversation id.
        const ownerConversationId = String((log.conversationId || pair[1] || '')).trim();
        if (!ownerConversationId) {
          return EMPTY;
        }
        const snapshot: any = Object.assign({}, log, { conversationId: ownerConversationId });
        return this.history.saveActivityLog(ownerConversationId, snapshot).pipe(
          catchError(() => EMPTY)
        );
      })
    );

  /** 2) Restore Actions log (Workspace ⋮ with an empty in-memory log): the
   * component dispatches LoadActivityLog — the effect GETs and lands the
   * items in the existing SetActivityLog store slice (pinned conversationId
   * per M8-T5). 404/empty → no dispatch; the empty pane stays. */
  @Effect() loadActivityLog$ = this.actions$
    .pipe(
      ofType<chatActions.LoadActivityLog>(ActionTypes.LOAD_ACTIVITY_LOG),
      mergeMap((action) => {
        const conversationId = String(action.payload && action.payload.conversationId || '').trim();
        if (!conversationId) {
          return EMPTY;
        }
        return this.history.loadActivityLog(conversationId).pipe(
          mergeMap((stored: any) => {
            const restored = stored && stored.activityLog;
            if (restored && restored.type === 'activity-log'
              && Array.isArray(restored.items) && restored.items.length) {
              return of(new chatActions.SetActivityLog({
                surface: Object.assign({}, restored, { conversationId: conversationId })
              }));
            }
            return EMPTY;
          }),
          catchError(() => EMPTY)
        );
      })
    );

  /** 3) Persist Workspace snapshot: SURFACE_SET of student-enrol-form /
   * buddy-enrol-workspace with content, plus the live-edit chrome events
   * (record_selected / field_patched student.enrol.*) and the post-settle
   * request → PUT /workspace-snapshot. The save settle copies the
   * saved-chip flags onto the store surface BEFORE this PUT (M9-T2c), so
   * the emit that starts the save never persists. On success the same
   * snapshot becomes the same-conversation restore cache. context
   * (context.view) is never persisted. */
  @Effect() persistWorkspaceSnapshot$ = this.actions$
    .pipe(
      ofType<chatActions.SetActiveSurface | chatActions.EmitEventRequested | chatActions.PersistWorkspaceSnapshotRequested>(
        ActionTypes.SURFACE_SET,
        ActionTypes.EMIT_EVENT_REQUESTED,
        ActionTypes.WORKSPACE_SNAPSHOT_PERSIST_REQUESTED
      ),
      filter((action) => {
        // M9-T2c: only the live-edit chrome events trigger from the emit
        // path — the save settle persists via the post-settle request (the
        // store surface then carries the saved chips).
        if (action.type === ActionTypes.EMIT_EVENT_REQUESTED) {
          const request = (action as chatActions.EmitEventRequested).payload
            && (action as chatActions.EmitEventRequested).payload.eventRequest;
          const event = String(request && request.event || '');
          return event === 'record_selected' || event === 'field_patched';
        }
        return true;
      }),
      withLatestFrom(
        this.store.select(this.selectAgentChatActiveSurface as any),
        this.store.select(this.selectAgentChatConversationId as any)
      ),
      // D6.3: on SURFACE_SET the ACTION payload is authoritative (the
      // store select can lag the just-dispatched surface); other triggers
      // keep the store surface.
      map((rows: any[]) => ({
        action: rows[0],
        surface: (rows[0] && rows[0].type === ActionTypes.SURFACE_SET
          ? rows[0].payload && rows[0].payload.surface
          : rows[1]) as AgentSurface | null,
        conversationId: String(rows[2] || '').trim()
      })),
      withLatestFrom(this.store.select(this.selectAgentChatRestoredWorkspace as any)),
      filter((pair: any[]) => {
        const candidate = pair[0];
        const type = String(candidate.surface && candidate.surface.type || '');
        if (!candidate.conversationId
          || (type !== 'student-enrol-form' && type !== 'buddy-enrol-workspace')
          || !surfaceHasSnapshotContent(candidate.surface)) {
          return false;
        }
        // D6: one row per conversation — buddy with records WINS. A thin
        // form never overwrites an existing buddy-enrol-workspace snapshot.
        const restored = pair[1];
        if (type !== 'buddy-enrol-workspace' && restored
          && String(restored.type || '') === 'buddy-enrol-workspace'
          && Array.isArray(restored.records) && restored.records.length > 0) {
          return false;
        }
        return true;
      }),
      // D6.4: unwrap the pair — everything downstream works on the
      // candidate ({ surface, conversationId }), not the raw
      // [candidate, restored] tuple.
      map((pair: any[]) => pair[0]),
      distinctUntilChanged((a: any, b: any) => JSON.stringify(a && a.surface) === JSON.stringify(b && b.surface)),
      mergeMap((candidate: any) => {
        // M8-T5/M9-T2b: the owner is the PINNED conversationId (stamped at
        // M8-T3 persist time), falling back to the store's active id.
        const ownerConversationId = String((candidate.surface && (candidate.surface as any).conversationId
          || candidate.conversationId || '')).trim();
        const snapshot: any = Object.assign({}, candidate.surface, { conversationId: ownerConversationId });
        delete snapshot.context;
        return this.history.saveWorkspaceSnapshot(ownerConversationId, snapshot).pipe(
          // M9-T2c: the successful snapshot is ALSO the same-conversation
          // restore cache — no conversation switch needed to reuse it.
          mergeMap(() => {
            // D6.3: the reuse cache is stamped ONLY from a buddy workspace
            // with records — thin forms never become the cache.
            if (snapshot.type === 'buddy-enrol-workspace'
              && Array.isArray(snapshot.records) && snapshot.records.length > 0) {
              return of(new chatActions.SetRestoredWorkspaceSurface({ surface: snapshot }));
            }
            return EMPTY;
          }),
          catchError(() => EMPTY)
        );
      })
    );

  /**
   * D1: get_institute_snapshot as a host function — when the agent emits
   * an institute-summary surface, the effect runs the host function, then
   * merges snapshot.data onto surface.data (snapshot keys win, no
   * invented keys) and re-dispatches openSurface (the motherboard path).
   * status !== ok → no invented data; the reply's own failure text stays.
   * The identical-JSON guard stops the re-dispatch loop.
   */
  @Effect() hydrateInstituteSurface$ = this.actions$
    .pipe(
      ofType<chatActions.SetActiveSurface>(ActionTypes.SURFACE_SET),
      map((action) => action.payload && action.payload.surface),
      filter((surface: any) => !!surface && String(surface.type || '') === 'institute-summary'),
      withLatestFrom(this.store.select((state: any) => state)),
      mergeMap((pair: any[]) => from(this.hostContextAdapter.getInstituteSnapshot(pair[1])).pipe(
        mergeMap((snap: any) => {
          if (!snap || snap.status !== 'ok' || !snap.data || typeof snap.data !== 'object') {
            // status not ok — never invent data; keep the reply as-is.
            return EMPTY;
          }
          const merged = Object.assign({}, pair[0], {
            data: Object.assign({}, pair[0].data, snap.data)
          });
          if (JSON.stringify(merged) === JSON.stringify(pair[0])) {
            return EMPTY;
          }
          return of(new chatActions.SetActiveSurface({ surface: merged }));
        }),
        catchError(() => EMPTY)
      ))
    );

  private mapPersistedConversationMessages(messages: PersistedConversationMessage[]) {
    if (!Array.isArray(messages)) { return []; }
    return messages
      .map((m) => this.mapPersistedConversationMessage(m))
      .filter((m) => m !== null) as any[];
  }

  private mapPersistedConversationMessage(message: PersistedConversationMessage) {
    if (!message || typeof message !== 'object') { return null; }
    if (message.role === 'user') {
      const text = typeof message.text === 'string' ? message.text : '';
      if (!text.trim()) { return null; }
      return {
        id: message.id || `msg_user_${Date.now()}_${Math.random()}`,
        role: 'user',
        blocks: [{ type: 'text', text }],
        timestamp: message.createdAt || new Date().toISOString(),
        status: 'completed',
        userMessageId: message.userMessageId,
      };
    }
    if (message.role === 'assistant') {
      const assistantPayload = message.assistant || null;
      const blocks = this.ctBotHostService.mapStoredAssistantBlocks(
        assistantPayload && Array.isArray(assistantPayload.messages) ? assistantPayload.messages : [],
        assistantPayload ? assistantPayload.correlationId || null : null
      );
      return {
        id: message.id || `msg_assistant_${Date.now()}_${Math.random()}`,
        role: 'assistant',
        blocks: blocks.length ? blocks : [{ type: 'text', text: 'No renderable content was returned.' }],
        timestamp: message.createdAt || new Date().toISOString(),
        status: 'completed'
      };
    }
    return null;
  }

  @Effect({ dispatch: false }) navigate$ = this.actions$
    .pipe(
      ofType<chatActions.NavigateRequested>(chatActions.ActionTypes.NAVIGATE_REQUESTED),
      map((action) => (action.payload && String(action.payload.href || '').trim()) || ''),
      tap((href) => {
        if (!href) { return; }
        // basic validation: internal href only
        if (href.charAt(0) !== '/' || /^https?:\/\//i.test(href)) {
          console.warn('[agent-chat] Ignoring invalid navigation href:', href);
          return;
        }
        this.router.navigateByUrl(href).catch((err) => console.error('[agent-chat] Navigation failed:', err));
      })
    );

  @Effect() emitEvent$ = this.actions$
    .pipe(
      ofType<chatActions.EmitEventRequested>(chatActions.ActionTypes.EMIT_EVENT_REQUESTED),
      mergeMap((action) => {
        const req = action.payload && action.payload.eventRequest;
        if (!req) { return EMPTY; }
        const eventName = String(req.event || '');
        const actionName = String(req.action || '');
        // Host-side intercepts (never reach the harness):
        // - form_continue (any action)            → prefill + open the full in-app form.
        // - form_submit + student.enrol.*         → persistStudentEnrol (thin enrol AND
        //   buddy workspace active-record submit; values only, no parse logic here).
        // - form_submit + org.add.*               → persistOrgAdd.
        // Everything else is forwarded to the harness via CtBotHostService.emitEvent,
        // including buddy workspace events buddy_parse/student.enrol.parse and
        // record_selected/student.enrol.select (harness no-ops/acks until BW-T3;
        // parse is never handled FE-side).
        if (eventName === 'form_continue') {
          return this.handleFormContinue(req, actionName);
        }
        // M5-T4 follow-up: the post-save authoring hop re-uses form_submit +
        // student.enrol.* but must NEVER persist again — the save already
        // succeeded via CTApi; forward it to the harness so it authors the
        // Actions catalog.
        if (eventName === 'form_submit' && actionName.indexOf('student.enrol') === 0) {
          // M15-T6: Submit active / Submit all persist through the EXISTING
          // student-add save (ctApi.enrolStudent) — the save is the script;
          // the agent never invents a created student and never runs this
          // hop as a file run.
          if (!(req && req.activityAuthoring)) {
            return this.persistStudentEnrol(req);
          }
          // M15-T6: the post-save AUTHORING hop must not fall through to
          // the old mock socket (dead since the file-run transport) and
          // must not start a file run. It settles through the
          // transportError path, whose panel fallback
          // (appendActivitySaveOutcome) records the already-confirmed save
          // outcome without a new agent claim.
          const authoringDown = 'Agent Actions authoring is not available.';
          this.forwarder.publishTransportError(req.requestId, authoringDown);
          return of(new SendFailure({ requestId: req.requestId, error: authoringDown }));
        }
        if (eventName === 'form_submit' && actionName.indexOf('org.add') === 0) {
          return this.persistOrgAdd(req);
        }
        // M15-T3: buddy-parse turns leave the mock socket too — the pasted
        // notes are THIS turn's text; the gate keeps form saves,
        // selection acks and everything else on their existing effects.
        if (eventName === 'buddy_parse' || actionName.indexOf('student.enrol.parse') === 0) {
          return from(this.ctBotHostService.buildEventContextBag(req)).pipe(
            tap((bag) => this.store.dispatch(new chatActions.StartAgentFileRun({
              conversationId: req.conversationId || this.ctBotHostService.conversationFallbackId,
              turnText: req.values && req.values['text'] ? String(req.values['text']) : '',
              context: bag,
              requestId: req.requestId,
              messageId: req.messageId
            }))),
            mergeMap(() => EMPTY),
            catchError((err) => {
              const details = err && err.message ? err.message : 'Emit event failed';
              this.forwarder.publishTransportError(req.requestId, details);
              return of(new SendFailure({ requestId: req.requestId, error: details }));
            })
          );
        }
        // M15-T5: clicking a workspace row is host-local UI state — the
        // surface ALREADY holds the records and the panel dispatches the
        // refreshed surface (activeRecordId set) in the same turn. No
        // file run, no mock socket, no agent turn: choosing the focused
        // row is not a verdict. The gate swallows the event here; the
        // emit path stays one place (emitEvent$).
        if (eventName === 'record_selected' || actionName.indexOf('student.enrol.select') === 0) {
          return EMPTY;
        }
        // M15-T4: the workspace Check hop (buddy_validate) used to fall
        // through to the old mock socket (ws://localhost:8787) and die
        // with "Unable to connect" / "Something went wrong while
        // processing that action." — it takes the same file-run channel
        // as buddy_parse. The user_prompt carries the workspace field
        // list and EVERY row (activeRecordId is focus only); the agent
        // decides validity and the reply renders through the existing
        // publish path (a surface echo patches the live panel via
        // mergeValidationEcho; plain text renders one block). No
        // validity decision here.
        if (eventName === 'buddy_validate' || actionName.indexOf('student.enrol.validate') === 0) {
          return from(this.ctBotHostService.buildEventContextBag(req)).pipe(
            tap((bag) => this.store.dispatch(new chatActions.StartAgentFileRun({
              conversationId: req.conversationId || this.ctBotHostService.conversationFallbackId,
              turnText: buddyValidateTurnText(req),
              context: bag,
              requestId: req.requestId,
              messageId: req.messageId
            }))),
            mergeMap(() => EMPTY),
            catchError((err) => {
              const details = err && err.message ? err.message : 'Emit event failed';
              this.forwarder.publishTransportError(req.requestId, details);
              return of(new SendFailure({ requestId: req.requestId, error: details }));
            })
          );
        }
        return this.ctBotHostService.emitEvent(req).pipe(
          map((response) => {
            this.forwarder.publishResponse(response);
            return new SendSuccess({ requestId: req.requestId });
          }),
          catchError((err) => {
            const details = err && err.message ? err.message : 'Emit event failed';
            this.forwarder.publishTransportError(req.requestId, details);
            return of(new SendFailure({ requestId: req.requestId, error: details }));
          })
        );
      })
    );

  @Effect() loadInstitute$ = this.actions$
    .pipe(
      ofType<chatActions.LoadInstituteRequested>(chatActions.ActionTypes.LOAD_INSTITUTE_REQUESTED),
      mergeMap(() => {
        return this.institute.fetchInstituteInfo().pipe(
          map((info: InstituteInfo) => {
            this.instituteForwarder.publish(info);
            return new chatActions.SetStatus({ status: 'idle' });
          }),
          catchError((err) => {
            console.warn('[agent-chat] Unable to load institute info', err);
            return of(new chatActions.SetStatus({ status: 'idle' }));
          })
        );
      })
    );

  constructor(
    private actions$: Actions,
    private transport: ChatTransportAdapterService,
    private forwarder: ChatResponseForwarder,
    private history: CtBotConversationHistoryService,
    private ctBotHostService: CtBotHostService,
    private hostContextAdapter: HostContextAdapter,
    private router: Router,
    private institute: MockInstituteService,
    private instituteForwarder: InstituteInfoForwarder,
    private store: Store<rootReducer.State>,
    private ctApi: CTApi,
    private studentFormPrefillService: StudentFormPrefillService,
    private orgFormPrefillService: OrgFormPrefillService,
    private agentFileRunPort: AgentFileRunPort,
    private agentFileRunEventsSocket: AgentFileRunEventsSocket,
    @Inject(AGENT_FILE_RUN_CONFIG) private readonly fileRunConfig: AgentFileRunConfig
  ) {}

  private handleFormContinue(req: any, actionName: string) {
    const values = (req && req.values) || {};
    const isOrg = actionName.indexOf('org.add') === 0;
    if (isOrg) {
      this.orgFormPrefillService.setDraft(values);
    } else {
      this.studentFormPrefillService.setDraft(values);
    }
    this.forwarder.publishResponse(this.buildHostChatResponse(req, 'completed', [
      { type: 'text', text: 'Opened the full form with your entered values.' },
      this.formOutcomeSuggestions(isOrg)
    ]));
    return from([
      new chatActions.ClearActiveSurface(),
      new chatActions.NavigateRequested({ href: isOrg ? '/admin/org/add' : '/admin/student/add' }),
      new SendSuccess({ requestId: req.requestId })
    ]);
  }

  private persistStudentEnrol(req: any) {
    const values = (req && req.values) || {};
    return this.resolveEnrolCourses(values).pipe(
      catchError((err) => {
        const message = this.httpErrorMessage(err);
        this.forwarder.publishResponse(this.buildHostChatResponse(req, 'failed', [
          { type: 'error', message: message },
          this.formOutcomeSuggestions(false)
        ]));
        return of(new SendFailure({ requestId: req.requestId, error: message }));
      }),
      mergeMap((courses: any[]) => {
        const built = this.buildStudentEnrolPayload(values, courses || []);
        if (built.error) {
          this.forwarder.publishResponse(this.buildHostChatResponse(req, 'failed', [
            { type: 'error', message: built.error },
            this.formOutcomeSuggestions(false)
          ]));
          return of(new SendFailure({ requestId: req.requestId, error: built.error }));
        }
        return this.ctApi.enrolStudent(built.payload).pipe(
          mergeMap((res: any) => {
            if (!res) {
              const message = 'Student was not created.';
              this.forwarder.publishResponse(this.buildHostChatResponse(req, 'failed', [
                { type: 'error', message: message },
                this.formOutcomeSuggestions(false)
              ]));
              return of(new SendFailure({ requestId: req.requestId, error: message }));
            }
            this.ctApi.resetStuCache().subscribe(() => {}, () => {});
            this.store.dispatch(new studentAction.EnrolStudent({ student: res }));
            const name = this.toText(values.name);
            this.forwarder.publishResponse(this.buildHostChatResponse(req, 'completed', [
              { type: 'text', text: name ? ('Student ' + name + ' was created.') : 'Student was created.' },
              this.formOutcomeSuggestions(false)
            ]));
            // BW-T6: the chat claims success only here — the real API replied.
            // A buddy-workspace submit keeps the surface open: the workspace
            // saves valid records sequentially and other chips stay editable.
            // The thin enrol surface still closes after the save as today.
            return from(this.studentEnrolSettleActions(req));
          }),
          catchError((err) => {
            const message = this.httpErrorMessage(err);
            this.forwarder.publishResponse(this.buildHostChatResponse(req, 'failed', [
              { type: 'error', message: message },
              this.formOutcomeSuggestions(false)
            ]));
            return of(new SendFailure({ requestId: req.requestId, error: message }));
          })
        );
      })
    );
  }

  /**
   * BW-T6: success actions for a student-enrol submit. The buddy workspace
   * surface is identified by formId / correlationId (`student-enrol-buddy`,
   * `buddy_ws_*`) and stays open so Submit all valid can continue and other
   * chips stay editable; the thin enrol surface still closes as today. Never
   * claims success before this — the API replied `res` by the time we run.
   */
  private studentEnrolSettleActions(req: any): any[] {
    const actions: any[] = [];
    if (!this.isBuddyWorkspaceSubmit(req)) {
      actions.push(new chatActions.ClearActiveSurface());
    }
    actions.push(new SendSuccess({ requestId: req.requestId }));
    return actions;
  }

  private isBuddyWorkspaceSubmit(req: any): boolean {
    const formId = this.toText(req && req.formId).trim();
    const correlationId = this.toText(req && req.correlationId).trim();
    return formId.indexOf('buddy') >= 0 || correlationId.indexOf('buddy_ws_') === 0;
  }

  /**
   * Resolve the course list for an enrol submit without blocking on the
   * panel's local options: 1) a course object attached to the submit event,
   * 2) the NgRx course list, 3) the same GET /acad/course + SetCourses the
   * native add page uses, re-reading the store once. The caller fails only
   * if the selected id is still unresolvable afterwards.
   */
  private resolveEnrolCourses(values: any) {
    const courseId = this.toText(values && values.courseId).trim();
    if (!courseId) {
      return of([]);
    }
    const attached = values && values.course;
    if (attached && this.toText(attached.id).trim() === courseId) {
      return of([attached]);
    }
    return this.store.select(rootReducer.get_courses_for_students).pipe(
      take(1),
      mergeMap((courses: any[]) => {
        if ((courses || []).some((item) => item && String(item.id) === courseId)) {
          return of(courses || []);
        }
        return this.ctApi.getCourses().pipe(
          mergeMap((res: any) => {
            this.store.dispatch(new studentAction.SetCourses({ course_list: res }));
            return this.store.select(rootReducer.get_courses_for_students).pipe(take(1));
          })
        );
      })
    );
  }

  private persistOrgAdd(req: any) {
    const values = (req && req.values) || {};
    const name = this.toText(values.name);
    if (!name) {
      const message = 'Name is required.';
      this.forwarder.publishResponse(this.buildHostChatResponse(req, 'failed', [
        { type: 'error', message: message },
        this.formOutcomeSuggestions(true)
      ]));
      return of(new SendFailure({ requestId: req.requestId, error: message }));
    }
    const payload = {
      name: name,
      shortName: this.toText(values.shortName),
      parentId: this.toText(values.parentId),
      ownerId: this.toText(values.ownerId)
    };
    return this.ctApi.addOrg(payload).pipe(
      mergeMap((res: any) => {
        if (!res) {
          const message = 'Organization was not created.';
          this.forwarder.publishResponse(this.buildHostChatResponse(req, 'failed', [
            { type: 'error', message: message },
            this.formOutcomeSuggestions(true)
          ]));
          return of(new SendFailure({ requestId: req.requestId, error: message }));
        }
        this.forwarder.publishResponse(this.buildHostChatResponse(req, 'completed', [
          { type: 'text', text: 'Organization ' + name + ' was created.' },
          this.formOutcomeSuggestions(true)
        ]));
        return from([
          new chatActions.ClearActiveSurface(),
          new SendSuccess({ requestId: req.requestId })
        ]);
      }),
      catchError((err) => {
        const message = this.httpErrorMessage(err);
        this.forwarder.publishResponse(this.buildHostChatResponse(req, 'failed', [
          { type: 'error', message: message },
          this.formOutcomeSuggestions(true)
        ]));
        return of(new SendFailure({ requestId: req.requestId, error: message }));
      })
    );
  }

  private buildStudentEnrolPayload(values: any, courses: any[]): { payload?: any; error?: string } {
    const name = this.toText(values && values.name);
    const dobText = this.toText(values && values.dob);
    const gender = this.toText(values && values.gender);
    const courseId = this.toText(values && values.courseId);
    if (!name || !dobText || !gender || !courseId) {
      return { error: 'Name, date of birth, gender, and course are required.' };
    }
    const dob = this.toDateString(dobText);
    if (!dob) {
      return { error: 'Date of birth is invalid.' };
    }
    const course = (courses || []).find((item) => item && String(item.id) === courseId);
    if (!course || !course.id) {
      return { error: 'Selected course could not be resolved. Please re-open the form and pick the course again.' };
    }
    const doaText = this.toText(values && values.doa);
    // Match ut_save(): the DOA key is only sent when an admission date was entered;
    // a JSON null here makes the C# API throw a null reference.
    const parsedDoa = doaText ? this.toDateString(doaText) : null;
    return {
      payload: {
        Name: name,
        DOB: dob,
        Gender: gender,
        CourseName: course.name || null,
        AadharNumber: this.toText(values && values.aadharNo) || null,
        CourseId: course.id || null,
        StudentId: this.toText(values && values.studentId) || null,
        ...(parsedDoa ? { DOA: parsedDoa } : {}),
        Email: this.toText(values && values.email) || null,
        AdmissionNumber: this.toText(values && values.admissionNo) || null,
        ApplicationNumber: this.toText(values && values.applicationNo) || null,
        Mobile: this.toText(values && values.mobile) || null,
        SecName: course.secName,
        TermName: 'Annual',
        Branch: course.branch,
        UDID: this.toText(values && values.uDID) || '',
        FatherName: this.toText(values && values.fatherName),
        FatherEmail: this.toText(values && values.fatherEmail) || '',
        FatherMobile: this.toText(values && values.fatherMobile) || '',
        MotherName: this.toText(values && values.motherName) || '',
        MotherEmail: this.toText(values && values.motherEmail) || '',
        MotherMobile: this.toText(values && values.motherMobile) || '',
        Line1: '',
        Line2: '',
        City: '',
        Pincode: '',
        State: '',
        Country: '',
        FatherOccupationTitle: '',
        FatherOccupationParticulars: '',
        FatherOccupationAsOn: null,
        MotherOccupationTitle: '',
        MotherOccupationParticulars: '',
        MotherOccupationAsOn: null,
        FatherPAN: '',
        MotherPAN: ''
      }
    };
  }

  private toDateString(value: string): string | null {
    const text = this.toText(value).trim();
    if (!text) {
      return null;
    }
    const iso = /^(\d{4})-(\d{2})-(\d{2})/.exec(text);
    if (iso) {
      const parsed = new Date(Number(iso[1]), Number(iso[2]) - 1, Number(iso[3]));
      return isNaN(parsed.getTime()) ? null : parsed.toDateString();
    }
    const dmy = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(text);
    if (dmy) {
      const parsed = new Date(Number(dmy[3]), Number(dmy[2]) - 1, Number(dmy[1]));
      return isNaN(parsed.getTime()) ? null : parsed.toDateString();
    }
    const parsed = new Date(text);
    if (isNaN(parsed.getTime())) {
      return null;
    }
    return parsed.toDateString();
  }

  private httpErrorMessage(err: any): string {
    if (!err) {
      return 'Request failed.';
    }
    const body = err.error;
    let message = '';
    if (typeof body === 'string' && body.trim()) {
      message = body.trim();
    } else if (body && typeof body === 'object') {
      if (typeof body.message === 'string' && body.message.trim()) {
        message = body.message.trim();
      } else if (typeof body.error === 'string' && body.error.trim()) {
        message = body.error.trim();
      }
    } else if (typeof err.message === 'string' && err.message.trim()) {
      message = err.message.trim();
    }
    if (!message) {
      return 'Request failed.';
    }
    // Keep server/stack details out of the chat surface.
    if (/object reference not set|exception|stack trace|\bat system\.|\bat [A-Za-z0-9_.]+\(|\bnull\b/i.test(message)) {
      return 'Request failed. Please try again.';
    }
    return message;
  }

  private toText(value: any): string {
    if (value === null || value === undefined) {
      return '';
    }
    return String(value);
  }

  private formOutcomeSuggestions(isOrg: boolean): ChatBlock {
    const items = isOrg ? [
      { id: 'form_outcome_enrol', label: 'Enrol student', prompt: 'enrol student' },
      { id: 'form_outcome_fees', label: 'Open fees', prompt: 'open fees' },
      { id: 'form_outcome_institute', label: 'Institute info', prompt: 'institute info' }
    ] : [
      { id: 'form_outcome_org', label: 'Add organization', prompt: 'add organization' },
      { id: 'form_outcome_fees', label: 'Open fees', prompt: 'open fees' },
      { id: 'form_outcome_institute', label: 'Institute info', prompt: 'institute info' }
    ];
    return {
      type: 'suggestions',
      items: items.map((item) => ({
        id: item.id,
        label: item.label,
        action: {
          id: item.id + '_action',
          label: item.label,
          payload: { type: 'internal.prompt', prompt: item.prompt }
        }
      }))
    };
  }

  private buildHostChatResponse(req: any, status: 'completed' | 'failed', blocks: ChatBlock[]): ChatResponse {
    return {
      schemaVersion: '1.0.0',
      requestId: req.requestId,
      conversationId: req.conversationId,
      messageId: req.messageId || ('msg_' + Date.now()),
      parentMessageId: req.messageId,
      agent: { id: 'ct-bot-host', displayName: 'CT-Bot' },
      status: status,
      blocks: blocks
    };
  }
}

/** M8-T3/M9-T2 shared eligibility: thin-form data or buddy records. */
function surfaceHasSnapshotContent(surface: AgentSurface | null): boolean {
  const type = String(surface && surface.type || '');
  if (type === 'buddy-enrol-workspace') {
    return Array.isArray((surface as any).records) && (surface as any).records.length > 0;
  }
  if (type === 'student-enrol-form') {
    return Object.keys((surface as any).data || {}).length > 0;
  }
  return false;
}
