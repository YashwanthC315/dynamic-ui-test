import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { Router } from '@angular/router';
import { Store, StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { EMPTY, of } from 'rxjs';
import { take } from 'rxjs/operators';

import { CTApi } from '../../service/ct-api';
import { HostContextAdapter, CtHostContextAdapter } from '../services/host-context-adapter.service';
import { CtBotSessionTokenService } from '../services/ct-bot-session-token.service';
import { AgentFileRunPort, AGENT_FILE_RUN_CONFIG, HttpAgentFileRunPort } from '../services/agent-file-run.port';
import { AgentFileRunEventsSocket } from '../services/agent-file-run-events.socket';
import { ChatResponseForwarder } from '../services/chat-response-forwarder.service';
import { ChatTransportAdapterService } from '../services/chat-transport-adapter.service';
import { CtBotConversationHistoryService } from '../services/ct-bot-conversation-history.service';
import { CtBotHostService } from '../services/ct-bot-host.service';
import { MockInstituteService } from '../services/mock-institute.service';
import { InstituteInfoForwarder } from '../services/institute-info-forwarder.service';
import { StudentFormPrefillService } from '../../student/service/student-form-prefill.service';
import { OrgFormPrefillService } from '../../org/service/org-form-prefill.service';
import * as chatActions from './action.chat';
import * as fromAgentChat from './reducer.chat';
import { ChatEffects } from './effects.chat';

/**
 * M15-T8: LoadConversations stays an action; the effect no longer calls
 * the mock harness (http://localhost:8787 /v1/conversations) — the
 * file-run harness has no conversation-list route. The list select is
 * honestly empty; no request hits the mock base and no conversation is
 * invented from a run.
 */
const pub = { publishedResponses: [] as any[] };

describe('conversation list without the mock harness (M15-T8)', function () {
  let http: HttpTestingController;
  let store: Store<any>;
  let listConversationsSpy: jasmine.Spy;

  beforeEach(() => {
    pub.publishedResponses = [];
    listConversationsSpy = jasmine.createSpy('listConversations').and.returnValue(EMPTY);
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        StoreModule.forRoot({ agentChat: fromAgentChat.reducer }),
        EffectsModule.forRoot([ChatEffects])
      ],
      providers: [
        { provide: AGENT_FILE_RUN_CONFIG, useValue: {
          baseUrl: 'http://file-run-host.test',
          bearerToken: 'file-run-token',
          agentPath: 'agents/ct_main.exs',
          suggestionsAgentPath: 'agents/ct_suggestions.exs'
        } },
        { provide: AgentFileRunPort, useClass: HttpAgentFileRunPort },
        { provide: AgentFileRunEventsSocket, useValue: { open: () => EMPTY } },
        { provide: ChatTransportAdapterService, useValue: {} },
        { provide: ChatResponseForwarder, useValue: {
          publishResponse: (response: any) => { pub.publishedResponses.push(response); },
          publishTransportError: () => {}
        } },
        { provide: CtBotConversationHistoryService, useValue: { listConversations: listConversationsSpy } },
        { provide: CtBotHostService, useClass: CtBotHostService },
        { provide: HostContextAdapter, useClass: CtHostContextAdapter },
        { provide: CtHostContextAdapter, useClass: CtHostContextAdapter },
        { provide: Router, useValue: {} },
        { provide: MockInstituteService, useValue: {} },
        { provide: InstituteInfoForwarder, useValue: {} },
        { provide: CTApi, useValue: {} },
        { provide: StudentFormPrefillService, useValue: { setDraft: () => {} } },
        { provide: OrgFormPrefillService, useValue: { setDraft: () => {} } },
        { provide: CtBotSessionTokenService, useValue: { readAccessToken: () => 'session-token' } }
      ]
    });
    http = TestBed.get(HttpTestingController);
    store = TestBed.get(Store);
  });

  afterEach(() => {
    http.verify();
  });

  it('LoadConversations settles the list to empty WITHOUT calling the mock harness', function (done) {
    store.dispatch(new chatActions.LoadConversations({ restoreActive: false }));

    // no request may hit ANY http endpoint (the mock base included)
    const started = Date.now();
    const poll = () => {
      if (Date.now() - started > 400) {
        expect(listConversationsSpy).not.toHaveBeenCalled();
        expect(http.match(_ => true).length).toBe(0);
        done();
        return;
      }
      setTimeout(poll, 10);
    };
    poll();

    store
      .select((state: any) => state.agentChat.conversationList)
      .take(1)
      .subscribe((list: any[]) => {
        expect(list).toEqual([]);
      });
  });
});
