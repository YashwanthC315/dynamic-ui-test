import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { Router } from '@angular/router';
import { Store, StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { EMPTY } from 'rxjs';

import { CTApi } from '../../service/ct-api';
import { HostContextAdapter, CtHostContextAdapter } from '../services/host-context-adapter.service';
import { CtBotSessionTokenService } from '../services/ct-bot-session-token.service';
import { AgentFileRunPort, AGENT_FILE_RUN_CONFIG, HttpAgentFileRunPort } from '../services/agent-file-run.port';
import { AgentFileRunEventsSocket } from '../services/agent-file-run-events.socket';
import { ChatResponseForwarder } from '../services/chat-response-forwarder.service';
import { ChatTransportAdapterService } from '../services/chat-transport-adapter.service';
import { CtBotConversationHistoryService } from '../services/ct-bot-conversation-history.service';
import { CtBotHostService } from '../services/ct-bot-host.service';
import { MockInstituteService } from '../services/mock-institute.service';
import { InstituteInfoForwarder } from '../services/institute-info-forwarder.service';
import { StudentFormPrefillService } from '../../student/service/student-form-prefill.service';
import { OrgFormPrefillService } from '../../org/service/org-form-prefill.service';
import * as chatActions from './action.chat';
import * as fromAgentChat from './reducer.chat';
import { ChatEffects } from './effects.chat';

/**
 * M15-T7 follow-up: a chat reply whose body is the suggestions agent's
 * shape ({suggestions:[{label,text}]}) is CHIPS, not the reply text —
 * the bubble must not show that JSON. The reply effect maps it to a
 * suggestions block (chips for the same request) and starts NO second
 * chips run for it. No chip when the list is empty.
 */
const pub = { publishedResponses: [] as any[] };

describe('chips-shaped chat reply (M15-T7 follow-up)', function () {
  const RUNS_URL = 'http://file-run-host.test/api/playground/agent-file-runs';

  let http: HttpTestingController;
  let store: Store<any>;

  beforeEach(() => {
    pub.publishedResponses = [];
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        StoreModule.forRoot({ agentChat: fromAgentChat.reducer }),
        EffectsModule.forRoot([ChatEffects])
      ],
      providers: [
        { provide: AGENT_FILE_RUN_CONFIG, useValue: {
          baseUrl: 'http://file-run-host.test',
          bearerToken: 'file-run-token',
          agentPath: 'agents/ct_main.exs',
          suggestionsAgentPath: 'agents/ct_suggestions.exs'
        } },
        { provide: AgentFileRunPort, useClass: HttpAgentFileRunPort },
        { provide: AgentFileRunEventsSocket, useValue: { open: () => EMPTY } },
        { provide: ChatTransportAdapterService, useValue: {} },
        { provide: ChatResponseForwarder, useValue: {
          publishResponse: (response: any) => { pub.publishedResponses.push(response); },
          publishTransportError: () => {}
        } },
        { provide: CtBotConversationHistoryService, useValue: {} },
        { provide: CtBotHostService, useClass: CtBotHostService },
        { provide: HostContextAdapter, useClass: CtHostContextAdapter },
        { provide: CtHostContextAdapter, useClass: CtHostContextAdapter },
        { provide: Router, useValue: {} },
        { provide: MockInstituteService, useValue: {} },
        { provide: InstituteInfoForwarder, useValue: {} },
        { provide: CTApi, useValue: {} },
        { provide: StudentFormPrefillService, useValue: { setDraft: () => {} } },
        { provide: OrgFormPrefillService, useValue: { setDraft: () => {} } },
        { provide: CtBotSessionTokenService, useValue: { readAccessToken: () => 'session-token' } }
      ]
    });
    http = TestBed.get(HttpTestingController);
    store = TestBed.get(Store);
  });

  afterEach(() => {
    http.verify();
  });

  it('publishing {"suggestions":[...]} as the chat reply renders chips, not the JSON', () => {
    store.dispatch(new chatActions.AgentFileRunReply({
      conversationId: 'conv-1',
      rawResponse: '{"suggestions":[{"label":"Open Fees","text":"take me to fees"}]}',
      requestId: 'req-1',
      messageId: 'msg-1'
    }));

    expect(pub.publishedResponses.length).toBe(1);
    const response = pub.publishedResponses[0];
    expect(response.requestId).toBe('req-1');
    expect(response.blocks.length).toBe(1);
    expect(response.blocks[0].type).toBe('suggestions');
    expect(response.blocks[0].items.length).toBe(1);
    expect(response.blocks[0].items[0].label).toBe('Open Fees');
    expect(response.blocks[0].items[0].action.payload).toEqual({ type: 'internal.prompt', prompt: 'take me to fees' });
    // the bubble is not the JSON: no text block carries the raw payload
    expect(JSON.stringify(response.blocks)).not.toContain('"suggestions":[{');
  });

  it('a chips-shaped chat reply starts NO second chips run', function (done) {
    store.dispatch(new chatActions.AgentFileRunReply({
      conversationId: 'conv-2',
      rawResponse: '{"suggestions":[{"label":"Open Fees","text":"take me to fees"}]}',
      requestId: 'req-2',
      messageId: 'msg-2'
    }));

    const started = Date.now();
    const poll = () => {
      if (Date.now() - started > 400) {
        expect(http.match(RUNS_URL).length).toBe(0);
        done();
        return;
      }
      setTimeout(poll, 10);
    };
    poll();
  });

  it('an empty suggestions list is no chip (the standard empty-reply fallback shows, no invented chips)', () => {
    store.dispatch(new chatActions.AgentFileRunReply({
      conversationId: 'conv-3',
      rawResponse: '{"suggestions": []}',
      requestId: 'req-3',
      messageId: 'msg-3'
    }));

    const response = pub.publishedResponses[0];
    const suggestionsBlocks = response.blocks.filter((block: any) => block.type === 'suggestions');
    expect(suggestionsBlocks.length).toBe(0);
  });
});
