import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { Router } from '@angular/router';
import { Store, StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { EMPTY } from 'rxjs';
import { take, filter } from 'rxjs/operators';

import { CTApi } from '../../service/ct-api';
import { HostContextAdapter, CtHostContextAdapter } from '../services/host-context-adapter.service';
import { CtBotSessionTokenService } from '../services/ct-bot-session-token.service';
import { AgentFileRunPort, AGENT_FILE_RUN_CONFIG, HttpAgentFileRunPort } from '../services/agent-file-run.port';
import { AgentFileRunEventsSocket, AGENT_RUN_SOCKET_FACTORY, WebSocketAgentFileRunEventsSocket } from '../services/agent-file-run-events.socket';
import { ChatResponseForwarder } from '../services/chat-response-forwarder.service';
import { ChatTransportAdapterService } from '../services/chat-transport-adapter.service';
import { CtBotConversationHistoryService } from '../services/ct-bot-conversation-history.service';
import { CtBotHostService } from '../services/ct-bot-host.service';
import { MockInstituteService } from '../services/mock-institute.service';
import { InstituteInfoForwarder } from '../services/institute-info-forwarder.service';
import { StudentFormPrefillService } from '../../student/service/student-form-prefill.service';
import { OrgFormPrefillService } from '../../org/service/org-form-prefill.service';
import { suggestionsPayloadToMessages, suggestionsRunTurnText } from './effects.chat';
import * as chatActions from './action.chat';
import * as fromAgentChat from './reducer.chat';
import { ChatEffects } from './effects.chat';

/**
 * M15-T7: suggestion chips on ordinary turns. After a persisted assistant
 * reply is published, the reply effect starts a SECOND file run with the
 * suggestions agent path (host config, no system_prompt); the chips reply
 * merges onto the original blocks for the SAME requestId through the ONE
 * render path. No chips when the run returns none.
 */
class FakeRunSocket {
  static instances: FakeRunSocket[] = [];
  public url: string;
  public protocols: string[];
  public closed = false;
  public onmessage: ((message: MessageEvent) => void) | null = null;
  public onerror: ((event: any) => void) | null = null;
  public onclose: ((event: any) => void) | null = null;
  constructor(url: string, protocols: string[] = []) {
    this.url = url;
    this.protocols = protocols;
    FakeRunSocket.instances.push(this);
  }
  send(): void { throw new Error('client sent a frame — read-only socket violated'); }
  close(): void {
    this.closed = true;
    if (this.onclose) { this.onclose({ code: 1000 } as CloseEvent); }
  }
  emit(text: string): void {
    if (this.onmessage) { this.onmessage({ data: text } as MessageEvent); }
  }
}

const pub = {
  publishedResponses: [] as any[]
};

describe('suggestion chips runs (M15-T7)', function () {
  const CONFIG = {
    baseUrl: 'http://file-run-host.test',
    bearerToken: 'file-run-token',
    agentPath: 'agents/ct_main.exs',
    suggestionsAgentPath: 'agents/ct_suggestions.exs'
  };
  const RUNS_URL = 'http://file-run-host.test/api/playground/agent-file-runs';

  let http: HttpTestingController;
  let store: Store<any>;

  beforeEach(() => {
    pub.publishedResponses = [];
    FakeRunSocket.instances = [];
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        StoreModule.forRoot({ agentChat: fromAgentChat.reducer }),
        EffectsModule.forRoot([ChatEffects])
      ],
      providers: [
        { provide: AGENT_FILE_RUN_CONFIG, useValue: CONFIG },
        { provide: AgentFileRunPort, useClass: HttpAgentFileRunPort },
        { provide: AgentFileRunEventsSocket, useClass: WebSocketAgentFileRunEventsSocket },
        { provide: AGENT_RUN_SOCKET_FACTORY, useValue: ((url: string, protocols: string[]) => new FakeRunSocket(url, protocols)) as any },
        { provide: ChatTransportAdapterService, useValue: {} },
        { provide: ChatResponseForwarder, useValue: {
          publishResponse: (response: any) => { pub.publishedResponses.push(response); },
          publishTransportError: () => {}
        } },
        { provide: CtBotConversationHistoryService, useValue: {} },
        { provide: CtBotHostService, useClass: CtBotHostService },
        { provide: HostContextAdapter, useClass: CtHostContextAdapter },
        { provide: CtHostContextAdapter, useClass: CtHostContextAdapter },
        { provide: Router, useValue: {} },
        { provide: MockInstituteService, useValue: {} },
        { provide: InstituteInfoForwarder, useValue: {} },
        { provide: CTApi, useValue: {} },
        { provide: StudentFormPrefillService, useValue: { setDraft: () => {} } },
        { provide: OrgFormPrefillService, useValue: { setDraft: () => {} } },
        { provide: CtBotSessionTokenService, useValue: { readAccessToken: () => 'session-token' } }
      ]
    });
    http = TestBed.get(HttpTestingController);
    store = TestBed.get(Store);
  });

  afterEach(() => {
    http.verify();
  });

  function chatReplyJson(): string {
    return JSON.stringify({
      messages: [{ type: 'text', text: 'Opened Fees Transactions.' }],
      actions: []
    });
  }

  it('a published assistant reply starts a SECOND file run with the suggestions agent path (no system_prompt)', function (done) {
    store.dispatch(new chatActions.StartAgentFileRun({
      conversationId: 'conv-1',
      turnText: 'take me to fee transactions',
      history: [{ role: 'user', text: 'hello' }],
      context: { route: '/fees/transactions' } as any,
      requestId: 'req-1',
      messageId: 'msg-1'
    }));

    // main run POST + its label GET
    const mainReq = http.expectOne(RUNS_URL);
    expect(Object.keys(mainReq.request.body)).toEqual(['agent_path', 'user_prompt']);
    expect(mainReq.request.body['agent_path']).toBe('agents/ct_main.exs');
    mainReq.flush({ run_id: 'run-1' }, { status: 202, statusText: 'Accepted' });
    http.expectOne('http://file-run-host.test/api/playground/runs/run-1').flush({ label: '' }, { status: 200, statusText: 'OK' });

    // the chat reply publishes (threaded as the socket effect does); the
    // reply effect then starts the chips run
    store.dispatch(new chatActions.AgentFileRunReply({
      conversationId: 'conv-1',
      rawResponse: chatReplyJson(),
      requestId: 'req-1',
      messageId: 'msg-1',
      userText: 'take me to fee transactions',
      history: [{ role: 'user', text: 'hello' }],
      route: '/fees/transactions'
    }));

    const chipsReq = http.expectOne(RUNS_URL);
    expect(chipsReq.request.method).toBe('POST');
    expect(chipsReq.request.headers.get('Authorization')).toBe('Bearer file-run-token');
    expect(Object.keys(chipsReq.request.body)).toEqual(['agent_path', 'user_prompt']);
    expect(chipsReq.request.body['agent_path']).toBe('agents/ct_suggestions.exs');
    expect('system_prompt' in chipsReq.request.body).toBe(false);
    const chipsPrompt = JSON.parse(chipsReq.request.body['user_prompt']);
    expect(chipsPrompt.userText).toBe('take me to fee transactions');
    expect(chipsPrompt.lastAssistantText).toBe('Opened Fees Transactions.');
    expect(chipsPrompt.recentHistory.length).toBe(1);
    expect(chipsPrompt.route).toBe('/fees/transactions');
    chipsReq.flush({ run_id: 'run-2' }, { status: 202, statusText: 'Accepted' });
    // the suggestions run's label GET must NOT fire (byline stays the chat run's)
    http.verify();
    done();
  });

  it('the chips reply merges onto the original blocks for the SAME requestId (text + chips)', function (done) {
    store.dispatch(new chatActions.StartAgentFileRun({
      conversationId: 'conv-1',
      turnText: 'take me to fee transactions',
      context: { route: '/fees/transactions' } as any,
      requestId: 'req-1',
      messageId: 'msg-1'
    }));
    http.expectOne(RUNS_URL).flush({ run_id: 'run-1' }, { status: 202, statusText: 'Accepted' });
    http.expectOne('http://file-run-host.test/api/playground/runs/run-1').flush({}, { status: 200, statusText: 'OK' });

    store.dispatch(new chatActions.AgentFileRunReply({
      conversationId: 'conv-1',
      rawResponse: chatReplyJson(),
      requestId: 'req-1',
      messageId: 'msg-1',
      userText: 'take me to fee transactions',
      route: '/fees/transactions'
    }));
    const chipsReq = http.expectOne(RUNS_URL);
    chipsReq.flush({ run_id: 'run-2' }, { status: 202, statusText: 'Accepted' });

    // the chips run's socket delivers the suggestions reply
    const wait = () => {
      const sockets = FakeRunSocket.instances;
      const ws = sockets.length > 1 ? sockets[1] : null;
      if (!ws) { setTimeout(wait, 10); return; }
      ws.emit(JSON.stringify({
        kind: 'event', cursor: 'v1:1',
        event: { event_type: 'llm_responded', payload: JSON.stringify({
          response_type: 'text',
          raw_response: JSON.stringify({ suggestions: [
            { label: 'Collect fees', text: 'collect fees' },
            { label: 'Institute info', text: 'institute info' },
            { label: 'Add student', text: 'add student' }
          ] })
        }) }
      }));

      const waitPublish = () => {
        if (pub.publishedResponses.length >= 2) {
          // [0] = the chat reply, [1] = the chips reply merged for the SAME requestId
          const response = pub.publishedResponses[1];
          expect(response.requestId).toBe('req-1');
          expect(response.blocks.length).toBe(2);
          expect(response.blocks[0].type).toBe('text');
          expect(response.blocks[1].type).toBe('suggestions');
          expect(response.blocks[1].items.length).toBe(3);
          // items are mapped through the ONE existing suggestion-item mapper
          // (send_message -> internal.prompt payload), same as the mock path.
          expect(response.blocks[1].items[0].label).toBe('Collect fees');
          expect(response.blocks[1].items[0].action.payload).toEqual({ type: 'internal.prompt', prompt: 'collect fees' });
          done();
          return;
        }
        if (!ws.closed) { setTimeout(waitPublish, 10); return; }
        done.fail('chips never published');
      };
      waitPublish();
    };
    wait();
  });

  it('no chips when the suggestions run returns none', function (done) {
    pub.publishedResponses = [];
    store.dispatch(new chatActions.StartAgentFileRun({
      conversationId: 'conv-2',
      turnText: 'open fees',
      context: { route: '/home' } as any,
      requestId: 'req-3',
      messageId: 'msg-3'
    }));
    http.expectOne(RUNS_URL).flush({ run_id: 'run-3' }, { status: 202, statusText: 'Accepted' });
    http.expectOne('http://file-run-host.test/api/playground/runs/run-3').flush({}, { status: 200, statusText: 'OK' });

    store.dispatch(new chatActions.AgentFileRunReply({
      conversationId: 'conv-2',
      rawResponse: chatReplyJson(),
      requestId: 'req-3',
      messageId: 'msg-3',
      userText: 'open fees',
      route: '/home'
    }));
    const chipsReq = http.expectOne(RUNS_URL);
    chipsReq.flush({ run_id: 'run-4' }, { status: 202, statusText: 'Accepted' });

    const wait = () => {
      const sockets = FakeRunSocket.instances;
      const ws = sockets.length > 1 ? sockets[1] : null;
      if (!ws) { setTimeout(wait, 10); return; }
      // an empty suggestions reply
      ws.emit(JSON.stringify({
        kind: 'event', cursor: 'v1:1',
        event: { event_type: 'llm_responded', payload: JSON.stringify({ response_type: 'text', raw_response: '{"suggestions": []}' }) }
      }));
      setTimeout(() => {
        expect(pub.publishedResponses.length).toBe(1); // only the chat reply
        expect(pub.publishedResponses[0].blocks.length).toBe(1); // text only, no suggestions block
        done();
      }, 30);
    };
    wait();
  });

  it('helpers: suggestions payload mapping + turn text', () => {
    expect(suggestionsPayloadToMessages('{"suggestions":[{"label":"Open Fees","text":"open fees"}]}'))
      .toEqual([{ type: 'suggestions', items: [{ id: 'chip-1', label: 'Open Fees', action: 'send_message', payload: { text: 'open fees' } }] }]);
    expect(suggestionsPayloadToMessages('{"suggestions":[]}')).toEqual([]);
    expect(suggestionsPayloadToMessages('not json')).toEqual([]);
    expect(JSON.parse(suggestionsRunTurnText({ userText: 'u', lastAssistantText: 'a', recentHistory: [], route: '/home' })))
      .toEqual({ userText: 'u', lastAssistantText: 'a', recentHistory: [], route: '/home' });
  });
});
