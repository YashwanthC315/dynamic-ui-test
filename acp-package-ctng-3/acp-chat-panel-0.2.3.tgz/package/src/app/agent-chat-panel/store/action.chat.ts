import { Action } from '@ngrx/store';
import { type } from '../../util';
import { ChatBlock, ChatResponseStatus } from '../services/chat-contracts';
import { ConversationListItem } from '../services/ct-bot-conversation-history.service';
import { HostContextBag } from '../services/ct-bot-host-protocol';

export const ActionTypes = {
  SET_MESSAGES: type('[AgentChat] Set Messages'),
  SET_CONVERSATION_ID: type('[AgentChat] Set Conversation Id'),
  SET_CONVERSATION_LIST: type('[AgentChat] Set Conversation List'),
  SEND_REQUEST: type('[AgentChat] Send Request'),
  SEND_SUCCESS: type('[AgentChat] Send Success'),
  SEND_FAILURE: type('[AgentChat] Send Failure'),
  CANCEL_REQUEST: type('[AgentChat] Cancel Request'),
  CLEAR_ERROR: type('[AgentChat] Clear Error'),
  SET_ACTIVE_REQUEST_ID: type('[AgentChat] Set Active Request Id'),
  SET_STATUS: type('[AgentChat] Set Status'),
  LOAD_CONVERSATIONS: type('[AgentChat] Load Conversations'),
  LOAD_CONVERSATIONS_FAILURE: type('[AgentChat] Load Conversations Failure'),
  RESTORE_CONVERSATION: type('[AgentChat] Restore Conversation'),
  RESTORE_CONVERSATION_FAILURE: type('[AgentChat] Restore Conversation Failure'),
  CREATE_CONVERSATION: type('[AgentChat] Create Conversation'),
  CREATE_CONVERSATION_FAILURE: type('[AgentChat] Create Conversation Failure'),
  NAVIGATE_REQUESTED: type('[AgentChat] Navigate Requested'),
  EMIT_EVENT_REQUESTED: type('[AgentChat] Emit Event Requested'),
  LOAD_INSTITUTE_REQUESTED: type('[AgentChat] Load Institute Requested'),
  SURFACE_SET: type('[AgentChat] Set Active Surface'),
  SURFACE_CLEAR: type('[AgentChat] Clear Active Surface'),
  ACTIVITY_LOG_SET: type('[AgentChat] Set Activity Log'),
  ACTIVITY_LOG_APPEND: type('[AgentChat] Append Activity Item'),
  ACTIVITY_LOG_CLEAR: type('[AgentChat] Clear Activity Log'),
  LOAD_ACTIVITY_LOG: type('[AgentChat] Load Activity Log'),
  WORKSPACE_SNAPSHOT_PERSIST_REQUESTED: type('[AgentChat] Persist Workspace Snapshot Requested'),
  SET_RESTORED_WORKSPACE_SURFACE: type('[AgentChat] Set Restored Workspace Surface'),
  // M15-T1: agent file-run — one file-run per utterance. An action starts
  // the run; ChatEffects calls the port; the reducer stores run_id under
  // the conversationId; a select reads it. The port only POSTs.
  START_AGENT_FILE_RUN: type('[AgentChat] Start Agent File Run'),
  START_AGENT_FILE_RUN_SUCCESS: type('[AgentChat] Agent File Run Started'),
  // M15-T2: the file-run reply arrives on the read-only events socket;
  // a LATER text frame replaces the earlier one.
  AGENT_FILE_RUN_REPLY: type('[AgentChat] Agent File Run Reply'),
  // M15-T3: the run record's label becomes the message.agent byline;
  // absent label -> CT-Bot Assistant fallback.
  AGENT_FILE_RUN_LABEL: type('[AgentChat] Agent File Run Label'),
  // M15-T3: the file-run POST/context build failed — the panel settles
  // the turn via the same transportError path the mock socket used.
  AGENT_FILE_RUN_FAILED: type('[AgentChat] Agent File Run Failed')
};

export class SetMessages implements Action {
  type = ActionTypes.SET_MESSAGES;
  constructor(public payload: { messages: any[] }) {}
}

export class SetConversationId implements Action {
  type = ActionTypes.SET_CONVERSATION_ID;
  constructor(public payload: { conversationId: string | null }) {}
}

export class SetConversationList implements Action {
  type = ActionTypes.SET_CONVERSATION_LIST;
  constructor(public payload: { list: ConversationListItem[] }) {}
}

export class SendRequest implements Action {
  type = ActionTypes.SEND_REQUEST;
  constructor(public payload: { requestId: string; message?: any } ) {}
}

export class SendSuccess implements Action {
  type = ActionTypes.SEND_SUCCESS;
  constructor(public payload: { requestId: string; message?: any } ) {}
}

export class SendFailure implements Action {
  type = ActionTypes.SEND_FAILURE;
  constructor(public payload: { requestId: string; error: string }) {}
}

export class CancelRequest implements Action {
  type = ActionTypes.CANCEL_REQUEST;
  constructor(public payload: { requestId: string }) {}
}

export class ClearError implements Action {
  type = ActionTypes.CLEAR_ERROR;
  constructor(public payload: any = null) {}
}

export class SetActiveRequestId implements Action {
  type = ActionTypes.SET_ACTIVE_REQUEST_ID;
  constructor(public payload: { activeRequestId: string | null }) {}
}

export class SetStatus implements Action {
  type = ActionTypes.SET_STATUS;
  constructor(public payload: { status: 'idle' | 'inFlight' | 'error' }) {}
}

export class LoadConversations implements Action {
  type = ActionTypes.LOAD_CONVERSATIONS;
  constructor(public payload: { restoreActive: boolean }) {}
}

export class LoadConversationsFailure implements Action {
  type = ActionTypes.LOAD_CONVERSATIONS_FAILURE;
  constructor(public payload: { error: string }) {}
}

export class RestoreConversation implements Action {
  type = ActionTypes.RESTORE_CONVERSATION;
  constructor(public payload: { conversationId: string }) {}
}

export class RestoreConversationFailure implements Action {
  type = ActionTypes.RESTORE_CONVERSATION_FAILURE;
  constructor(public payload: { error: string }) {}
}

export class CreateConversation implements Action {
  type = ActionTypes.CREATE_CONVERSATION;
  constructor(public payload: { conversationId: string; title?: string }) {}
}

export class CreateConversationFailure implements Action {
  type = ActionTypes.CREATE_CONVERSATION_FAILURE;
  constructor(public payload: { error: string }) {}
}

export class NavigateRequested implements Action {
  type = ActionTypes.NAVIGATE_REQUESTED;
  constructor(public payload: { href: string; label?: string; messageId?: string } ) {}
}

export class EmitEventRequested implements Action {
  type = ActionTypes.EMIT_EVENT_REQUESTED;
  constructor(public payload: { eventRequest: any } ) {}
}

export class LoadInstituteRequested implements Action {
  type = ActionTypes.LOAD_INSTITUTE_REQUESTED;
  constructor(public payload: any = null) {}
}

// Surface actions
import { AgentSurface, ActivityLogSurface, ActivityItem } from '../services/surface-contracts';

export class SetActiveSurface implements Action {
  type = ActionTypes.SURFACE_SET;
  constructor(public payload: { surface: AgentSurface }) {}
}

export class ClearActiveSurface implements Action {
  type = ActionTypes.SURFACE_CLEAR;
  constructor(public payload: any = null) {}
}

// Activity log actions (P0-B1: store slice only)
export class SetActivityLog implements Action {
  type = ActionTypes.ACTIVITY_LOG_SET;
  constructor(public payload: { surface: ActivityLogSurface }) {}
}

export class AppendActivityItem implements Action {
  type = ActionTypes.ACTIVITY_LOG_APPEND;
  constructor(public payload: { item: ActivityItem; menuActions?: any; conversationId?: string }) {}
}

export class ClearActivityLog implements Action {
  type = ActionTypes.ACTIVITY_LOG_CLEAR;
  constructor(public payload: any = null) {}
}

// M9-T2: the panel only DISPATCHES — the effects own the harness REST I/O
// (activity-log persist/restore, workspace-snapshot persist/restore).
export class LoadActivityLog implements Action {
  type = ActionTypes.LOAD_ACTIVITY_LOG;
  constructor(public payload: { conversationId: string }) {}
}

export class PersistWorkspaceSnapshotRequested implements Action {
  type = ActionTypes.WORKSPACE_SNAPSHOT_PERSIST_REQUESTED;
  constructor(public payload: any = null) {}
}

export class SetRestoredWorkspaceSurface implements Action {
  type = ActionTypes.SET_RESTORED_WORKSPACE_SURFACE;
  constructor(public payload: { surface: AgentSurface | null }) {}
}

/** M15-T1: starts one agent file run. turnText is this turn (user prompt
 * or pasted buddy text); history + context ride the identical shapes the
 * websocket path already uses (M10-T1 history, HostContextBag). */
export class StartAgentFileRun implements Action {
  type = ActionTypes.START_AGENT_FILE_RUN;
  constructor(public payload: {
    conversationId: string;
    turnText: string;
    history?: Array<{ role: 'user' | 'assistant'; text: string }>;
    context?: HostContextBag;
    // M15-T3: panel request envelope — the reply is published as a
    // ChatResponse for THIS requestId, parentMessageId = messageId.
    requestId?: string;
    messageId?: string;
    // M15-T7: 'chat' (default) or 'suggestions' — the chips run started
    // by the reply effect; replies of suggestions runs never overwrite
    // the chat reply or re-trigger chips.
    purpose?: string;
    // M15-T7: per-run agent file (host config value, e.g. the
    // suggestions agent path); absent = the configured main agent file.
    agentPath?: string;
  }) {}
}

export class StartAgentFileRunSuccess implements Action {
  type = ActionTypes.START_AGENT_FILE_RUN_SUCCESS;
  constructor(public payload: {
    conversationId: string;
    runId: string;
    requestId?: string;
    messageId?: string;
    purpose?: string;
    // M15-T7: threaded so the reply publisher can compose the chips run
    // (userText / history / route of the moment the chat reply answered).
    userText?: string;
    history?: Array<{ role: 'user' | 'assistant'; text: string }>;
    route?: string;
  }) {}
}

/** M15-T2: one llm_responded/text reply for the conversation's current
 * file run. The reducer REPLACES the stored raw_response (later frame
 * wins); nothing else writes it. */
export class AgentFileRunReply implements Action {
  type = ActionTypes.AGENT_FILE_RUN_REPLY;
  constructor(public payload: {
    conversationId: string;
    rawResponse: string;
    requestId?: string;
    messageId?: string;
    purpose?: string;
    userText?: string;
    history?: Array<{ role: 'user' | 'assistant'; text: string }>;
    route?: string;
  }) {}
}

/** M15-T3: label from GET runs/{run_id} — copied onto message.agent. */
export class AgentFileRunLabel implements Action {
  type = ActionTypes.AGENT_FILE_RUN_LABEL;
  constructor(public payload: { conversationId: string; requestId?: string; label: string }) {}
}

/** M15-T3: the file-run POST/context build failed. */
export class AgentFileRunFailed implements Action {
  type = ActionTypes.AGENT_FILE_RUN_FAILED;
  constructor(public payload: { requestId: string; error: string; conversationId?: string; purpose?: string }) {}
}

export type Actions =
  | SetMessages
  | SetConversationId
  | SetConversationList
  | SendRequest
  | SendSuccess
  | SendFailure
  | CancelRequest
  | ClearError
  | SetActiveRequestId
  | SetStatus
  | LoadConversations
  | LoadConversationsFailure
  | RestoreConversation
  | RestoreConversationFailure
  | CreateConversation
  | CreateConversationFailure
  | NavigateRequested
  | EmitEventRequested
  | LoadInstituteRequested
  | SetActiveSurface
  | ClearActiveSurface
  | SetActivityLog
  | AppendActivityItem
  | ClearActivityLog
  | LoadActivityLog
  | PersistWorkspaceSnapshotRequested
  | SetRestoredWorkspaceSurface
  | StartAgentFileRun
  | StartAgentFileRunSuccess
  | AgentFileRunReply
  | AgentFileRunLabel
  | AgentFileRunFailed;
