import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Store, StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { take } from 'rxjs/operators';

import { CTApi } from '../../service/ct-api';
import { HostContextAdapter } from '../services/host-context-adapter.service';
import {
  AGENT_FILE_RUN_CONFIG,
  AgentFileRunPort,
  HttpAgentFileRunPort
} from '../services/agent-file-run.port';
import {
  AgentFileRunEventsSocket,
  AGENT_RUN_SOCKET_FACTORY,
  parseRunEventFrame,
  encodeBearerSubprotocol,
  WebSocketAgentFileRunEventsSocket
} from '../services/agent-file-run-events.socket';
import { ChatResponseForwarder } from '../services/chat-response-forwarder.service';
import { ChatTransportAdapterService } from '../services/chat-transport-adapter.service';
import { CtBotConversationHistoryService } from '../services/ct-bot-conversation-history.service';
import { CtBotHostService } from '../services/ct-bot-host.service';
import { MockInstituteService } from '../services/mock-institute.service';
import { InstituteInfoForwarder } from '../services/institute-info-forwarder.service';
import { StudentFormPrefillService } from '../../student/service/student-form-prefill.service';
import { OrgFormPrefillService } from '../../org/service/org-form-prefill.service';
import * as chatActions from './action.chat';
import * as fromAgentChat from './reducer.chat';
import { ChatEffects } from './effects.chat';

/**
 * M15-T2: after StartAgentFileRunSuccess the effect opens the run's
 * read-only events socket over a FAKE WebSocket factory, one text
 * llm_responded frame feeds the reply, the select reads the stored
 * raw_response, tool_call frames never land, and control stream_end
 * completes (and closes) the socket. No frame is ever sent.
 */
class FakeRunSocket {
  static instances: FakeRunSocket[] = [];
  public protocols: string[];
  public url: string;
  public sent: string[] = [];
  public closed = false;
  public onmessage: ((message: MessageEvent) => void) | null = null;
  public onerror: ((event: any) => void) | null = null;
  public onclose: ((event: any) => void) | null = null;

  constructor(url: string, protocols: string[] = []) {
    this.url = url;
    this.protocols = protocols;
    FakeRunSocket.instances.push(this);
  }

  send(data: string): void {
    // The real socket CLOSES if the client sends a frame; the fake throws
    // so the spec fails loudly if the client ever sends.
    this.sent.push(data);
    throw new Error('client sent a frame — read-only socket violated');
  }

  close(): void {
    this.closed = true;
    if (this.onclose) { this.onclose({ code: 1000 } as CloseEvent); }
  }

  emit(text: string): void {
    if (this.onmessage) { this.onmessage({ data: text } as MessageEvent); }
  }
}

describe('agent file-run events socket → reducer → select (M15-T2)', function () {
  const CONFIG = {
    baseUrl: 'http://file-run-host.test',
    bearerToken: 'file-run-token',
    agentPath: 'agents/ct_main.exs'
  };
  let FakeRunSocketRef: any;

  let store: Store<any>;

  beforeEach(() => {
    FakeRunSocket.instances = [];
    const factory = ((url: string, protocols: string[]) => new FakeRunSocket(url, protocols)) as any;
    FakeRunSocketRef = FakeRunSocket as any;
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        StoreModule.forRoot({ agentChat: fromAgentChat.reducer }),
        EffectsModule.forRoot([ChatEffects])
      ],
      providers: [
        { provide: AGENT_FILE_RUN_CONFIG, useValue: CONFIG },
        { provide: AgentFileRunPort, useClass: HttpAgentFileRunPort },
        { provide: AGENT_RUN_SOCKET_FACTORY, useValue: factory },
        { provide: AgentFileRunEventsSocket, useClass: WebSocketAgentFileRunEventsSocket },
        { provide: ChatTransportAdapterService, useValue: {} },
        { provide: ChatResponseForwarder, useValue: { publishResponse: () => {}, publishTransportError: () => {} } },
        { provide: CtBotConversationHistoryService, useValue: {} },
        { provide: CtBotHostService, useValue: {} },
        { provide: HostContextAdapter, useValue: {} },
        { provide: Router, useValue: {} },
        { provide: MockInstituteService, useValue: {} },
        { provide: InstituteInfoForwarder, useValue: {} },
        { provide: CTApi, useValue: {} },
        { provide: StudentFormPrefillService, useValue: { setDraft: () => {} } },
        { provide: OrgFormPrefillService, useValue: { setDraft: () => {} } }
      ]
    });
    store = TestBed.get(Store);
  });

  function replyOnce(conversationId: string, assert: (reply: string) => void): void {
    store
      .select((state: any) => fromAgentChat.get_agent_file_run_reply_for(state.agentChat, conversationId))
      .take(1)
      .subscribe(assert as any);
  }

  function textFrame(rawResponse: string): string {
    return JSON.stringify({
      kind: 'event',
      cursor: 'v1:3',
      event: {
        event_type: 'llm_responded',
        payload: JSON.stringify({ response_type: 'text', raw_response: rawResponse })
      }
    });
  }

  function toolCallFrame(): string {
    return JSON.stringify({
      kind: 'event',
      cursor: 'v1:4',
      event: {
        event_type: 'tool_call',
        payload: JSON.stringify({ tool: 'search', args: '{}' })
      }
    });
  }

  it('frame parser: keeps only llm_responded + response_type text; ignores the rest', function () {
    expect(parseRunEventFrame(textFrame('Hello from the run.')))
      .toEqual({ reply: 'Hello from the run.' });
    expect(parseRunEventFrame(toolCallFrame())).toEqual({});
    expect(parseRunEventFrame(JSON.stringify({
      kind: 'event', cursor: 'v1:5',
      event: { event_type: 'llm_responded', payload: JSON.stringify({ response_type: 'tool_call', raw_response: 'no' }) }
    }))).toEqual({});
    expect(parseRunEventFrame(JSON.stringify({ kind: 'control', control: 'stream_end' })))
      .toEqual({ end: true });
    expect(parseRunEventFrame('not-json')).toEqual({});
    expect(parseRunEventFrame(JSON.stringify({ kind: 'event', event: { event_type: 'llm_responded', payload: '{"broken"' } })))
      .toEqual({});
  });

  it('bearer subprotocol is the token as unpadded base64url', function () {
    expect(encodeBearerSubprotocol('file-run-token')).toBe(btoa('file-run-token').replace(/=+$/, ''));
    expect(encodeBearerSubprotocol('a+b/c===').indexOf('+')).toBe(-1);
    expect(encodeBearerSubprotocol('a+b/c===').indexOf('/')).toBe(-1);
    expect(encodeBearerSubprotocol('a+b/c===').endsWith('=')).toBe(false);
  });

  it('one text llm_responded frame → the select returns raw_response; tool_call does not; stream_end closes', function (done) {
    store.dispatch(new chatActions.StartAgentFileRunSuccess({ conversationId: 'conv-1', runId: 'run-1' }));

    const sockets = FakeRunSocket.instances;
    const openCall = setInterval(() => { /* wait for effect to open */ }, 0);
    clearInterval(openCall);
    const wait = () => {
      if (!sockets.length) {
        setTimeout(wait, 10);
        return;
      }
      const ws = sockets[sockets.length - 1];
      expect(ws.url).toBe('ws://file-run-host.test/api/playground/runs/run-1/events/ws');
      expect(ws.protocols[0]).toBe('aetheris.events.v1');
      expect(ws.protocols[1]).toBe('aetheris.bearer.' + btoa('file-run-token').replace(/=+$/, ''));

      // feed one text frame → the select returns that raw_response
      ws.emit(textFrame('Transactions: Anita R — ¥? no, 1500.'));

      replyOnce('conv-1', (reply: string) => {
        expect(reply).toBe('Transactions: Anita R — ¥? no, 1500.');

        // a tool_call frame does NOT change the reply
        ws.emit(toolCallFrame());
        replyOnce('conv-1', (unchanged: string) => {
          expect(unchanged).toBe('Transactions: Anita R — ¥? no, 1500.');

          // a later text frame REPLACES the earlier one
          ws.emit(textFrame('The two transactions in view: Anita R 1500, Ravi K 2500.'));
          replyOnce('conv-1', (replaced: string) => {
            expect(replaced).toBe('The two transactions in view: Anita R 1500, Ravi K 2500.');
            expect(ws.sent.length).toBe(0);

            // control stream_end ends the socket (completed + closed)
            ws.emit(JSON.stringify({ kind: 'control', control: 'stream_end' }));
            expect(ws.closed).toBe(true);
            done();
          });
        });
      });
    };
    wait();
  });

  it('non-text event types (spawn_agent/child runs) never reach the reducer', function (done) {
    store.dispatch(new chatActions.StartAgentFileRunSuccess({ conversationId: 'conv-2', runId: 'run-2' }));
    const wait = () => {
      const ws = FakeRunSocket.instances[FakeRunSocket.instances.length - 1];
      if (!ws) {
        setTimeout(wait, 10);
        return;
      }
      ws.emit(JSON.stringify({
        kind: 'event', cursor: 'v1:1',
        event: { event_type: 'spawn_agent', payload: JSON.stringify({ agent: 'parse' }) }
      }));
      replyOnce('conv-2', (reply: string) => {
        expect(reply).toBe('');
        done();
      });
    };
    wait();
  });
});
