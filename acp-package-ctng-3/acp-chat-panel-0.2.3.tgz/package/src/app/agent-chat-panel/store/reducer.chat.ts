import * as action from './action.chat';
import { ChatBlock, ChatResponseStatus } from '../services/chat-contracts';
import { ConversationListItem } from '../services/ct-bot-conversation-history.service';

export interface ConversationMessage {
  id: string;
  role: 'assistant' | 'user' | 'system' | 'error';
  blocks: ChatBlock[];
  timestamp: string;
  status?: ChatResponseStatus;
  requestId?: string;
  userMessageId?: string;
  agent?: { id?: string; name?: string } | null;
}

import { AgentSurface, ActivityLogSurface, ActivityItem } from '../services/surface-contracts';

export interface State {
  messages: ConversationMessage[];
  conversationId: string | null;
  conversationList: ConversationListItem[];
  status: 'idle' | 'inFlight' | 'error';
  activeRequestId: string | null;
  error: string | null;
  // currently shown dynamic surface (or null when none)
  activeSurface: AgentSurface | null;
  // P0-B1: activity log slice for the result/action panel (never persisted)
  activityLog: ActivityLogSurface | null;
  // M9-T2: restored enrol Workspace snapshot for the active conversation —
  // fetched by the effect on SET_CONVERSATION_ID (404 → null); the panel
  // SELECTs it for the fresh-empty reuse rule. Never auto-opened.
  restoredWorkspaceSurface: AgentSurface | null;

  // M15-T1: agent file-run ids, keyed by conversationId (oldest first).
  // Started by START_AGENT_FILE_RUN → ChatEffects → agent file-run port;
  // stored on START_AGENT_FILE_RUN_SUCCESS. Transient (not persisted).
  agentFileRunIds: { [conversationId: string]: string[] };

  // M15-T2: latest file-run reply (payload.raw_response of the last
  // llm_responded/text frame) under the conversationId. Later frames
  // REPLACE it; tool_call/spawn_agent/child frames never land here.
  agentFileRunReplies: { [conversationId: string]: string };

  // M15-T3: the run record's label (GET runs/{run_id}) — copied onto
  // message.agent by the reply publisher; absent label falls back to
  // CT-Bot Assistant.
  agentFileRunLabels: { [conversationId: string]: string };

  // M15-T6 follow-up: the courses list the host sent as
  // context.formOptions.courses for THIS conversation's current run —
  // copied onto a course select field whose options are missing/empty
  // when the reply surface is published. Never invented; a non-empty
  // agent-sent options list stays as the agent sent it.
  agentFileRunCourseOptions: { [conversationId: string]: Array<{ value: string; label: string }> };
}

const initialState: State = {
  messages: [],
  conversationId: null,
  conversationList: [],
  status: 'idle',
  activeRequestId: null,
  error: null,
  activeSurface: null,
  activityLog: null,
  restoredWorkspaceSurface: null,
  agentFileRunIds: {},
  agentFileRunReplies: {},
  agentFileRunLabels: {},
  agentFileRunCourseOptions: {}
};

export function reducer(state = initialState, act: action.Actions): State {
  switch (act.type) {
    case action.ActionTypes.SET_MESSAGES:
      return Object.assign({}, state, { messages: act.payload.messages });

    case action.ActionTypes.SET_CONVERSATION_ID:
      // M9-T2: a conversation switch drops the previous conversation's
      // restored snapshot immediately; the effect refetches for the new id.
      return Object.assign({}, state, {
        conversationId: act.payload.conversationId,
        restoredWorkspaceSurface: null
      });

    case action.ActionTypes.SET_CONVERSATION_LIST:
      return Object.assign({}, state, { conversationList: act.payload.list });

    // M15-T1: the file-run id lands in the store here — no effect-side
    // state, no private map.
    case action.ActionTypes.START_AGENT_FILE_RUN:
      return Object.assign({}, state, (() => {
        // M15-T6 follow-up: remember the courses list the host sent as
        // context.formOptions.courses for THIS conversation — the reply
        // publisher copies it onto an empty course select. Absent list
        // keeps the previous one (harmless: empty options stay empty).
        const courses = act.payload && act.payload.context
          && (act.payload.context as any).formOptions
          && (act.payload.context as any).formOptions['courses'];
        if (!Array.isArray(courses)) { return state; }
        const next = Object.assign({}, state.agentFileRunCourseOptions);
        next[act.payload.conversationId] = courses;
        return { agentFileRunCourseOptions: next };
      })());

    case action.ActionTypes.START_AGENT_FILE_RUN_SUCCESS:
      return Object.assign({}, state, {
        agentFileRunIds: Object.assign({}, state.agentFileRunIds, (() => {
          const next = Object.assign({}, state.agentFileRunIds);
          next[act.payload.conversationId] = (next[act.payload.conversationId] || []).concat(act.payload.runId);
          return next;
        })())
      });

    // M15-T2: the reply frame lands here — later text frames replace.
    // M15-T7: suggestions-run replies never overwrite the chat reply
    // (the chips publisher reads the CHAT reply from here).
    case action.ActionTypes.AGENT_FILE_RUN_REPLY:
      if (act.payload.purpose === 'suggestions') { return state; }
      return Object.assign({}, state, {
        agentFileRunReplies: Object.assign({}, state.agentFileRunReplies, (() => {
          const next = Object.assign({}, state.agentFileRunReplies);
          next[act.payload.conversationId] = act.payload.rawResponse;
          return next;
        })())
      });

    case action.ActionTypes.AGENT_FILE_RUN_LABEL:
      return Object.assign({}, state, (() => {
        if (!act.payload.label || !String(act.payload.label).trim()) {
          // absent label -> the publisher falls back to CT-Bot Assistant.
          return state;
        }
        const next = Object.assign({}, state.agentFileRunLabels);
        next[act.payload.conversationId] = String(act.payload.label).trim();
        return { agentFileRunLabels: next };
      })());

    // M15-T3: failures settle the panel turn through the transportError
    // path; nothing to store.
    case action.ActionTypes.AGENT_FILE_RUN_FAILED:
      return state;

    case action.ActionTypes.SEND_REQUEST:
      return Object.assign({}, state, { status: 'inFlight', activeRequestId: act.payload.requestId, error: null });

    case action.ActionTypes.SEND_SUCCESS:
      const maybeMessage = act.payload && act.payload.message ? [act.payload.message] : [];
      return Object.assign({}, state, { status: 'idle', activeRequestId: null, messages: state.messages.concat(maybeMessage) });

    case action.ActionTypes.SEND_FAILURE:
      return Object.assign({}, state, { status: 'error', activeRequestId: null, error: act.payload.error });

    case action.ActionTypes.CANCEL_REQUEST:
      return Object.assign({}, state, { status: 'idle', activeRequestId: null });

    case action.ActionTypes.CLEAR_ERROR:
      return Object.assign({}, state, { error: null });

    case action.ActionTypes.SET_ACTIVE_REQUEST_ID:
      return Object.assign({}, state, { activeRequestId: act.payload.activeRequestId });

    case action.ActionTypes.SET_STATUS:
      return Object.assign({}, state, { status: act.payload.status });

    case action.ActionTypes.SURFACE_SET:
      return Object.assign({}, state, { activeSurface: act.payload.surface });

    case action.ActionTypes.SURFACE_CLEAR:
      return Object.assign({}, state, { activeSurface: null });

    case action.ActionTypes.ACTIVITY_LOG_SET:
      return Object.assign({}, state, { activityLog: act.payload.surface });

    case action.ActionTypes.ACTIVITY_LOG_APPEND: {
      const item: ActivityItem = act.payload.item;
      const current = state.activityLog;
      let surface: ActivityLogSurface = current
        ? Object.assign({}, current, { items: current.items.concat([item]) })
        : { type: 'activity-log', items: [item] };
      // M8-T5: pin the owner — the conversationId this append belongs to
      // (the live conversation at save time), kept on the surface so the
      // persist write-back never uses a later active id.
      const pinnedConversationId = act.payload.conversationId
        || (current && current.conversationId)
        || undefined;
      if (pinnedConversationId) {
        surface = Object.assign({}, surface, { conversationId: pinnedConversationId });
      }
      // M5-T4: the payload may author the whole-pane overflow catalog —
      // attach it verbatim (even []); when omitted, keep the current one
      // (the host never stamps menuActions here).
      const menuActions = Array.isArray(act.payload.menuActions)
        ? act.payload.menuActions
        : (current && Array.isArray(current.menuActions) ? current.menuActions : undefined);
      if (menuActions !== undefined) {
        surface = Object.assign({}, surface, { menuActions });
      }
      return Object.assign({}, state, { activityLog: surface });
    }

    case action.ActionTypes.ACTIVITY_LOG_CLEAR:
      return Object.assign({}, state, { activityLog: null });

    case action.ActionTypes.SET_RESTORED_WORKSPACE_SURFACE:
      return Object.assign({}, state, { restoredWorkspaceSurface: act.payload.surface });

    default:
      return state;
  }
}

// selectors
export const get_messages = (state: State) => state.messages;
export const get_conversation_id = (state: State) => state.conversationId;
export const get_conversation_list = (state: State) => state.conversationList;
export const get_status = (state: State) => state.status;
export const get_active_request_id = (state: State) => state.activeRequestId;
export const get_error = (state: State) => state.error;
export const get_active_surface = (state: State) => state.activeSurface;
export const get_activity_log = (state: State) => state.activityLog;
export const get_restored_workspace_surface = (state: State) => state.restoredWorkspaceSurface;
// M15-T1: run ids under a conversation — a select reads them; nothing
// else writes them.
export const get_agent_file_run_ids = (state: State) => state.agentFileRunIds;
export const get_agent_file_run_ids_for = (state: State, conversationId: string) => state.agentFileRunIds[String(conversationId || '')] || [];
// M15-T2: the conversation's latest file-run reply — a select reads it.
export const get_agent_file_run_replies = (state: State) => state.agentFileRunReplies;
export const get_agent_file_run_reply_for = (state: State, conversationId: string) => state.agentFileRunReplies[String(conversationId || '')] || '';
// M15-T3: the run label under a conversation — the reply publisher reads
// it for the message.agent byline.
export const get_agent_file_run_labels = (state: State) => state.agentFileRunLabels;
export const get_agent_file_run_label_for = (state: State, conversationId: string) => state.agentFileRunLabels[String(conversationId || '')] || '';
// M15-T6 follow-up: the run's host-sent courses list under a conversation.
export const get_agent_file_run_course_options = (state: State) => state.agentFileRunCourseOptions;
export const get_agent_file_run_course_options_for = (state: State, conversationId: string) => state.agentFileRunCourseOptions[String(conversationId || '')] || [];
