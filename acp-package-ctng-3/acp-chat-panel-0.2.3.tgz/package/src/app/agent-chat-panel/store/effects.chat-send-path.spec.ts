import { TestBed, async } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { Router } from '@angular/router';
import { ActionsSubject, Store, StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { EMPTY, of } from 'rxjs';
import { filter } from 'rxjs/operators';
import { take } from 'rxjs/operators';

import { CTApi } from '../../service/ct-api';
import { HostContextAdapter, CtHostContextAdapter } from '../services/host-context-adapter.service';
import { CtBotSessionTokenService } from '../services/ct-bot-session-token.service';
import { AgentFileRunPort, AGENT_FILE_RUN_CONFIG, HttpAgentFileRunPort } from '../services/agent-file-run.port';
import { AgentFileRunEventsSocket } from '../services/agent-file-run-events.socket';
import { ChatResponseForwarder } from '../services/chat-response-forwarder.service';
import { ChatTransportAdapterService } from '../services/chat-transport-adapter.service';
import { CtBotConversationHistoryService } from '../services/ct-bot-conversation-history.service';
import { CtBotHostService } from '../services/ct-bot-host.service';
import { ChatRequest, ChatResponse } from '../services/chat-contracts';
import { selectRecordSurface } from '../components/agent-chat-panel.component';
import { MockInstituteService } from '../services/mock-institute.service';
import { InstituteInfoForwarder } from '../services/institute-info-forwarder.service';
import { StudentFormPrefillService } from '../../student/service/student-form-prefill.service';
import { OrgFormPrefillService } from '../../org/service/org-form-prefill.service';
import { stripCodeFence, salvageMessagesSentence, applyCourseOptionsToSurface } from './effects.chat';
import * as chatActions from './action.chat';
import * as fromAgentChat from './reducer.chat';
import { ChatEffects } from './effects.chat';

/**
 * M15-T3: the send path dispatches StartAgentFileRun instead of the mock
 * socket (fees + buddy-parse turns), the run record label becomes the
 * message.agent byline (fallback CT-Bot Assistant), and the reply is
 * parsed into the SAME render path the panel already uses — assistant
 * JSON feeds the existing renderer, plain text becomes one text block.
 */
const pub = {
  publishedResponses: [] as ChatResponse[],
  transportErrors: [] as Array<{ requestId: string; details: string }>
};

function makeChatRequest(prompt: string, history: any[] | undefined, requestId: string = 'req-1'): ChatRequest {
  return {
    schemaVersion: '1.0.0',
    requestId: requestId,
    conversationId: 'conv-1',
    messageId: 'msg-1',
    prompt: prompt,
    history: history,
    context: { app: {}, host: {}, catalog: { itemCount: 0 } } as any,
    client: { appId: 'test', appVersion: '1', locale: 'en' } as any
  };
}

describe('chat send path over agent file runs (M15-T3)', function () {
  const CONFIG = {
    baseUrl: 'http://file-run-host.test',
    bearerToken: 'file-run-token',
    agentPath: 'agents/ct_main.exs'
  };
  const RUNS_URL = 'http://file-run-host.test/api/playground/agent-file-runs';
  const RUN_LABEL_URL = (runId: string) =>
    'http://file-run-host.test/api/playground/runs/' + runId;

  let http: HttpTestingController;
  let store: Store<any>;
  const ENROL_RESULT: any = { id: 'stu-1' };
let transportSend: jasmine.Spy;
  let enrolStudentSpy: jasmine.Spy;
  let routerSpy: any;
  let transportEmit: jasmine.Spy;

  beforeEach(() => {
    pub.publishedResponses = [];
    pub.transportErrors = [];
    transportSend = jasmine.createSpy('transportSend').and.returnValue(EMPTY);
    transportEmit = jasmine.createSpy('transportEmitEvent').and.returnValue(EMPTY);
    routerSpy = jasmine.createSpyObj('Router', ['navigateByUrl']);
    enrolStudentSpy = jasmine.createSpy('enrolStudent').and.returnValue(of(ENROL_RESULT));
    routerSpy.navigateByUrl.and.returnValue(Promise.resolve());
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        StoreModule.forRoot({ agentChat: fromAgentChat.reducer }),
        EffectsModule.forRoot([ChatEffects])
      ],
      providers: [
        { provide: AGENT_FILE_RUN_CONFIG, useValue: CONFIG },
        { provide: AgentFileRunPort, useClass: HttpAgentFileRunPort },
        { provide: AgentFileRunEventsSocket, useValue: { open: () => EMPTY } },
        { provide: ChatTransportAdapterService, useValue: { send: transportSend, emitEvent: transportEmit } },
        { provide: ChatResponseForwarder, useValue: {
          publishResponse: (response: ChatResponse) => { pub.publishedResponses.push(response); },
          publishTransportError: (requestId: string, details: string) => { pub.transportErrors.push({ requestId, details }); }
        } },
        { provide: CtBotConversationHistoryService, useValue: {} },
        { provide: HostContextAdapter, useClass: CtHostContextAdapter },
        { provide: CtHostContextAdapter, useClass: CtHostContextAdapter },
        { provide: CtBotHostService, useClass: CtBotHostService },
        { provide: Router, useValue: routerSpy },
        { provide: MockInstituteService, useValue: {} },
        { provide: InstituteInfoForwarder, useValue: {} },
        { provide: CTApi, useValue: {
          enrolStudent: enrolStudentSpy,
          resetStuCache: () => ({ subscribe: () => {} })
        } },
        { provide: StudentFormPrefillService, useValue: { setDraft: () => {} } },
        { provide: OrgFormPrefillService, useValue: { setDraft: () => {} } },
        { provide: CtBotSessionTokenService, useValue: { readAccessToken: () => 'session-token' } }
      ]
    });
    http = TestBed.get(HttpTestingController);
    store = TestBed.get(Store);
  });

  afterEach(() => {
    http.verify();
  });

  function expectRunPost(runId: string, label: any, req: any): void {
    expect(req.request.method).toBe('POST');
    expect(req.request.headers.get('Authorization')).toBe('Bearer file-run-token');
    expect(Object.keys(req.request.body)).toEqual(['agent_path', 'user_prompt']);
    expect('system_prompt' in req.request.body).toBe(false);
    req.flush({ run_id: runId }, { status: 202, statusText: 'Accepted' });
    const labelWaitStart = Date.now();
    const pollLabel = () => {
      const matches = http.match(RUN_LABEL_URL(runId));
      if (matches.length) {
        matches[0].flush(label, { status: 200, statusText: 'OK' });
        return;
      }
      if (Date.now() - labelWaitStart > 2000) {
        return;
      }
      setTimeout(pollLabel, 10);
    };
    pollLabel();
  }

  function statusOnce(assert: (status: string) => void): void {
    store
      .select((state: any) => state.agentChat.status)
      .take(1)
      .subscribe(assert as any);
  }

  function waitAndRunUrl(timeoutMs: number, assertUrl: string, onReady: (req: any) => void, done: any): void {
    const started = Date.now();
    const poll = () => {
      const matches = http.match(assertUrl);
      if (matches.length) {
        onReady(matches[0]);
        return;
      }
      if (Date.now() - started > timeoutMs) {
        done.fail('request never appeared: ' + assertUrl);
        return;
      }
      setTimeout(poll, 10);
    };
    poll();
  }

  it('a fees turn dispatches StartAgentFileRun — the mock socket transport is NOT touched', function (done) {
    store.dispatch(new chatActions.SendRequest({ requestId: 'req-1', message: makeChatRequest('what can you see?', [
      { role: 'user', text: 'prior turn' }
    ]) }));

    waitAndRunUrl(2000, RUNS_URL, (req) => {
      const prompt: string = req.request.body['user_prompt'];
      expect(prompt.indexOf('what can you see?')).toBeGreaterThan(0);
      expect(prompt.indexOf('user: prior turn')).toBe(0);
      expect(prompt.indexOf('[host_context] ')).toBeGreaterThan(0);
      expect(req.request.body['agent_path']).toBe('agents/ct_main.exs');
      expectRunPost('run-fees-1', {}, req);

      expect(transportSend).not.toHaveBeenCalled();
      expect(transportEmit).not.toHaveBeenCalled();
      done();
    }, done);
  });

  it('a buddy-parse turn goes through the file-run channel, NOT the mock socket', function (done) {
    store.dispatch(new chatActions.EmitEventRequested({ eventRequest: {
      requestId: 'req-1',
      messageId: 'msg-2',
      conversationId: 'conv-1',
      event: 'buddy_parse',
      action: 'student.enrol.parse',
      values: { text: 'Anita Rao 01/02/2014 female PUC I' }
    } as any }));

    waitAndRunUrl(2000, RUNS_URL, (req) => {
      const prompt: string = req.request.body['user_prompt'];
      expect(prompt.indexOf('Anita Rao 01/02/2014 female PUC I')).toBeGreaterThan(0);
      expectRunPost('run-buddy-1', {}, req);

      expect(transportEmit).not.toHaveBeenCalled();
      expect(transportSend).not.toHaveBeenCalled();
      done();
    }, done);
  });

  it('Check (buddy_validate) runs through the file-run channel with EVERY record + the field list, NOT the mock socket', function (done) {
    store.dispatch(new chatActions.EmitEventRequested({ eventRequest: {
      requestId: 'req-1',
      messageId: 'msg-3',
      conversationId: 'conv-1',
      event: 'buddy_validate',
      action: 'student.enrol.validate',
      values: {
        fields: [{ id: 'name', label: 'Name', type: 'text', required: true }, { id: 'courseId', label: 'Course', type: 'select' }],
        records: [
          { id: 'b1', values: { name: 'Anita Rao', courseId: 'c1' } },
          { id: 'b2', values: { name: 'Ravi K', courseId: 'c2' } }
        ],
        surfaceId: 'surface_buddy_ws',
        activeRecordId: 'b1',
        buddyText: 'Anita Rao 01/02/2014 female PUC I',
        parse: { mapped: [], rejected: [] }
      }
    } as any }));

    waitAndRunUrl(2000, RUNS_URL, (req) => {
      expect(req.request.method).toBe('POST');
      expect(req.request.headers.get('Authorization')).toBe('Bearer file-run-token');
      expect(Object.keys(req.request.body)).toEqual(['agent_path', 'user_prompt']);
      expect('system_prompt' in req.request.body).toBe(false);
      const prompt: string = req.request.body['user_prompt'];
      expect(prompt.indexOf('[workspace fields] ')).toBeGreaterThan(0);
      expect(prompt.indexOf('[workspace records] ')).toBeGreaterThan(0);
      expect(prompt.indexOf('Anita Rao')).toBeGreaterThan(0);
      expect(prompt.indexOf('[active record id] b1')).toBeGreaterThan(0);
      expect(prompt.indexOf('Ravi K')).toBeGreaterThan(0);
      expect(prompt.indexOf('"name"')).toBeGreaterThan(0);
      expect(req.request.body['agent_path']).toBe('agents/ct_main.exs');
      expectRunPost('run-check-1', {}, req);

      expect(transportEmit).not.toHaveBeenCalled();
      expect(transportSend).not.toHaveBeenCalled();
      done();
    }, done);
  });

  it('a fenced surface echo publishes the surface for the existing mergeValidationEcho path', () => {
    const echo = {
      messages: [{ type: 'text', text: '' }],
      surface: {
        type: 'buddy-enrol-workspace',
        id: 'surface_buddy_ws',
        records: [
          { id: 'b1', valid: true, validationChecked: true, values: { name: 'Anita Rao' } },
          { id: 'b2', valid: false, validationChecked: true, validationReasons: ['Course is unresolved.'], values: { name: 'Ravi K' } }
        ],
        activeRecordId: 'b1'
      }
    };
    store.dispatch(new chatActions.AgentFileRunReply({
      conversationId: 'conv-1',
      rawResponse: '```json\n' + JSON.stringify(echo) + '\n```',
      requestId: 'req-1',
      messageId: 'msg-3'
    }));

    expect(pub.publishedResponses.length).toBe(1);
    const response: any = pub.publishedResponses[0];
    expect(response.surface).toBeTruthy();
    expect(response.surface.id).toBe('surface_buddy_ws');
    expect(response.surface.records.length).toBe(2);
    expect(response.surface.records[0].valid).toBe(true);
    expect(response.surface.records[1].valid).toBe(false);
    expect(response.surface.records[1].validationReasons[0]).toBe('Course is unresolved.');
    expect(response.requestId).toBe('req-1');
    expect(response.parentMessageId).toBe('msg-3');
  });

  it('a fenced Check reply whose JSON fails to parse still publishes its messages TEXT (verdict kept verbatim, no fence)', () => {
    store.dispatch(new chatActions.AgentFileRunReply({
      conversationId: 'conv-1',
      rawResponse: '```json\n\n{\n  "messages": [{ "type": "text", "text": "Anita Rao — valid (name/course/section)." }\n```',
      requestId: 'req-1',
      messageId: 'msg-3'
    }));

    expect(pub.publishedResponses.length).toBe(1);
    const response = pub.publishedResponses[0];
    expect(response.blocks.length).toBe(1);
    expect((response.blocks[0] as any).text).toBe('Anita Rao — valid (name/course/section).');
    expect(JSON.stringify(response.blocks).indexOf('```')).toBe(-1);
  });

  it('Submit active (buddy form_submit) persists through the effect: the save API runs, no mock socket, no file run', function (done) {
    enrolStudentSpy.calls.reset();
    store.dispatch(new chatActions.EmitEventRequested({ eventRequest: {
      requestId: 'req-1',
      messageId: 'msg-5',
      conversationId: 'conv-1',
      correlationId: 'surface_buddy_ws',
      event: 'form_submit',
      action: 'student.enrol.submit',
      formId: 'student-enrol-buddy',
      recordId: 'b1',
      values: { name: 'Anita Rao', dob: '01/02/2014', gender: 'Female', courseId: 'c1', course: { id: 'c1', name: 'PUC I', branch: 'Commerce', secName: 'A', fullName: 'PUC I Commerce A' } }
    } as any }));

    const started = Date.now();
    const poll = () => {
      if (enrolStudentSpy.calls.count() > 0) {
        expect(transportEmit).not.toHaveBeenCalled();
        expect(transportSend).not.toHaveBeenCalled();
        expect(http.match(RUNS_URL).length).toBe(0);
        // The save replied: the outcome is real, not agent-invented.
        expect(pub.publishedResponses.length).toBe(1);
        expect(pub.publishedResponses[0].status).toBe('completed');
        expect(JSON.stringify(pub.publishedResponses[0].blocks)).toContain('Student Anita Rao was created.');
        done();
        return;
      }
      if (Date.now() - started > 2000) {
        done.fail('the existing student-enrol save never ran');
        return;
      }
      setTimeout(poll, 10);
    };
    poll();
  });

  it('the post-save authoring hop does not fall through to the mock socket nor start a file run', function (done) {
    store.dispatch(new chatActions.EmitEventRequested({ eventRequest: {
      requestId: 'req-2',
      messageId: 'msg-6',
      conversationId: 'conv-1',
      correlationId: 'surface_buddy_ws',
      event: 'form_submit',
      action: 'student.enrol.submit',
      formId: 'student-enrol-buddy',
      recordId: 'b1',
      activityAuthoring: true,
      values: { name: 'Anita Rao', courseId: 'c1' }
    } as any }));

    const started = Date.now();
    const poll = () => {
      if (pub.transportErrors.length) {
        expect(pub.transportErrors[0].requestId).toBe('req-2');
        expect(transportEmit).not.toHaveBeenCalled();
        expect(transportSend).not.toHaveBeenCalled();
        expect(http.match(RUNS_URL).length).toBe(0);
        done();
        return;
      }
      if (Date.now() - started > 2000) {
        done.fail('authoring hop did not settle');
        return;
      }
      setTimeout(poll, 10);
    };
    poll();
  });

  it('the host-sent courses fill an EMPTY course field when the reply surface is applied; agent-sent options stay', () => {
    const hostCourses = [{ value: 'c1', label: 'PUC I Commerce A' }, { value: 'c2', label: 'PUC II Science B' }];

    // (a) reducer remembers the list the host sent on StartAgentFileRun.
    store.dispatch(new chatActions.StartAgentFileRun({
      conversationId: 'conv-1',
      turnText: 'enrol students from these notes',
      context: { route: '/home', formOptions: { courses: hostCourses } } as any,
      requestId: 'req-1',
      messageId: 'msg-1'
    }));
    // The action also starts the real run — flush its POST + label GET.
    const runReq = http.expectOne(RUNS_URL);
    runReq.flush({ run_id: 'run-opts-1' }, { status: 202, statusText: 'Accepted' });
    http.expectOne(RUN_LABEL_URL('run-opts-1')).flush({}, { status: 200, statusText: 'OK' });
    store
      .select((state: any) => fromAgentChat.get_agent_file_run_course_options_for(state.agentChat, 'conv-1'))
      .take(1)
      .subscribe((courses: any) => {
        expect(courses).toEqual(hostCourses);
      });

    // (b) the workspace surface's course field options were MISSING — the
    // reply surface gets the host list when it is applied.
    const surface: any = {
      type: 'buddy-enrol-workspace',
      id: 'surface_buddy_ws',
      fields: [
        { id: 'name', label: 'Name', type: 'text' },
        { id: 'courseId', label: 'Course', type: 'select', required: true, options: [] }
      ]
    };
    applyCourseOptionsToSurface(surface, hostCourses);
    const courseField = surface.fields.filter((f: any) => f.id === 'courseId')[0];
    expect(courseField.options).toEqual(hostCourses);
    // nothing invented elsewhere: gender stays untouched, name stays text
    expect(surface.fields[0].options).toBeUndefined();

    // (c) an agent-sent NON-empty options list stays as the agent sent it.
    const agentSurface: any = {
      type: 'buddy-enrol-workspace',
      id: 'surface_buddy_ws',
      fields: [
        { id: 'courseId', label: 'Course', type: 'select', required: true, options: [{ value: 'c9', label: 'Agent Picked Course' }] }
      ]
    };
    applyCourseOptionsToSurface(agentSurface, hostCourses);
    expect(agentSurface.fields[0].options).toEqual([{ value: 'c9', label: 'Agent Picked Course' }]);

    // (d) the thin enrol form path (schema.fields) is covered too.
    const thinSurface: any = {
      type: 'student-enrol-form',
      schema: { fields: [{ id: 'courseId', label: 'Course', type: 'select', required: true }] }
    };
    applyCourseOptionsToSurface(thinSurface, hostCourses);
    expect(thinSurface.schema.fields[0].options).toEqual(hostCourses);

    // (e) an empty host list invents nothing: the field keeps its empty
    // options.
    const emptyHost: any = { type: 'buddy-enrol-workspace', fields: [{ id: 'courseId', type: 'select', options: [] }] };
    applyCourseOptionsToSurface(emptyHost, []);
    expect(emptyHost.fields[0].options).toEqual([]);
  });

  it('a text-only Check reply publishes no surface — the mergeValidationEcho path never runs on a sentence', () => {
    pub.publishedResponses = [];
    store.dispatch(new chatActions.AgentFileRunReply({
      conversationId: 'conv-1',
      rawResponse: 'Anita Rao — valid (name/course/section).',
      requestId: 'req-1',
      messageId: 'msg-3'
    }));

    expect(pub.publishedResponses.length).toBe(1);
    const response: any = pub.publishedResponses[0];
    expect(response.blocks).toEqual([{ type: 'text', text: 'Anita Rao — valid (name/course/section).' } as any]);
    expect(response.surface).toBeUndefined();
  });

  it('record_selected emits nothing — no file run, no mock socket; row choice is host-local UI state', function (done) {
    store.dispatch(new chatActions.EmitEventRequested({ eventRequest: {
      requestId: 'req-1',
      messageId: 'msg-4',
      conversationId: 'conv-1',
      event: 'record_selected',
      action: 'student.enrol.select',
      values: { recordId: 'b2' }
    } as any }));

    // No lazy HTTP turn: neither the file-run POST nor the mock socket.
    const started = Date.now();
    const poll = () => {
      const runMatches = http.match(RUNS_URL);
      if (runMatches.length) {
        done.fail('record_selected started a file run — it must not');
        return;
      }
      if (transportEmit.calls.count() > 0 || transportSend.calls.count() > 0) {
        done.fail('record_selected reached the mock socket transport');
        return;
      }
      if (Date.now() - started > 400) {
        expect(transportEmit).not.toHaveBeenCalled();
        expect(transportSend).not.toHaveBeenCalled();
        done();
        return;
      }
      setTimeout(poll, 10);
    };
    poll();
  });

  it('record_selected set-active keeps the records: selecting the second row leaves both rows on the dispatched surface', () => {
    // The plugin-CLOSURE surface went stale after the parse rebind: its
    // records array is empty. The LIVE workspace surface holds both rows.
    const staleClosure = { type: 'buddy-enrol-workspace', id: 'surface_buddy_ws', records: [], activeRecordId: null };
    const liveSurface = {
      type: 'buddy-enrol-workspace',
      id: 'surface_buddy_ws',
      activeRecordId: 'b1',
      records: [
        { id: 'b1', values: { name: 'Anita Rao' } },
        { id: 'b2', values: { name: 'Ravi K' } }
      ]
    };
    const selected: any = selectRecordSurface(staleClosure as any, liveSurface as any, 'b2');
    expect(selected).toBeTruthy();
    expect(selected.activeRecordId).toBe('b2');
    expect(selected.records.length).toBe(2);
    expect(selected.records[0].values.name).toBe('Anita Rao');
    expect(selected.records[1].values.name).toBe('Ravi K');
    expect(selected.records[1].id).toBe('b2');
  });

  it('record_selected does not dispatch when the records array is missing or empty', () => {
    const emptyRecords = selectRecordSurface(
      { type: 'buddy-enrol-workspace', id: 'surface_buddy_ws', records: [] } as any,
      null as any,
      'b2'
    );
    expect(emptyRecords).toBeNull();
    const missingRecords = selectRecordSurface(
      { type: 'buddy-enrol-workspace', id: 'surface_buddy_ws' } as any,
      null as any,
      'b2'
    );
    expect(missingRecords).toBeNull();
    const noSelection = selectRecordSurface(
      { type: 'buddy-enrol-workspace', id: 'surface_buddy_ws', records: [{ id: 'b1' }] } as any,
      null as any,
      '   '
    );
    expect(noSelection).toBeNull();
  });

  it('assistant JSON reply follows the existing render path with the fallback byline', async(() => {
    const assistantJson = JSON.stringify({
      messages: [{ type: 'text', text: 'Columns: id, amount.' }],
      actions: []
    });
    store.dispatch(new chatActions.AgentFileRunReply({
      conversationId: 'conv-1',
      rawResponse: assistantJson,
      requestId: 'req-1',
      messageId: 'msg-1'
    }));

    expect(pub.publishedResponses.length).toBe(1);
    const response = pub.publishedResponses[0];
    expect(response.requestId).toBe('req-1');
    expect(response.conversationId).toBe('conv-1');
    expect(response.parentMessageId).toBe('msg-1');
    expect(response.agent.displayName).toBe('CT-Bot Assistant');
    expect(response.blocks.length).toBe(1);
    expect(response.blocks[0]).toEqual({ type: 'text', text: 'Columns: id, amount.' } as any);
    statusOnce((status: string) => expect(status).toBe('idle'));
  }));

  it('plain text reply renders as ONE text block through the same path', () => {
    store.dispatch(new chatActions.AgentFileRunReply({
      conversationId: 'conv-1',
      rawResponse: 'Plain reply from the agent.',
      requestId: 'req-1',
      messageId: 'msg-1'
    }));

    expect(pub.publishedResponses.length).toBe(1);
    const response = pub.publishedResponses[0];
    expect(response.blocks).toEqual([{ type: 'text', text: 'Plain reply from the agent.' } as any]);
    expect(response.agent.displayName).toBe('CT-Bot Assistant');
  });

  it('the run label is copied onto message.agent when present', () => {
    store.dispatch(new chatActions.AgentFileRunLabel({ conversationId: 'conv-1', requestId: 'req-1', label: 'Parse Agent' }));
    store.dispatch(new chatActions.AgentFileRunReply({
      conversationId: 'conv-1',
      rawResponse: 'Parsed 2 students.',
      requestId: 'req-1',
      messageId: 'msg-1'
    }));

    const response = pub.publishedResponses[0];
    expect(response.agent.displayName).toBe('Parse Agent');
    expect(response.agent.id).toBe('ct-bot-mock-harness');
  });

  it('a failed run settles the turn through the transportError path', function (done) {
    const baseline = pub.transportErrors.length;
    store.dispatch(new chatActions.SendRequest({ requestId: 'req-err', message: makeChatRequest('what can you see?', [], 'req-err') }));

    waitAndRunUrl(2000, RUNS_URL, (req) => {
      req.flush({ message: 'down' }, { status: 500, statusText: 'Server Error' });

      const started = Date.now();
      const poll = () => {
        const fresh = pub.transportErrors.slice(baseline);
        if (fresh.length) {
          expect(fresh[0].requestId).toBe('req-err');
          expect(pub.publishedResponses.length).toBe(0);
          statusOnce((status: string) => {
            expect(status).toBe('error');
            done();
          });
          return;
        }
        if (Date.now() - started > 2000) {
          done.fail('transportError never published');
          return;
        }
        setTimeout(poll, 10);
      };
      poll();
    }, done);
  });

  it('```json-fenced assistant JSON parses: text block + navigate action reach the render path', () => {
    const fenced = '```json\n' + JSON.stringify({
      messages: [{ type: 'text', text: 'Opening fee transactions.' }],
      actions: [{ type: 'navigate', route: '/fees/transactions' }]
    }) + '\n```';
    store.dispatch(new chatActions.AgentFileRunReply({
      conversationId: 'conv-1',
      rawResponse: fenced,
      requestId: 'req-1',
      messageId: 'msg-1'
    }));

    expect(pub.publishedResponses.length).toBe(1);
    const response = pub.publishedResponses[0];
    expect(response.blocks).toEqual([{ type: 'text', text: 'Opening fee transactions.' } as any]);
    expect(response.actions.length).toBe(1);
    expect(response.actions[0].payload).toEqual({ type: 'navigate', href: '/fees/transactions', target: 'internal' } as any);
  });

  it('unfenced assistant JSON and plain text behave unchanged', () => {
    store.dispatch(new chatActions.AgentFileRunReply({
      conversationId: 'conv-1',
      rawResponse: JSON.stringify({ messages: [{ type: 'text', text: 'Plain JSON.' }], actions: [] }),
      requestId: 'req-1',
      messageId: 'msg-1'
    }));
    expect(pub.publishedResponses[0].blocks[0]).toEqual({ type: 'text', text: 'Plain JSON.' } as any);

    store.dispatch(new chatActions.AgentFileRunReply({
      conversationId: 'conv-1',
      rawResponse: 'plain text stays one block',
      requestId: 'req-1',
      messageId: 'msg-1'
    }));
    expect(pub.publishedResponses[1].blocks).toEqual([{ type: 'text', text: 'plain text stays one block' } as any]);
  });

  it("the fenced fees reply's effect RETURNS NavigateRequested (href /fees) — navigate$ performs it", (done) => {
    const navigateActions: any[] = [];
    const actionsSub = TestBed.get(ActionsSubject);
    const streamSub = actionsSub.pipe(
      filter((action: any) => action.type === chatActions.ActionTypes.NAVIGATE_REQUESTED),
      take(1)
    ).subscribe((action: any) => {
      navigateActions.push(action);
    });

    const fenced = '```json\n' + JSON.stringify({
      messages: [{ type: 'text', text: 'Taking you to the Fees dashboard.' }],
      actions: [{ type: 'navigate', route: '/fees' }]
    }) + '\n```';
    store.dispatch(new chatActions.AgentFileRunReply({
      conversationId: 'conv-1',
      rawResponse: fenced,
      requestId: 'req-1',
      messageId: 'msg-1'
    }));

    const started = Date.now();
    const poll = () => {
      if (routerSpy.navigateByUrl.calls.count() > 0) {
        // The effect returned NavigateRequested (seen on the actions
        // stream), and the existing navigate$ effect called the router.
        expect(navigateActions.length).toBe(1);
        expect(navigateActions[0].payload).toEqual({ href: '/fees' });
        expect(routerSpy.navigateByUrl).toHaveBeenCalledWith('/fees');
        streamSub.unsubscribe();
        done();
        return;
      }
      if (Date.now() - started > 2000) {
        streamSub.unsubscribe();
        done.fail('NavigateRequested never reached navigate$');
        return;
      }
      setTimeout(poll, 10);
    };
    poll();
  });

  it('a fenced Check reply WITH blank lines inside/around the fence renders its text sentence (no fence)', () => {
    const verdict = 'Anita Rao is valid: name, course and section all matched.';
    const fencedWithBlanks = '\n\n```json\n\n' + JSON.stringify({
      messages: [{ type: 'text', text: verdict }],
      actions: []
    }) + '\n\n```';
    store.dispatch(new chatActions.AgentFileRunReply({
      conversationId: 'conv-1',
      rawResponse: fencedWithBlanks,
      requestId: 'req-1',
      messageId: 'msg-1'
    }));

    expect(pub.publishedResponses.length).toBe(1);
    const response = pub.publishedResponses[0];
    expect(response.blocks.length).toBe(1);
    expect((response.blocks[0] as any).text).toBe(verdict);
    expect(JSON.stringify(response.blocks).indexOf('```')).toBe(-1);
  });

  it('a fenced reply that is not assistant JSON stays ONE text block of the stripped sentence', () => {
    store.dispatch(new chatActions.AgentFileRunReply({
      conversationId: 'conv-1',
      rawResponse: '\n```json\n\nAnita Rao — valid (name/course/section).\n\n```',
      requestId: 'req-1',
      messageId: 'msg-1'
    }));

    expect(pub.publishedResponses.length).toBe(1);
    const response = pub.publishedResponses[0];
    expect(response.blocks).toEqual([{ type: 'text', text: 'Anita Rao — valid (name/course/section).' } as any]);
    expect(JSON.stringify(response.blocks).indexOf('```')).toBe(-1);
  });

  it('fence stripping edge cases: ```json and ``` both strip; plain text untouched', () => {
    const fencedJson = '```json\n{"messages":[{"type":"text","text":"from json fence"}],"actions":[]}\n```';
    const strippedJson = stripCodeFence(fencedJson);
    expect(strippedJson.indexOf('```')).toBe(-1);
    expect(JSON.parse(strippedJson).messages[0].text).toBe('from json fence');
    expect(stripCodeFence('plain reply stays')).toBe('plain reply stays');
    expect(JSON.parse(stripCodeFence('   ```json\n{"a":1}\n```   '))).toEqual({ 'a': 1 });
    expect(stripCodeFence('```\nno language cue\n```').indexOf('no language cue')).toBeGreaterThan(-1);
  });
});