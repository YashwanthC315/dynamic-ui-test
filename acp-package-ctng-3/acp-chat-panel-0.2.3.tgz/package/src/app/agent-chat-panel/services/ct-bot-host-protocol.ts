export const hostProtocolVersion: '1.0' = '1.0';

/** M5-T4: harness-authored Actions catalog for a settled form_submit
 * (enroll saves). Both fields are payload-driven — when present (even
 * actions: []), the host renders exactly that; when omitted, the host
 * keeps its demo fallback. Shapes reuse the shared contracts. */
export interface HarnessSaveActivity {
  item?: import('./surface-contracts').ActivityItem;
  menuActions?: import('./surface-contracts').ActivityAction[];
}

export type HostProtocolCapability =
  | 'text'
  | 'markdown'
  | 'suggestions'
  | 'link'
  | 'form'
  | 'confirmation'
  | 'navigate'
  | 'change_state';

export const hostProtocolCapabilities: HostProtocolCapability[] = [
  'text',
  'markdown',
  'suggestions',
  'link',
  'form',
  'confirmation',
  'navigate',
  'change_state'
];

export type HostBlockType = 'text' | 'markdown' | 'suggestions' | 'link' | 'form' | 'confirmation';
export type HostActionType = 'navigate' | 'change_state';

export interface HostContextFocus {
  type: 'student' | 'applicant' | 'other' | null;
  id?: string;
  label?: string;
}

export interface HostContextFlags {
  underFees?: boolean;
}

export interface HostModuleFlags {
  underFees: boolean;
  underConnect: boolean;
  underStudent: boolean;
}

export interface HostViewSnapshot {
  /** M14-T4: rows-style fields are filled by a 'rows' brick; a view bag
   * may be extras-only (summary/chart/wizard) with all of them absent. */
  module?: string;
  screen?: string;
  title?: string;
  source?: string;
  filters?: Record<string, unknown>;
  columns?: string[];
  rows?: Array<Record<string, unknown>>;
  rowCount?: number;
  truncated?: boolean;
  maxRows?: number;
  /** M14-T4: bounded store-backed extras — summary?: {label,value}[]
   * (max 12), chart?: {title?,kind?,series?}, wizard?: scalar map
   * (max 12 keys). Omitted when the select is empty; never invented. */
  [key: string]: unknown;
}

export interface HostContextBag {
  route: string;
  persona?: string;
  focus?: HostContextFocus | null;
  moduleFlags?: HostModuleFlags;
  flags?: HostContextFlags;
  /** M11-T3: bounded summary of the OPEN workspace surface (no records
   * blob, no form field dump) — omitted when no surface is open. */
  surface?: HostSurfaceSummary;
  /** M11-T3: bounded summary of the Actions log — count + last line only;
   * omitted when the log is empty or missing. */
  activity?: HostActivitySummary;
  view?: HostViewSnapshot;
  [key: string]: unknown;
}

/** M11-T3: pane summary — counts/ids derived from the store's surface;
 * no records blob, no institute data, no form fields. */
export interface HostSurfaceSummary {
  type: string;
  title?: string;
  id?: string;
  recordCount?: number;
  activeRecordId?: string;
  /** M11-T5b: human display label of the active record, resolved by the
   * host from the records already on the surface — printed instead of
   * the raw id. Never a records[] blob. */
  activeRecordLabel?: string;
  /** M11-T6: generic bounded preview — key/label + short value pairs
   * from data / schema fields / short record labels. Max ~12 entries;
   * never the full records array, raw formOptions, or nested blobs. */
  preview?: Array<{ label: string; value: string }>;
}

/** D-detour: Assembler summary — itemCount, the last line's kind/text,
 * and the items' save-time payloads (bounded) for draft composition.
 * Wire key: context.assembler (context.activity kept as a one-release
 * fallback read). */
export interface HostActivitySummary {
  itemCount: number;
  lastKind?: string;
  /** M12: bounded item payloads authored at save (e.g. name/course/dob).
   * Pass-through of what the store already holds. */
  payloads?: Array<Record<string, unknown>>;
  lastText?: string;
}

export interface HostHello {
  type: 'hello';
  hostProtocolVersion: typeof hostProtocolVersion;
  capabilities?: HostProtocolCapability[];
}

export interface HostUserMessage {
  type: 'user_message';
  conversationId?: string;
  messageId?: string;
  text: string;
  /**
   * M10-T1: prior turns of THIS conversation for follow-up context —
   * `{ role: 'user' | 'assistant', text }[]` in chronological order, oldest
   * first. Texts only (joined text/markdown blocks of completed replies);
   * EXCLUDES the current prompt (which stays in `text`), intro/system
   * bubbles, error bubbles, in-flight placeholders, and any block payloads
   * or context — never invent turns.
   */
  history?: Array<{ role: 'user' | 'assistant'; text: string }>;
  context?: HostContextBag;
}

export interface HostEmitEvent {
  type: 'emit_event';
  conversationId?: string;
  correlationId?: string | null;
  event: string;
  action?: string;
  values?: Record<string, unknown>;
  /** M5-T4: buddy-workspace chip id — the harness authors the per-row
   * catalog (Focus + Copy names) for THAT saved student. */
  recordId?: string;
  /** D6.4-fix: the open workspace fields (ids + order) from the store
   * surface, sent on buddy_parse / student.enrol.parse so the parse hop
   * keeps the field list. */
  fields?: Array<{ id: string; label?: string; type?: string; required?: boolean }>;
  context?: HostContextBag;
}

export interface HostContextResponse {
  type: 'context_response';
  conversationId?: string;
  correlationId?: string | null;
  values?: Record<string, unknown>;
}

export type HostToHarnessMessage =
  | HostHello
  | HostUserMessage
  | HostEmitEvent
  | HostContextResponse;

export interface AssistantTextBlock {
  type: 'text';
  text: string;
}

export interface AssistantMarkdownBlock {
  type: 'markdown';
  markdown: string;
}

/** In-thread form only (text | number | select). Student-enrol M3 uses response.surface, not this block. */
export interface AssistantFormBlock {
  type: 'form';
  formId: string;
  title?: string;
  submitAction: string;
  correlationId: string;
  fields: Array<{
    id: string;
    type: 'text' | 'number' | 'select';
    label: string;
    required?: boolean;
    options?: Array<{ value: string; label: string }>;
  }>;
}

export interface AssistantSuggestionsBlock {
  type: 'suggestions';
  id?: string;
  items: Array<{
    id: string;
    label: string;
    action: 'send_message' | 'navigate' | string;
    payload?: Record<string, unknown>;
  }>;
}

export interface AssistantLinkBlock {
  type: 'link';
  id?: string;
  label: string;
  href: string;
  target?: 'internal' | 'external';
}

export interface AssistantConfirmationBlock {
  type: 'confirmation';
  text: string;
  confirmAction: string;
  cancelAction: string;
  correlationId: string;
}

export type AssistantMessageBlock =
  | AssistantTextBlock
  | AssistantMarkdownBlock
  | AssistantSuggestionsBlock
  | AssistantLinkBlock
  | AssistantFormBlock
  | AssistantConfirmationBlock;

export interface NavigateAction {
  type: 'navigate';
  route: string;
}

export interface ChangeStateAction {
  type: 'change_state';
  patch: Record<string, unknown>;
}

export type AssistantAction = NavigateAction | ChangeStateAction;

/** Optional byline for assistant responses (e.g. parse agent vs CT-Bot). */
export interface HostResponseAgent {
  id: string;
  displayName?: string;
}

export interface HarnessAssistantResponse {
  type: 'assistant_response';
  conversationId: string;
  correlationId: string | null;
  hostProtocolVersion: typeof hostProtocolVersion;
  messages: AssistantMessageBlock[];
  actions: AssistantAction[];
  /** Prefer AgentSurface (see surface-contracts). Student enrol: type student-enrol-form + schema.fields. */
  surface?: Record<string, unknown>;
  /** M5-T4: harness-authored Actions catalog for a settled form_submit. */
  activity?: HarnessSaveActivity;
  /** Optional agent byline; host falls back to CT-Bot Assistant when omitted. */
  agent?: HostResponseAgent;
}

export interface HarnessErrorResponse {
  type: 'error';
  conversationId: string;
  code: 'bad_request' | 'unsupported_type' | 'configuration_error' | 'internal_error';
  message: string;
}

export type HarnessToHostMessage = HarnessAssistantResponse | HarnessErrorResponse;
