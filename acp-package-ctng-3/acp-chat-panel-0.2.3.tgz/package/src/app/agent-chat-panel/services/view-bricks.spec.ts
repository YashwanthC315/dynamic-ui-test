import { buildContextFocusFromBricks, buildFormOptionsFromBricks, buildViewSnapshotFromBricks, resolveFormOptionsFromBricks, routeMatchesBrick, ViewBrick } from './view-bricks';

describe('view-bricks orchestrator (M14-T1)', function () {

  function rowsBrick(overrides?: Partial<ViewBrick>): ViewBrick {
    return Object.assign({
      kind: 'rows',
      routePattern: '/demo/list',
      module: 'demo',
      screen: 'list',
      title: 'Demo List',
      source: 'store.demo.list',
      select: (state: any) => state && state.demo ? state.demo.list : null
    } as ViewBrick, overrides || {});
  }

  it('returns null (omit context.view) when no brick matches the route', function () {
    const bricks = [rowsBrick()];
    expect(buildViewSnapshotFromBricks(bricks, {}, '/other/screen')).toBeNull();
    expect(buildViewSnapshotFromBricks(null, {}, '/demo/list')).toBeNull();
  });

  it('matches routePattern as a prefix, case-insensitive', function () {
    expect(routeMatchesBrick('/demo/list', '/demo/list')).toBe(true);
    expect(routeMatchesBrick('/demo/list', '/demo/list/extra')).toBe(true);
    expect(routeMatchesBrick('/demo/list', '/DEMO/LIST')).toBe(true);
    expect(routeMatchesBrick('/demo/list', '/demo')).toBe(false);
    expect(routeMatchesBrick('/demo/list', '/x/demo/list')).toBe(false);
  });

  it('serializes rows with the pre-T1 bounds: 30 cap, scalars only, 160-char strings, Date→ISO', function () {
    const rawRows: any[] = [];
    for (let i = 0; i < 35; i++) {
      rawRows.push({ id: 'r' + i, name: '  Row ' + i + '  ', amount: i * 10, ok: i % 2 === 0, when: new Date(Date.UTC(2026, 0, i + 1)), blob: { nested: true }, empty: '   ' });
    }
    rawRows[0].longText = new Array(200).join('x');
    const snapshot = buildViewSnapshotFromBricks([rowsBrick()], { demo: { list: rawRows } }, '/demo/list');
    expect(snapshot).not.toBeNull();
    expect(snapshot!.maxRows).toBe(30);
    expect(snapshot!.rows.length).toBe(30);
    expect(snapshot!.rowCount).toBe(35);
    expect(snapshot!.truncated).toBe(true);
    const first: any = snapshot!.rows[0];
    expect(first['id']).toBe('r0');
    expect(first['name']).toBe('Row 0');
    expect(first['when']).toBe('2026-01-01T00:00:00.000Z');
    expect('blob' in first).toBe(false);
    expect('empty' in first).toBe(false);
    expect(first['longText']).toBe(new Array(161).join('x') + '...');
    expect(snapshot!.columns).toEqual(['id', 'name', 'amount', 'ok', 'when', 'longText']);
  });

  it('ships an empty rows snapshot when the selected slice is empty or null (list owner route)', function () {
    const bricks = [rowsBrick()];
    const empty = buildViewSnapshotFromBricks(bricks, { demo: { list: [] } }, '/demo/list');
    expect(empty).not.toBeNull();
    expect(empty!.rows).toEqual([]);
    expect(empty!.columns).toEqual([]);
    expect(empty!.rowCount).toBe(0);
    expect(empty!.truncated).toBe(false);
    const missing = buildViewSnapshotFromBricks(bricks, { demo: {} }, '/demo/list');
    expect(missing).not.toBeNull();
    expect(missing!.rows).toEqual([]);
  });

  it('omits filters when the filters brick yields no keys', function () {
    const filters: ViewBrick = {
      kind: 'filters',
      routePattern: '/demo/list',
      module: 'demo',
      select: (state: any) => (state && state.demo && state.demo.query ? { query: state.demo.query } : {})
    };
    const withQuery = buildViewSnapshotFromBricks([rowsBrick(), filters], { demo: { list: [], query: 'a' } }, '/demo/list');
    expect(withQuery!.filters).toEqual({ query: 'a' });
    const withoutQuery = buildViewSnapshotFromBricks([rowsBrick(), filters], { demo: { list: [] } }, '/demo/list');
    expect(withoutQuery!.filters).toBeUndefined();
    expect('filters' in (withoutQuery as any)).toBe(false);
  });

  it('filters-only brick with empty result omits context.view entirely', function () {
    const filters: ViewBrick = {
      kind: 'filters',
      routePattern: '/demo/list',
      select: () => ({})
    };
    expect(buildViewSnapshotFromBricks([filters], {}, '/demo/list')).toBeNull();
  });

  it('first matching brick per (kind, module) wins', function () {
    const first = rowsBrick({ title: 'First' });
    const second = rowsBrick({ title: 'Second' });
    const snapshot = buildViewSnapshotFromBricks([first, second], { demo: { list: [] } }, '/demo/list');
    expect(snapshot!.title).toBe('First');
  });

  it('a brick whose select throws is treated as absent, not fatal', function () {
    const broken: ViewBrick = rowsBrick({ select: () => { throw new Error('boom'); } });
    const snapshot = buildViewSnapshotFromBricks([broken], {}, '/demo/list');
    expect(snapshot).not.toBeNull();
    expect(snapshot!.rows).toEqual([]);
  });

  it('resolves screen/title from functions and source from raw rows length', function () {
    const brick = rowsBrick({
      screen: (route: string) => (route === '/demo/list' ? 'list' : 'other'),
      title: () => 'T',
      source: (rawRows: any[]) => (rawRows.length ? 'store.demo.list' : 'store.demo')
    });
    const filled = buildViewSnapshotFromBricks([brick], { demo: { list: [{ id: 'a' }] } }, '/demo/list');
    expect(filled!.screen).toBe('list');
    expect(filled!.source).toBe('store.demo.list');
    const empty = buildViewSnapshotFromBricks([brick], { demo: { list: [] } }, '/demo/list');
    expect(empty!.source).toBe('store.demo');
  });
});

describe('view-bricks focus (M14-T2)', function () {
  function focusBrick(overrides?: Partial<ViewBrick>): ViewBrick {
    return Object.assign({
      kind: 'focus',
      routePattern: '/',
      module: 'demo',
      focusType: 'other',
      idField: ['id', 'Id'],
      labelField: ['name', 'Name'],
      select: (state: any) => state && state.demo ? state.demo.selected : null
    } as ViewBrick, overrides || {});
  }

  it('writes the pre-T2 HostContextFocus shape { type, id, label }', function () {
    const bricks = [focusBrick()];
    const state = { demo: { selected: { id: 'e1', name: 'Entity One' } } };
    expect(buildContextFocusFromBricks(bricks, state, '/anywhere')).toEqual({ type: 'other', id: 'e1', label: 'Entity One' });
  });

  it('label falls back to the id when no labelField key matches', function () {
    const bricks = [focusBrick()];
    const state = { demo: { selected: { id: 'e1' } } };
    expect(buildContextFocusFromBricks(bricks, state, '/anywhere')).toEqual({ type: 'other', id: 'e1', label: 'e1' });
  });

  it('focus rides every turn (route-independent, pre-T2 behaviour)', function () {
    const bricks = [focusBrick()];
    const state = { demo: { selected: { id: 'e1', name: 'N' } } };
    expect(buildContextFocusFromBricks(bricks, state, '/a')).not.toBeNull();
    expect(buildContextFocusFromBricks(bricks, state, '/b/c')).not.toBeNull();
  });

  it('first focus brick IN REGISTRATION ORDER whose entity yields an id wins', function () {
    const first = focusBrick({ module: 'a', focusType: 'other', select: () => ({ id: '', Name: 'no id here' }) });
    const second = focusBrick({ module: 'b', focusType: 'other', select: (s: any) => s.b.selected, labelField: ['name', 'Name'] });
    const state = { b: { selected: { id: 'b1', name: 'B One' } } };
    expect(buildContextFocusFromBricks([first, second], state, '/x')).toEqual({ type: 'other', id: 'b1', label: 'B One' });
  });

  it('same-module duplicate focus bricks: first wins (kind+module dedupe)', function () {
    // First brick wins even when its own labelField misses (label falls
    // back to id 'e1'); the second brick would have produced label 'N'.
    const first = focusBrick({ labelField: ['first'] });
    const second = focusBrick({ labelField: ['name', 'Name'] });
    const state = { demo: { selected: { id: 'e1', name: 'N' } } };
    expect(buildContextFocusFromBricks([first, second], state, '/x')).toEqual({ type: 'other', id: 'e1', label: 'e1' });
  });

  it('no entity or no resolvable id → null focus (same as pre-T2)', function () {
    const bricks = [focusBrick()];
    expect(buildContextFocusFromBricks(bricks, { demo: {} }, '/x')).toBeNull();
    expect(buildContextFocusFromBricks(bricks, { demo: { selected: { Name: 'no id' } } }, '/x')).toBeNull();
    expect(buildContextFocusFromBricks(bricks, {}, '/x')).toBeNull();
    expect(buildContextFocusFromBricks(null, { demo: { selected: { id: 'e1' } } }, '/x')).toBeNull();
  });

  it('a focus brick that throws in select is skipped, not fatal', function () {
    const broken = focusBrick({ select: () => { throw new Error('boom'); } });
    const healthy = focusBrick({ module: 'b', focusType: 'other', select: () => ({ id: 'b1', name: 'B' }) });
    expect(buildContextFocusFromBricks([broken, healthy], {}, '/x')).toEqual({ type: 'other', id: 'b1', label: 'B' });
  });
});

describe('view-bricks form-options (M14-T3)', function () {
  function shapedBrick(rows: any[], overrides?: Partial<ViewBrick>): ViewBrick {
    return Object.assign({
      kind: 'form-options',
      name: 'courses',
      routePattern: '/',
      module: 'demo',
      select: () => rows
    } as ViewBrick, overrides || {});
  }

  it('passes already-shaped {value,label} entries through dedup (value, then normalized label, keep first)', function () {
    const rows = [
      { value: 'c1', label: 'PUC I Commerce A' },
      { value: 'c1x', label: 'PUC I Commerce A' },   // same normalized label → dropped
      { value: 'c2', label: 'PUC I Commerce  B' },   // whitespace normalized separately
      { value: '', label: 'no value' },              // no value → dropped
      { value: 'c3', label: '  ' }                   // empty label → falls back to value
    ];
    const bag = buildFormOptionsFromBricks([shapedBrick(rows)], {}, '/anywhere', ['courses']);
    expect(bag).toEqual({
      courses: [
        { value: 'c1', label: 'PUC I Commerce A' },
        { value: 'c2', label: 'PUC I Commerce  B' },
        { value: 'c3', label: 'c3' }
      ]
    });
  });

  it('caps at 100 options, keeping the first 100', function () {
    const rows: any[] = [];
    for (let i = 0; i < 120; i++) { rows.push({ value: 'v' + i, label: 'L ' + i }); }
    const bag = buildFormOptionsFromBricks([shapedBrick(rows)], {}, '/x', ['courses']);
    expect(bag!.courses.length).toBe(100);
    expect(bag!.courses[99].value).toBe('v99');
  });

  it('reads raw rows through valueField/labelField with label fallback to value', function () {
    const brick = shapedBrick(
      [{ Id: 'o1', Name: 'Org One' }, { id: 'o2', label: 'Org Two' }, { Name: 'no id' }],
      { name: 'parentOrgs', valueField: ['id', 'Id'], labelField: ['name', 'Name', 'label', 'Label'] }
    );
    const bag = buildFormOptionsFromBricks([brick], {}, '/x', ['parentOrgs']);
    expect(bag).toEqual({ parentOrgs: [{ value: 'o1', label: 'Org One' }, { value: 'o2', label: 'Org Two' }] });
  });

  it('a matched brick contributes its key even when the slice is empty', function () {
    const bag = buildFormOptionsFromBricks([shapedBrick([])], {}, '/x', ['courses']);
    expect(bag).toEqual({ courses: [] });
  });

  it('a requested name with no matching brick is omitted; all missing → null', function () {
    expect(buildFormOptionsFromBricks([shapedBrick([{ value: 'v', label: 'L' }])], {}, '/x', ['parentOrgs'])).toBeNull();
    expect(buildFormOptionsFromBricks(null, {}, '/x', ['courses'])).toBeNull();
    expect(buildFormOptionsFromBricks([shapedBrick([{ value: 'v', label: 'L' }])], {}, '/x', [])).toBeNull();
  });

  it('bricks register "/" so options ride any route (intent-gated, not route-gated)', function () {
    const bag = buildFormOptionsFromBricks([shapedBrick([{ value: 'v', label: 'L' }])], {}, '/fees/transactions', ['courses']);
    expect(bag!.courses.length).toBe(1);
  });

  it('resolveFormOptionsFromBricks awaits a brick fallback ONLY when the store slice is empty', function (done) {
    let fallbackCalls = 0;
    const storeBrick = shapedBrick([{ value: 'c1', label: 'Store Course' }], {
      fallback: () => { fallbackCalls++; return Promise.resolve([{ value: 'api1', label: 'API Course' }]); }
    });
    resolveFormOptionsFromBricks([storeBrick], {}, '/x', ['courses']).then((bag) => {
      expect(bag).toEqual({ courses: [{ value: 'c1', label: 'Store Course' }] });
      expect(fallbackCalls).toBe(0);
      done();
    }).catch(done.fail);
  });

  it('empty store → fallback awaited; fallback error → empty options, never invented', function (done) {
    let fallbackCalls = 0;
    const fallbackBrick = shapedBrick([], {
      fallback: () => { fallbackCalls++; return Promise.reject(new Error('api down')); }
    });
    resolveFormOptionsFromBricks([fallbackBrick], {}, '/x', ['courses']).then((bag) => {
      expect(bag).toEqual({ courses: [] });
      expect(fallbackCalls).toBe(1);
      done();
    }).catch(done.fail);
  });

  it('two bricks sharing ONE fallback function trigger a single fallback call (org pattern)', function (done) {
    let fallbackCalls = 0;
    const shared = () => { fallbackCalls++; return Promise.resolve([{ id: 'o1', name: 'Org One' }]); };
    const parent = shapedBrick([], { name: 'parentOrgs', valueField: ['id', 'Id'], labelField: ['name', 'Name'], fallback: shared });
    const owner = shapedBrick([], { name: 'ownerOrgs', valueField: ['id', 'Id'], labelField: ['name', 'Name'], fallback: shared });
    resolveFormOptionsFromBricks([parent, owner], {}, '/x', ['parentOrgs', 'ownerOrgs']).then((bag) => {
      expect(bag!.parentOrgs).toEqual([{ value: 'o1', label: 'Org One' }]);
      expect(bag!.ownerOrgs).toEqual([{ value: 'o1', label: 'Org One' }]);
      expect(fallbackCalls).toBe(1);
      done();
    }).catch(done.fail);
  });
});

describe('view-bricks summary/chart/wizard extras (M14-T4)', function () {
  function extraBrick(kind: any, raw: any, overrides?: Partial<ViewBrick>): ViewBrick {
    return Object.assign({
      kind: kind,
      routePattern: '/demo/screen',
      module: 'demo',
      select: () => raw
    } as ViewBrick, overrides || {});
  }

  it('summary: scalar-map object entries are humanized and bounded to 12', function () {
    const raw: Record<string, unknown> = {};
    for (let i = 0; i < 15; i++) { raw['credit_' + i] = i; }
    raw['blob'] = { nested: true };
    raw['empty'] = '   ';
    const snapshot = buildViewSnapshotFromBricks([extraBrick('summary', raw)], {}, '/demo/screen');
    expect((snapshot! as any).summary!.length).toBe(12);
    expect((snapshot! as any).summary![0]).toEqual({ label: 'Credit 0', value: '0' });
    expect((snapshot! as any).summary).not.toContain(jasmine.objectContaining({ label: 'Blob' }));
    expect((snapshot! as any).summary).not.toContain(jasmine.objectContaining({ label: 'Empty' }));
  });

  it('summary: shaped {label,value} entries pass through with scalars only', function () {
    const raw = [
      { label: 'Sent', value: '10' },
      { label: 'Draft', value: 3 },
      { label: '   ', value: 'x' },
      { label: 'No value', value: '' }
    ];
    const snapshot = buildViewSnapshotFromBricks([extraBrick('summary', raw)], {}, '/demo/screen');
    expect((snapshot! as any).summary).toEqual([
      { label: 'Sent', value: '10' },
      { label: 'Draft', value: '3' }
    ]);
  });

  it('chart: title/kind scalars + capped shaped series, no blobs', function () {
    const raw = {
      title: 'SMS delivery',
      kind: 'column',
      series: [{ label: '01 Aug', value: 3 }, { label: '', value: 0 }, { label: 'no value', value: '' }, 'junk'],
      data: { blob: 'nope' }
    };
    const snapshot = buildViewSnapshotFromBricks([extraBrick('chart', raw)], {}, '/demo/screen');
    expect((snapshot! as any).chart).toEqual({
      title: 'SMS delivery',
      kind: 'column',
      series: [{ label: '01 Aug', value: '3' }]
    });
    expect('data' in snapshot!).toBe(false);
  });

  it('chart: a raw series array or scalar select is omitted (brick shapes it)', function () {
    expect(buildViewSnapshotFromBricks([extraBrick('chart', [1, 2])], {}, '/demo/screen')).toBeNull();
    expect(buildViewSnapshotFromBricks([extraBrick('chart', 'oops')], {}, '/demo/screen')).toBeNull();
  });

  it('wizard: scalars only, cap 12 keys; objects/arrays dropped', function () {
    const raw = {
      step: 'subject',
      subject: 'Term results',
      hasAttachment: true,
      count: 4,
      blob: { x: 1 },
      list: [1, 2]
    };
    const snapshot = buildViewSnapshotFromBricks([extraBrick('wizard', raw)], {}, '/demo/screen');
    expect((snapshot! as any).wizard).toEqual({
      step: 'subject',
      subject: 'Term results',
      hasAttachment: 'true',
      count: '4'
    });
    expect('blob' in (snapshot!.wizard as any)).toBe(false);
    expect('list' in (snapshot!.wizard as any)).toBe(false);
  });

  it('an empty extra omits its key; a view with only an empty extra is omitted entirely', function () {
    expect(buildViewSnapshotFromBricks([extraBrick('summary', {})], {}, '/demo/screen')).toBeNull();
    expect(buildViewSnapshotFromBricks([extraBrick('wizard', null)], {}, '/demo/screen')).toBeNull();
  });

  it('select receives the route so wizard bricks can derive the step', function () {
    let seenRoute = '';
    const brick = extraBrick('wizard', null, {
      select: (state: any, route: string) => { seenRoute = String(route || ''); return { step: 'x' }; }
    });
    const snapshot = buildViewSnapshotFromBricks([brick], {}, '/demo/screen');
    expect(seenRoute).toBe('/demo/screen');
    expect((snapshot! as any).wizard).toEqual({ step: 'x' });
  });
});

describe('extras merge with a rows view (M14-T4)', function () {
  it('a summary brick on the same route rides the rows snapshot untouched', function () {
    const rows: ViewBrick = {
      kind: 'rows',
      routePattern: '/demo/list',
      module: 'demo',
      screen: 'list',
      title: 'Demo List',
      source: 'store.demo.list',
      select: (state: any) => state.demo.list
    };
    const summary: ViewBrick = {
      kind: 'summary',
      routePattern: '/demo/list',
      module: 'demo',
      select: (state: any) => [{ label: 'Credits', value: String(state.demo.credits) }]
    };
    const snapshot: any = buildViewSnapshotFromBricks(
      [rows, summary],
      { demo: { list: [{ id: 'r1' }], credits: 7 } },
      '/demo/list'
    );
    expect(snapshot).toEqual({
      module: 'demo',
      screen: 'list',
      title: 'Demo List',
      source: 'store.demo.list',
      columns: ['id'],
      rows: [{ id: 'r1' }],
      rowCount: 1,
      truncated: false,
      maxRows: 30,
      summary: [{ label: 'Credits', value: '7' }]
    });
  });
});
