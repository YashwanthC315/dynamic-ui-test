import { Injectable, Optional } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { Subscription } from 'rxjs/Subscription';
import * as rootReducer from '../../rootReducer';
import { FeesService } from '../../fees/service/service';
import { createToolRegistry, registerDefaultUiContextTools, ToolRegistry } from '../../ai-context-tools';
import { UiContextToolDependencies } from '../../ai-context-tools/types';
import { environment } from '../../../../env/environment';
import { ChatRequest, ChatResponse } from './chat-contracts';
import { HarnessTransportClient } from './chat-transport-adapter.service';
import { buildFilteredHarnessTools } from './frontend-agent-tool-filter';

export interface FrontendAgentOptions {
  conversationId?: string;
  runId?: string;
  requestId?: string;
  scenario?: string;
  metadata?: { [key: string]: any };
}

export interface FrontendAgentToolActivity {
  id: string;
  name: string;
  arguments: any;
  ok?: boolean;
  result?: any;
  error?: string;
}

interface RuntimeMessage {
  role: 'system' | 'user' | 'assistant' | 'tool';
  content?: string;
  name?: string;
  tool_call_id?: string;
  tool_calls?: any[];
}

interface ActiveRun {
  runId: string;
  conversationId: string;
  requestId: string;
  socket: WebSocket;
  cancelled: boolean;
  terminal: boolean;
  deltas: string[];
  observer?: any;
}

const SYSTEM_GUIDANCE = [
  'Prefer calling context tools before acting.',
  'Use only the filtered domain tools supplied for the current route.',
  'Use mutation tools only with explicit, validated arguments.',
  'For financial actions, confirm intent when the request is ambiguous.'
].join(' ');

const AGENT_INSTRUCTIONS_URL = (environment as any).AGENT_INSTRUCTIONS_URL || '/AGENTS.md';
const DEFAULT_HISTORY_MAX_TOKENS = 12000;
const DEFAULT_HISTORY_COMPACT_AT = 0.7;
const DEFAULT_HISTORY_KEEP_RECENT_TURNS = 6;

@Injectable({ providedIn: 'root' })
export class FrontendAgentService implements HarnessTransportClient {
  readonly delta$ = new Subject<{ runId: string; delta: string }>();
  readonly toolActivity$ = new Subject<FrontendAgentToolActivity>();
  readonly final$ = new Subject<{ runId: string; message: string; output?: any }>();
  readonly error$ = new Subject<{ runId?: string; message: string; code?: string }>();

  private readonly registry: ToolRegistry;
  private readonly messages: RuntimeMessage[] = [{ role: 'system', content: SYSTEM_GUIDANCE }];
  private systemGuidance = SYSTEM_GUIDANCE;
  private systemGuidancePromise: Promise<string> | null = null;
  private startSequence = 0;
  private pendingRequestId: string | null = null;
  private latestState: any = null;
  private stateSubscription: Subscription;
  private activeRun: ActiveRun | null = null;
  private readonly harnessUrl: string;
  private readonly historyMaxTokens: number;
  private readonly historyCompactAt: number;
  private readonly historyKeepRecentTurns: number;

  constructor(
    private readonly router: Router,
    private readonly store: Store<rootReducer.State>,
    @Optional() private readonly feesService: FeesService
  ) {
    this.harnessUrl = (environment as any).AGENT_HARNESS_WS_URL || 'ws://localhost:8787';
    this.historyMaxTokens = this.readPositiveNumber((environment as any).AGENT_HISTORY_MAX_TOKENS, DEFAULT_HISTORY_MAX_TOKENS);
    this.historyCompactAt = this.readFraction((environment as any).AGENT_HISTORY_COMPACT_AT, DEFAULT_HISTORY_COMPACT_AT);
    this.historyKeepRecentTurns = this.readPositiveInteger((environment as any).AGENT_HISTORY_KEEP_RECENT_TURNS, DEFAULT_HISTORY_KEEP_RECENT_TURNS);
    this.stateSubscription = this.store.subscribe((state: any) => this.latestState = state);

    const deps: UiContextToolDependencies = {
      router: this.router,
      store: this.store,
      getState: () => this.latestState,
      feesService: this.feesService
    };
    this.registry = createToolRegistry();
    registerDefaultUiContextTools(this.registry, deps);
    if (!this.feesService) {
      console.warn('[FrontendAgent] FeesService is not available; Fees mutation tools will return structured errors.');
    }
  }

  /** Adapter-compatible entry point used by the existing chat panel. */
  send(request: ChatRequest): Observable<ChatResponse> {
    return new Observable((observer: any) => {
      const finalSubscription = this.final$.subscribe((event) => {
        if (this.activeRun && this.activeRun.requestId === request.requestId) {
          observer.next(this.toChatResponse(request, event.message, event.output));
          observer.complete();
        }
      });
      const errorSubscription = this.error$.subscribe((event) => {
        if (!event.runId || !this.activeRun || event.runId === this.activeRun.runId) {
          observer.error(new Error(event.message));
        }
      });

      this.startRun(request.prompt, {
        conversationId: request.conversationId,
        requestId: request.requestId,
        metadata: { chat_context: request.context, client: request.client }
      });

      return () => {
        finalSubscription.unsubscribe();
        errorSubscription.unsubscribe();
        if (this.activeRun && this.activeRun.requestId === request.requestId) {
          this.cancelRun('transport subscription cancelled');
        } else if (this.pendingRequestId === request.requestId) {
          this.pendingRequestId = null;
          this.startSequence++;
        }
      };
    });
  }

  startRun(userMessage: string, options: FrontendAgentOptions = {}): void {
    if (this.activeRun) {
      this.cancelRun('superseded by a new run');
    }

    const startSequence = ++this.startSequence;

    const token = this.readAccessToken();
    const runId = options.runId || this.createId('run');
    const conversationId = options.conversationId || this.createId('conv');
    const requestId = options.requestId || this.createId('req');
    if (!token) {
      const technicalMessage = 'Cannot start the frontend agent: no access token is available.';
      console.error('[FrontendAgent] error code=missing_access_token', technicalMessage);
      this.error$.next({
        runId,
        message: this.toUserFacingErrorMessage('missing_access_token', technicalMessage),
        code: 'missing_access_token'
      });
      return;
    }

    this.pendingRequestId = requestId;
    this.loadSystemGuidance().then((guidance) => {
      if (startSequence !== this.startSequence) {
        return;
      }
      this.pendingRequestId = null;
      this.systemGuidance = guidance;
      this.messages[0] = { role: 'system', content: guidance };
      this.beginRun(userMessage, options, runId, conversationId, requestId, token);
    });
  }

  private beginRun(
    userMessage: string,
    options: FrontendAgentOptions,
    runId: string,
    conversationId: string,
    requestId: string,
    token: string
  ): void {
    this.pendingRequestId = null;
    const definitions = this.registry.getToolDefinitions();
    const tools = buildFilteredHarnessTools(this.router, definitions);
    console.log('[FrontendAgent] start run_id=' + runId + ' tools=[' + tools.map((tool) => tool.name).join(', ') + ']');

    this.compactHistoryIfNeeded();
    this.messages.push({ role: 'user', content: userMessage });

    const socketUrl = this.withToken(this.harnessUrl, token);
    console.log('[FrontendAgent] connecting → ' + this.harnessUrl + ' tokenPresent=' + (!!token));
    const socket = new WebSocket(socketUrl);
    this.activeRun = { runId, conversationId, requestId, socket, cancelled: false, terminal: false, deltas: [] };

    socket.onopen = () => {
      console.log('[FrontendAgent] connected');
      const payload: any = {
        type: 'start', run_id: runId, conversation_id: conversationId,
        messages: this.messages.slice(), tools, metadata: Object.assign({}, options.metadata || {}, {
          auth: { tokenPresent: true }, frontend_agent: true
        })
      };
      if (options.scenario) { payload.scenario = options.scenario; }
      socket.send(JSON.stringify(payload));
    };
    socket.onmessage = (event: MessageEvent) => this.handleServerEvent(event.data);
    socket.onerror = () => this.failActiveRun('WebSocket connection error.', 'socket_error');
    socket.onclose = () => {
      if (this.activeRun && this.activeRun.socket === socket && !this.activeRun.cancelled && !this.activeRun.terminal) {
        this.failActiveRun('WebSocket closed before the agent completed.', 'socket_closed');
      }
    };
  }

  /**
   * Loads an optional runtime AGENTS.md. Angular cannot read the repository
   * filesystem from the browser, so the file must be served at
   * AGENT_INSTRUCTIONS_URL (default: /AGENTS.md). A missing, empty, or HTML
   * response falls back to the built-in guidance.
   */
  private loadSystemGuidance(): Promise<string> {
    if (this.systemGuidancePromise) {
      return this.systemGuidancePromise;
    }

    this.systemGuidancePromise = fetch(AGENT_INSTRUCTIONS_URL, { credentials: 'same-origin' })
      .then((response) => {
        const contentType = response.headers.get('content-type') || '';
        if (!response.ok || contentType.toLowerCase().indexOf('text/html') >= 0) {
          throw new Error('AGENTS.md is not available at ' + AGENT_INSTRUCTIONS_URL);
        }
        return response.text();
      })
      .then((content) => {
        const guidance = content.trim();
        if (!guidance) {
          throw new Error('AGENTS.md is empty.');
        }
        console.log('[FrontendAgent] loaded system guidance from ' + AGENT_INSTRUCTIONS_URL);
        return guidance;
      })
      .catch((error) => {
        console.warn('[FrontendAgent] using default system guidance:', error instanceof Error ? error.message : error);
        return this.systemGuidance;
      });

    return this.systemGuidancePromise;
  }

  cancelRun(reason: string = 'cancelled by user'): void {
    this.startSequence++;
    const run = this.activeRun;
    if (!run) {
      this.pendingRequestId = null;
      return;
    }
    if (run.terminal) {
      return;
    }
    console.log('[FrontendAgent] cancel run_id=' + run.runId + ' reason=' + reason);
    run.cancelled = true;
    if (run.socket.readyState === WebSocket.OPEN) {
      run.socket.send(JSON.stringify({ type: 'cancel', run_id: run.runId, conversation_id: run.conversationId, reason }));
    }
  }

  private handleServerEvent(raw: any): void {
    let event: any;
    try { event = typeof raw === 'string' ? JSON.parse(raw) : raw; }
    catch (error) { this.failActiveRun('Invalid JSON event from harness.', 'invalid_event'); return; }
    const run = this.activeRun;
    if (!run || (event.run_id && event.run_id !== run.runId)) { return; }

    if (event.type === 'delta') {
      run.deltas.push(String(event.delta || ''));
      console.log('[FrontendAgent] delta', event.delta);
      this.delta$.next({ runId: run.runId, delta: String(event.delta || '') });
      return;
    }
    if (event.type === 'tool_calls') {
      const calls = (Array.isArray(event.tool_calls) ? event.tool_calls : []).map((call: any) => ({
        id: String(call && call.id ? call.id : this.createId('tc')),
        name: String(call && call.name ? call.name : ''),
        arguments: call ? call.arguments : {}
      }));
      console.log('[FrontendAgent] tool_calls', calls);
      if (calls.length) {
        this.messages.push({
          role: 'assistant',
          content: '',
          tool_calls: calls.map((call: any) => ({
            id: call.id,
            type: 'function',
            function: {
              name: call.name,
              arguments: typeof call.arguments === 'string'
                ? call.arguments
                : JSON.stringify(call.arguments || {})
            }
          }))
        });
      }
      this.executeToolCalls(calls);
      return;
    }
    if (event.type === 'final') {
      console.log('[FrontendAgent] final', event.message);
      this.finishRun(String(event.message || run.deltas.join('')), event.output);
      return;
    }
    if (event.type === 'error') {
      this.failActiveRun(String(event.message || 'Harness error.'), event.code || 'harness_error');
    }
  }

  private async executeToolCalls(calls: any[]): Promise<void> {
    const run = this.activeRun;
    if (!run) { return; }
    const results: any[] = [];
    for (const call of calls) {
      const args = this.parseArguments(call.arguments);
      console.log('[FrontendAgent] execute tool ' + call.name + ' args=', args);
      const activity: FrontendAgentToolActivity = { id: call.id, name: call.name, arguments: args };
      try {
        let result: any;
        if (call.name === 'call_backend_agent') {
          // The harness owns backend-agent execution. Returning its request-shaped
          // payload lets deterministic and live harnesses continue their loop.
          result = args;
        } else {
          result = await this.registry.executeTool(call.name, args);
        }
        activity.ok = true; activity.result = result;
        results.push({ tool_call_id: call.id, result });
        console.log('[FrontendAgent] tool result ' + call.name + ' ok=true', result);
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        activity.ok = false; activity.error = message;
        results.push({ tool_call_id: call.id, error: message, result: { ok: false, tool: call.name, errors: [message] } });
        console.error('[FrontendAgent] tool result ' + call.name + ' ok=false', message);
      }
      this.toolActivity$.next(activity);
      this.messages.push({ role: 'tool', name: call.name, tool_call_id: call.id, content: JSON.stringify(activity.result || { error: activity.error }) });
    }
    if (this.activeRun !== run || run.cancelled || run.socket.readyState !== WebSocket.OPEN) { return; }
    run.socket.send(JSON.stringify({ type: 'tool_results', run_id: run.runId, conversation_id: run.conversationId, tool_results: results }));
  }

  private finishRun(message: string, output?: any): void {
    const run = this.activeRun;
    if (!run) { return; }
    const wasCancelled = run.cancelled;
    const resultMessage = wasCancelled ? (message || 'Request cancelled.') : message;
    run.terminal = true;
    if (!wasCancelled) {
      this.messages.push({ role: 'assistant', content: resultMessage });
      console.log('[FrontendAgent] history append assistant (len=' + resultMessage.length + ')');
    }
    this.final$.next({ runId: run.runId, message: resultMessage, output });
    if (run.socket.readyState === WebSocket.OPEN || run.socket.readyState === WebSocket.CONNECTING) { run.socket.close(); }
    this.activeRun = null;
  }

  private failActiveRun(message: string, code: string): void {
    const run = this.activeRun;
    if (run) {
      run.terminal = true;
    }
    console.error('[FrontendAgent] error code=' + code, message);
    this.error$.next({
      runId: run && run.runId,
      message: this.toUserFacingErrorMessage(code, message),
      code
    });
    if (run && run.socket.readyState !== WebSocket.CLOSED) { run.socket.close(); }
    this.activeRun = null;
  }

  private toUserFacingErrorMessage(code?: string, technicalMessage?: string): string {
    // Keep technicalMessage in the signature so callers provide explicit context
    // while user-facing copy remains safe and non-technical.
    void technicalMessage;
    if (code === 'missing_access_token') {
      return 'Your session expired. Please sign in again.';
    }
    return 'Unable to fulfill your request. Please try again later.';
  }

  private toChatResponse(request: ChatRequest, message: string, output?: any): ChatResponse {
    const cancelled = !!(output && output.cancelled);
    return {
      schemaVersion: '1.0.0', requestId: request.requestId, conversationId: request.conversationId,
      messageId: this.createId('resp'), parentMessageId: request.messageId,
      agent: { id: 'frontend-agent', displayName: 'Frontend Agent' }, status: cancelled ? 'cancelled' : 'completed',
      blocks: [cancelled ? { type: 'status', level: 'info', text: message } : { type: 'text', text: message }],
      contextPatch: output ? { frontendAgentOutput: output } : undefined
    };
  }

  private readAccessToken(): string {
    const stateToken = this.latestState && this.latestState.app && this.latestState.app.accessToken;
    let sessionToken = '';
    try { sessionToken = sessionStorage.getItem('accessToken') || ''; } catch (error) { /* SSR/test environment */ }
    return stateToken || sessionToken || '';
  }

  private withToken(url: string, token: string): string {
    return url + (url.indexOf('?') >= 0 ? '&' : '?') + 'access_token=' + encodeURIComponent(token);
  }

  private parseArguments(args: any): any {
    if (typeof args !== 'string') { return args || {}; }
    try { return JSON.parse(args); } catch (error) { return { raw: args }; }
  }

  /**
   * Phase 1 history estimate: serialized message size divided by four. A real
   * model tokenizer can replace this without changing the compaction policy.
   */
  private estimateHistoryTokens(messages: RuntimeMessage[] = this.messages): number {
    return messages.reduce((total, message) => {
      let serialized = '';
      try { serialized = JSON.stringify(message) || ''; } catch (error) { serialized = String(message.content || ''); }
      return total + Math.ceil(serialized.length / 4);
    }, 0);
  }

  private compactHistoryIfNeeded(): void {
    const before = this.estimateHistoryTokens();
    const threshold = this.historyMaxTokens * this.historyCompactAt;
    if (before < threshold || this.messages.length <= 1) {
      return;
    }

    const systemMessage = this.messages[0];
    const history = this.messages.slice(1);
    const userIndexes: number[] = [];
    history.forEach((message, index) => {
      if (message.role === 'user') { userIndexes.push(index); }
    });

    // A turn starts at a user message and includes following tool/assistant
    // messages until the next user message. Preserve the newest configured
    // number of turns, then drop still-older complete turns if necessary.
    let firstKeptIndex = 0;
    if (userIndexes.length > this.historyKeepRecentTurns) {
      firstKeptIndex = userIndexes[userIndexes.length - this.historyKeepRecentTurns];
    }
    let compacted = [systemMessage].concat(history.slice(firstKeptIndex));

    while (this.estimateHistoryTokens(compacted) >= threshold && userIndexes.length > 1) {
      const compactedHistory = compacted.slice(1);
      const compactedUserIndex = compactedHistory.findIndex((message) => message.role === 'user');
      if (compactedUserIndex < 0) { break; }
      compacted = [systemMessage].concat(compactedHistory.slice(compactedUserIndex + 1));
      userIndexes.shift();
    }

    this.messages.splice(0, this.messages.length, ...compacted);
    const after = this.estimateHistoryTokens();
    const keptTurns = this.messages.slice(1).filter((message) => message.role === 'user').length;
    console.log('[FrontendAgent] history compact before=' + before + ' after=' + after + ' keptTurns=' + keptTurns);
  }

  private readPositiveNumber(value: any, fallback: number): number {
    const parsed = Number(value);
    return isFinite(parsed) && parsed > 0 ? parsed : fallback;
  }

  private readFraction(value: any, fallback: number): number {
    const parsed = Number(value);
    return isFinite(parsed) && parsed > 0 && parsed <= 1 ? parsed : fallback;
  }

  private readPositiveInteger(value: any, fallback: number): number {
    const parsed = Math.floor(Number(value));
    return isFinite(parsed) && parsed > 0 ? parsed : fallback;
  }

  private createId(prefix: string): string {
    return prefix + '_' + Date.now() + '_' + Math.random().toString(36).slice(2, 9);
  }
}
