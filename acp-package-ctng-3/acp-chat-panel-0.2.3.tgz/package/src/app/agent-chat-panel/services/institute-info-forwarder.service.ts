import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import { InstituteInfo } from './mock-institute.service';

@Injectable({ providedIn: 'root' })
export class InstituteInfoForwarder {
  private subject = new Subject<InstituteInfo>();

  publish(info: InstituteInfo) {
    this.subject.next(info);
  }

  get institute$(): Observable<InstituteInfo> {
    return this.subject.asObservable();
  }
}
