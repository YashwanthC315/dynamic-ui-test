import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import {
  AGENT_FILE_RUN_CONFIG,
  AgentFileRunRequest,
  buildFileRunUserPrompt,
  HttpAgentFileRunPort
} from './agent-file-run.port';

describe('agent-file-run port (M15-T1, POST-only after follow-up)', function () {
  const CONFIG = {
    baseUrl: 'http://file-run-host.test',
    bearerToken: 'file-run-token',
    agentPath: 'agents/ct_main.exs'
  };
  const RUNS_URL = 'http://file-run-host.test/api/playground/agent-file-runs';

  let http: HttpTestingController;
  let port: HttpAgentFileRunPort;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        HttpAgentFileRunPort,
        { provide: AGENT_FILE_RUN_CONFIG, useValue: CONFIG }
      ]
    });
    http = TestBed.get(HttpTestingController);
    port = TestBed.get(HttpAgentFileRunPort);
  });

  afterEach(() => {
    http.verify();
  });

  function feesTurn(): AgentFileRunRequest {
    return {
      conversationId: 'conv-1',
      turnText: 'what can you see?',
      history: [
        { role: 'user', text: 'take me to fees transactions' },
        { role: 'assistant', text: 'Opened Fees Transactions.' }
      ],
      context: {
        route: '/fees/transactions',
        view: {
          module: 'fees',
          screen: 'transactions',
          columns: ['id', 'amount'],
          rows: [{ id: 't1', amount: 1500 }]
        }
      } as any
    };
  }

  function buddyParseTurn(): AgentFileRunRequest {
    return {
      conversationId: 'conv-1',
      turnText: 'Anita Rao 01/02/2014 female PUC I\nRavi K 03/05/2013 male PUC II',
      context: {
        route: '/home',
        formOptions: { courses: [{ value: 'c1', label: 'PUC I Commerce A' }] }
      } as any
    };
  }

  it('composes user_prompt as ONE string: history + host context + this turn', function () {
    const prompt = buildFileRunUserPrompt(feesTurn());
    const lines = prompt.split('\n');
    expect(lines[0]).toBe('user: take me to fees transactions');
    expect(lines[1]).toBe('assistant: Opened Fees Transactions.');
    expect(lines[2].indexOf('[host_context] {"route":"/fees/transactions"')).toBe(0);
    expect(lines[lines.length - 1]).toBe('what can you see?');
  });

  it('a fees turn POSTs agent_path + user_prompt ONLY, with the config bearer token, and emits the 202 run_id', function (done) {
    let emitted = '';
    port.startFileRun(feesTurn()).subscribe((runId: string) => {
      emitted = runId;
      expect(emitted).toBe('run-fees-1');
      done();
    }, (err) => done.fail(err));

    const req = http.expectOne(RUNS_URL);
    expect(req.request.method).toBe('POST');
    expect(req.request.headers.get('Authorization')).toBe('Bearer file-run-token');
    expect(Object.keys(req.request.body)).toEqual(['agent_path', 'user_prompt']);
    expect(req.request.body['agent_path']).toBe('agents/ct_main.exs');
    expect(req.request.body['user_prompt'].indexOf('what can you see?')).toBeGreaterThan(0);
    expect('system_prompt' in req.request.body).toBe(false);
    req.flush({ run_id: 'run-fees-1' }, { status: 202, statusText: 'Accepted' });
  });

  it('a buddy-parse turn POSTs the same two-key body (turn text + context, no history)', function (done) {
    let emitted = '';
    port.startFileRun(buddyParseTurn()).subscribe((runId: string) => {
      emitted = runId;
      expect(emitted).toBe('run-buddy-2');
      done();
    }, (err) => done.fail(err));

    const req = http.expectOne(RUNS_URL);
    expect(req.request.method).toBe('POST');
    expect(Object.keys(req.request.body)).toEqual(['agent_path', 'user_prompt']);
    expect(req.request.body['agent_path']).toBe('agents/ct_main.exs');
    // No history on this turn: context JSON first, turn text last.
    expect(req.request.body['user_prompt'].indexOf('[host_context] {"route":"/home"')).toBe(0);
    expect(req.request.body['user_prompt'].indexOf('Anita Rao 01/02/2014')).toBeGreaterThan(0);
    expect('system_prompt' in req.request.body).toBe(false);
    req.flush({ run_id: 'run-buddy-2' }, { status: 202, statusText: 'Accepted' });
  });

  it('a 202 without run_id, or an error response, surfaces as an error', function (done) {
    let errors = 0;
    port.startFileRun(feesTurn()).subscribe(() => done.fail('should not succeed'),
      () => {
        errors++;
        expect(errors).toBe(1);

        port.startFileRun(feesTurn()).subscribe(() => done.fail('should not succeed'),
          () => done(),
          () => done.fail('inner error handler not called'));
        const retry = http.expectOne(RUNS_URL);
        retry.flush({ message: 'api_error' }, { status: 500, statusText: 'Server Error' });
      }, () => done.fail('complete called on error'));
    const req = http.expectOne(RUNS_URL);
    req.flush({ ok: true }, { status: 202, statusText: 'Accepted' });
  });

  it('unconfigured token/agent_path fails fast without a request', function (done) {
    const unconfigured = new HttpAgentFileRunPort(http as any, { baseUrl: '', bearerToken: '', agentPath: '' });
    unconfigured.startFileRun(feesTurn()).subscribe(() => done.fail('should not start'),
      (err) => {
        expect(String(err && err.message).indexOf('not configured') >= 0).toBe(true);
        done();
      }, () => done.fail('complete called'));
  });
});
