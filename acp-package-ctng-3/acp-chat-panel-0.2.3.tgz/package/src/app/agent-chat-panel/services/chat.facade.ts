import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { createSelector } from '@ngrx/store';
import * as fromRoot from '../../rootReducer';
import * as fromAgent from '../store/reducer.chat';
import * as chatActions from '../store/action.chat';
import { AgentSurface, ActivityAction, ActivityItem, ActivityLogSurface } from './surface-contracts';

import { ChatRequest } from './chat-contracts';
import { ConversationListItem } from './ct-bot-conversation-history.service';

@Injectable({ providedIn: 'root' })
export class ChatFacade {
  private selectAgentState = fromRoot.getAgentChatState;

  private selectMessages = createSelector(this.selectAgentState, fromAgent.get_messages);
  private selectConversationId = createSelector(this.selectAgentState, fromAgent.get_conversation_id);
  private selectConversationList = createSelector(this.selectAgentState, fromAgent.get_conversation_list);
  private selectStatus = createSelector(this.selectAgentState, fromAgent.get_status);
  private selectActiveRequestId = createSelector(this.selectAgentState, fromAgent.get_active_request_id);
  private selectError = createSelector(this.selectAgentState, fromAgent.get_error);
  private selectActiveSurface = createSelector(this.selectAgentState, fromAgent.get_active_surface);
  private selectActivityLog = createSelector(this.selectAgentState, fromAgent.get_activity_log);
  private selectRestoredWorkspaceSurface = createSelector(this.selectAgentState, fromAgent.get_restored_workspace_surface);

  messages$ = this.store.select(this.selectMessages as any);
  conversationId$ = this.store.select(this.selectConversationId as any);
  conversationList$ = this.store.select(this.selectConversationList as any);
  status$ = this.store.select(this.selectStatus as any);
  activeRequestId$ = this.store.select(this.selectActiveRequestId as any);
  error$ = this.store.select(this.selectError as any);
  activeSurface$ = this.store.select(this.selectActiveSurface as any);
  activityLog$ = this.store.select(this.selectActivityLog as any);
  restoredWorkspaceSurface$ = this.store.select(this.selectRestoredWorkspaceSurface as any);

  constructor(private store: Store<any>) {}

  setMessages(messages: any[]) {
    this.store.dispatch(new chatActions.SetMessages({ messages }));
  }

  setConversationId(conversationId: string | null) {
    this.store.dispatch(new chatActions.SetConversationId({ conversationId }));
  }

  setConversationList(list: ConversationListItem[]) {
    this.store.dispatch(new chatActions.SetConversationList({ list }));
  }

  sendRequest(requestId: string, message?: any) {
    this.store.dispatch(new chatActions.SendRequest({ requestId, message }));
  }

  sendSuccess(requestId: string, message?: any) {
    this.store.dispatch(new chatActions.SendSuccess({ requestId, message }));
  }

  sendFailure(requestId: string, error: string) {
    this.store.dispatch(new chatActions.SendFailure({ requestId, error }));
  }

  cancelRequest(requestId: string) {
    this.store.dispatch(new chatActions.CancelRequest({ requestId }));
  }

  clearError() {
    this.store.dispatch(new chatActions.ClearError());
  }

  setActiveRequestId(activeRequestId: string | null) {
    this.store.dispatch(new chatActions.SetActiveRequestId({ activeRequestId }));
  }

  setStatus(status: 'idle' | 'inFlight' | 'error') {
    this.store.dispatch(new chatActions.SetStatus({ status }));
  }

  // History orchestration
  loadConversations(restoreActive: boolean = false) {
    this.store.dispatch(new chatActions.LoadConversations({ restoreActive }));
  }

  restoreConversationById(conversationId: string) {
    this.store.dispatch(new chatActions.RestoreConversation({ conversationId }));
  }

  createConversation(conversationId: string, title: string = 'New chat') {
    this.store.dispatch(new chatActions.CreateConversation({ conversationId, title }));
  }

  navigate(href: string, label?: string, messageId?: string) {
    this.store.dispatch(new chatActions.NavigateRequested({ href, label, messageId }));
  }

  emitEvent(eventRequest: any) {
    this.store.dispatch(new chatActions.EmitEventRequested({ eventRequest }));
  }

  loadInstitute() {
    this.store.dispatch(new chatActions.LoadInstituteRequested());
  }

  // Surface helpers
  openSurface(surface: AgentSurface) {
    this.store.dispatch(new chatActions.SetActiveSurface({ surface }));
  }

  clearSurface() {
    this.store.dispatch(new chatActions.ClearActiveSurface());
  }

  // Activity log helpers (P0-B1: store slice only)
  setActivityLog(surface: ActivityLogSurface) {
    this.store.dispatch(new chatActions.SetActivityLog({ surface }));
  }

  appendActivityItem(item: ActivityItem, menuActions?: ActivityAction[], conversationId?: string) {
    this.store.dispatch(new chatActions.AppendActivityItem({ item, menuActions, conversationId }));
  }

  clearActivityLog() {
    this.store.dispatch(new chatActions.ClearActivityLog());
  }

  /** M9-T2: the panel only dispatches — the effect owns the GET →
   * SetActivityLog round-trip. */
  loadActivityLog(conversationId: string) {
    this.store.dispatch(new chatActions.LoadActivityLog({ conversationId }));
  }

  /** M9-T2: post-settle workspace persist trigger — the effect owns the
   * PUT (the store surface object carries the live edits). */
  requestWorkspaceSnapshotPersist() {
    this.store.dispatch(new chatActions.PersistWorkspaceSnapshotRequested({}));
  }
}



