import { InjectionToken, Injectable, Inject } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { AGENT_FILE_RUN_CONFIG, AgentFileRunConfig } from './agent-file-run.port';

/**
 * M15 route fix: the browser WebSocket factory lives here as an EXPORTED
 * named function, not as an inline arrow in the AppModule providers list.
 * An inline function-expression useValue in AppModule broke the JIT
 * lazy-route discovery (listLazyRoutes returned an empty map -> the
 * shared $$_lazy_route_resource context compiled empty and EVERY
 * loadChildren string route threw Cannot find module). Same seam, same
 * token, factory reference only.
 */
export function browserAgentRunSocketFactory(): AgentRunSocketFactory {
  return (url: string, protocols: string[]) => new WebSocket(url, protocols);
}

/**
 * M15-T2: read-only file-run events socket. After a 202 run_id, the run's
 * reply arrives on:
 *
 *   GET {baseUrl}/api/playground/runs/{run_id}/events/ws
 *
 * A browser cannot set Authorization on a WebSocket, so the client
 * offers TWO subprotocols: 'aetheris.events.v1' and
 * 'aetheris.bearer.<bearer token as unpadded base64url>'. This client
 * only READS — a frame this client sends closes the socket, so it never
 * sends one. The server sends text frames (JSON):
 *
 *   {"kind":"event","cursor":"v1:3","event":{"event_type":"llm_responded",
 *    "payload":"<json string>"}}
 *
 * payload is a string and must be parsed; a frame is kept ONLY when
 * event_type is llm_responded and payload.response_type is "text" — the
 * reply is payload.raw_response, and a later text frame replaces it.
 * tool_call / spawn_agent / child runs are ignored. A control frame
 * {"kind":"control","control":"stream_end"} ends the socket.
 * Scripts do; agents decide — this client only reads.
 */

export interface AgentFileRunReply {
  rawResponse: string;
}

/** WebSocket factory seam — tests substitute a fake; AppModule the real browser WebSocket. */
export type AgentRunSocketFactory = (url: string, protocols: string[]) => WebSocket;

export const AGENT_RUN_SOCKET_FACTORY = new InjectionToken<AgentRunSocketFactory>('AGENT_RUN_SOCKET_FACTORY');

export interface ParsedRunFrame {
  reply?: string;
  end?: boolean;
}

/** Frame kinds the client reads; it only ever SENDS nothing. */
export const RUN_FRAME_KINDS = {
  EVENT: 'event',
  CONTROL: 'control'
};

export function encodeBearerSubprotocol(token: string): string {
  let base64 = '';
  try {
    // UTF-8 safe btoa (encodeURIComponent -> unescape gives byte chars).
    base64 = btoa(unescape(encodeURIComponent(String(token || ''))));
  } catch (e) {
    base64 = '';
  }
  if (!base64) { return ''; }
  return base64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

/**
 * Parses ONE text frame. Purer than the socket: exported for specs.
 * - event frame with llm_responded + payload.response_type "text" → reply.
 * - control stream_end → end.
 * - everything else (tool_call, spawn_agent, child runs, unparseable
 *   JSON) → ignored (no keys).
 */
export function parseRunEventFrame(text: string): ParsedRunFrame {
  let frame: any = null;
  try {
    frame = JSON.parse(String(text || ''));
  } catch (e) {
    return {};
  }
  if (!frame || typeof frame !== 'object') { return {}; }
  if (frame.kind === RUN_FRAME_KINDS.CONTROL) {
    return { end: frame.control === 'stream_end' };
  }
  if (frame.kind === RUN_FRAME_KINDS.EVENT) {
    const event = frame.event && typeof frame.event === 'object' ? frame.event : null;
    const eventType = event ? String(event.event_type || '') : '';
    if (eventType !== 'llm_responded') { return {}; }
    let payload: any = null;
    try {
      payload = typeof event.payload === 'string' ? JSON.parse(event.payload) : event.payload;
    } catch (e) {
      return {};
    }
    if (!payload || typeof payload !== 'object') { return {}; }
    if (String(payload.response_type || '') !== 'text') { return {}; }
    const rawResponse = payload.raw_response === undefined || payload.raw_response === null ? '' : String(payload.raw_response);
    if (!rawResponse) { return {}; }
    return { reply: rawResponse };
  }
  return {};
}

export abstract class AgentFileRunEventsSocket {
  /** Opens the run's read-only socket; emits every llm_responded/text
   * reply and completes on control stream_end (or socket close). Never
   * sends a frame. */
  abstract open(runId: string): Observable<AgentFileRunReply>;
}

@Injectable({ providedIn: 'root' })
export class WebSocketAgentFileRunEventsSocket extends AgentFileRunEventsSocket {
  private readonly config: AgentFileRunConfig;

  constructor(
    @Inject(AGENT_FILE_RUN_CONFIG) config: AgentFileRunConfig,
    @Inject(AGENT_RUN_SOCKET_FACTORY) private readonly socketFactory: AgentRunSocketFactory
  ) {
    super();
    this.config = config || { baseUrl: '', bearerToken: '', agentPath: '' };
  }

  open(runId: string): Observable<AgentFileRunReply> {
    return new Observable<AgentFileRunReply>((observer) => {
      const runIdText = String(runId || '').trim();
      if (!runIdText) { observer.complete(); return () => undefined; }
      const url = this.normalizeBaseUrl(this.config.baseUrl)
        + '/api/playground/runs/' + encodeURIComponent(runIdText) + '/events/ws';
      const protocols = ['aetheris.events.v1'];
      const bearer = encodeBearerSubprotocol(this.config.bearerToken);
      if (bearer) { protocols.push('aetheris.bearer.' + bearer); }
      let socket: WebSocket;
      try {
        socket = this.socketFactory(url, protocols);
      } catch (e) {
        observer.error(e);
        return () => undefined;
      }
      socket.onmessage = (message: MessageEvent) => {
        const parsed = parseRunEventFrame(message && message.data);
        if (parsed.end) {
          observer.complete();
          try { socket.close(); } catch (e) { /* already closed */ }
          return;
        }
        if (parsed.reply) {
          observer.next({ rawResponse: parsed.reply });
        }
        // Everything else is ignored — never invented, frames not echoed.
      };
      socket.onerror = () => {
        observer.error(new Error('Agent file-run events socket failed for run ' + runIdText));
      };
      socket.onclose = () => {
        observer.complete();
      };
      return () => {
        socket.onmessage = null as any;
        socket.onerror = null as any;
        socket.onclose = null as any;
        try { socket.close(); } catch (e) { /* already closed */ }
      };
    });
  }

  private normalizeBaseUrl(url: string): string {
    const trimmed = String(url || '').trim().replace(/\/+$/, '');
    return trimmed
      .replace(/^https:\/\//i, 'wss://')
      .replace(/^http:\/\//i, 'ws://');
  }
}
