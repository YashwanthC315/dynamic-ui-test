import { CtHostContextAdapter } from './host-context-adapter.service';
import { feesTransactionsFiltersBrick, feesTransactionsRowsBrick } from '../../fees/ct-bot-view-bricks';
import { studentFocusBrick, studentsManageRowsBrick } from '../../student/ct-bot-view-bricks';
import { applicantFocusBrick } from '../../admissions/ct-bot-view-bricks';

// Typed-any request stubs — the spec only exercises the context bag.
function makePromptRequest(prompt: string): any {
  return { prompt: prompt, context: { app: {}, host: {}, catalog: { itemCount: 0 } } };
}

function makeEventRequest(event: string, action: string): any {
  return { requestId: 'r1', messageId: 'm1', conversationId: 'c1', correlationId: 'x1', event: event, action: action, text: '' };
}

describe('CtHostContextAdapter view bricks (M14-T1/T2)', function () {
  function makeAdapter(bricks: any[] | null): CtHostContextAdapter {
    const ctApi: any = {};
    const sessionToken: any = { readAccessToken: () => 'token' };
    return new CtHostContextAdapter(ctApi, sessionToken, bricks);
  }

  function makeRequest(prompt: string): any {
    return { prompt: prompt, context: {} };
  }

  it('composes context.view from registered bricks on /fees/transactions', function (done) {
    const adapter = makeAdapter([feesTransactionsRowsBrick, feesTransactionsFiltersBrick]);
    const state: any = { fees: { txList: [{ id: 't1', amount: 100 }], queryString: 'q', txSearchTerm: 'a' } };
    adapter.buildOutboundContext(makeRequest('what can you see?'), state, '/fees/transactions')
      .then((bag: any) => {
        expect(bag.view).not.toBeNull();
        expect(bag.view.module).toBe('fees');
        expect(bag.view.screen).toBe('transactions');
        expect(bag.view.rows.length).toBe(1);
        expect(bag.view.filters).toEqual({ query: 'q', searchText: 'a' });
        done();
      })
      .catch(done.fail);
  });

  it('composes context.view from the students rows brick on /admin/student/manage', function (done) {
    const adapter = makeAdapter([studentsManageRowsBrick]);
    const state: any = { student: { response: { StudentList: [{ id: 's1', name: 'Anita Rao' }], TotalPages: 1 } } };
    adapter.buildOutboundContext(makeRequest('what can you see?'), state, '/admin/student/manage')
      .then((bag: any) => {
        expect(bag.view.module).toBe('student');
        expect(bag.view.screen).toBe('manage');
        expect(bag.view.source).toBe('store.student.response.StudentList');
        expect(bag.view.rows).toEqual([{ id: 's1', name: 'Anita Rao' }]);
        done();
      })
      .catch(done.fail);
  });

  it('omits context.view on unregistered routes', function (done) {
    const adapter = makeAdapter([feesTransactionsRowsBrick, feesTransactionsFiltersBrick]);
    const state: any = { fees: { txList: [{ id: 't1' }] } };
    adapter.buildOutboundContext(makeRequest('hello'), state, '/admin/course/manage')
      .then((bag: any) => {
        expect('view' in bag).toBe(false);
        done();
      })
      .catch(done.fail);
  });

  it('omits context.view when no bricks are registered at all', function (done) {
    const adapter = makeAdapter(null);
    const state: any = { fees: { txList: [{ id: 't1' }] } };
    adapter.buildOutboundContext(makeRequest('hello'), state, '/fees/transactions')
      .then((bag: any) => {
        expect('view' in bag).toBe(false);
        done();
      })
      .catch(done.fail);
  });

  it('focus parity: selected student (pre-T2 readFocusFromState keys)', function (done) {
    const adapter = makeAdapter([studentFocusBrick, applicantFocusBrick]);
    const state: any = { student: { selectedStudent: { id: 'stu-1', name: 'Anita Rao' } } };
    adapter.buildOutboundContext(makeRequest('this student'), state, '/fees/transactions')
      .then((bag: any) => {
        expect(bag.focus).toEqual({ type: 'student', id: 'stu-1', label: 'Anita Rao' });
        done();
      })
      .catch(done.fail);
  });

  it('focus parity: selected applicant when no student is selected', function (done) {
    const adapter = makeAdapter([studentFocusBrick, applicantFocusBrick]);
    const state: any = { admissions: { selectedApplicant: { applicationNumber: 'APL-7', name: 'Applicant A' } } };
    adapter.buildOutboundContext(makeRequest('this applicant'), state, '/admissions')
      .then((bag: any) => {
        expect(bag.focus).toEqual({ type: 'applicant', id: 'APL-7', label: 'Applicant A' });
        done();
      })
      .catch(done.fail);
  });

  it('focus parity: nothing selected → context.focus null (present-as-null, pre-T2)', function (done) {
    const adapter = makeAdapter([studentFocusBrick, applicantFocusBrick]);
    adapter.buildOutboundContext(makeRequest('hello'), {}, '/fees/transactions')
      .then((bag: any) => {
        expect('focus' in bag).toBe(true);
        expect(bag.focus).toBeNull();
        done();
      })
      .catch(done.fail);
  });
});

describe('CtHostContextAdapter form options via bricks (M14-T3)', function () {
  function makeAdapter(bricks: any[] | null): CtHostContextAdapter {
    const ctApi: any = {};
    const sessionToken: any = { readAccessToken: () => 'token' };
    return new CtHostContextAdapter(ctApi, sessionToken, bricks);
  }

  function coursesBrick(rows: any[], calls?: { count: number }): any {
    return {
      kind: 'form-options',
      name: 'courses',
      routePattern: '/',
      module: 'student',
      valueField: ['id', 'Id'],
      labelField: ['fullName', 'FullName'],
      select: (state: any) => (state && state.student && Array.isArray(state.student.courseList) ? state.student.courseList : []),
      fallback: (state: any) => {
        if (calls) { calls.count++; }
        return Promise.resolve(rows);
      }
    };
  }

  it('enrol prompt turn attaches formOptions.courses from student.courseList (deduped, capped)', function (done) {
    const adapter = makeAdapter([coursesBrick([])]);
    const state: any = {
      student: { courseList: [{ id: 'c1', fullName: 'PUC I Commerce A' }, { id: 'c1', fullName: 'PUC I Commerce A' }] }
    };
    adapter.buildOutboundContext(makePromptRequest('enroll student'), state, '/home')
      .then((bag: any) => {
        expect(bag.formOptions).toEqual({ courses: [{ value: 'c1', label: 'PUC I Commerce A' }] });
        done();
      })
      .catch(done.fail);
  });

  it('empty courseList → adapter gate awaits the app-owned fallback', function (done) {
    const calls = { count: 0 };
    const adapter = makeAdapter([coursesBrick([{ value: 'c9', label: 'API Course' }], calls)]);
    adapter.buildOutboundContext(makePromptRequest('enroll student'), { student: {} }, '/fees')
      .then((bag: any) => {
        expect(calls.count).toBe(1);
        expect(bag.formOptions).toEqual({ courses: [{ value: 'c9', label: 'API Course' }] });
        done();
      })
      .catch(done.fail);
  });

  it('org-add prompt turn attaches parentOrgs + ownerOrgs', function (done) {
    const orgBricks: any[] = [
      {
        kind: 'form-options', name: 'parentOrgs', routePattern: '/',
        valueField: ['id', 'Id'], labelField: ['name', 'Name'],
        select: (state: any) => (state && state.org && Array.isArray(state.org.firstLevelOrgs) ? state.org.firstLevelOrgs : [])
      },
      {
        kind: 'form-options', name: 'ownerOrgs', routePattern: '/',
        valueField: ['id', 'Id'], labelField: ['name', 'Name'],
        select: (state: any) => (state && state.org && Array.isArray(state.org.firstLevelOrgs) ? state.org.firstLevelOrgs : [])
      }
    ];
    const adapter = makeAdapter(orgBricks);
    const state: any = { org: { firstLevelOrgs: [{ id: 'o1', name: 'Demo Public School' }] } };
    adapter.buildOutboundContext(makePromptRequest('add organization'), state, '/connect')
      .then((bag: any) => {
        expect(bag.formOptions).toEqual({
          parentOrgs: [{ value: 'o1', label: 'Demo Public School' }],
          ownerOrgs: [{ value: 'o1', label: 'Demo Public School' }]
        });
        done();
      })
      .catch(done.fail);
  });

  it('buddy_parse event turn attaches formOptions.courses', function (done) {
    const adapter = makeAdapter([coursesBrick([])]);
    const state: any = { student: { courseList: [{ id: 'c2', fullName: 'PUC II Science B' }] } };
    adapter.buildEventContext(makeEventRequest('buddy_parse', 'student.enrol.parse'), state, '/home')
      .then((bag: any) => {
        expect(bag.formOptions).toEqual({ courses: [{ value: 'c2', label: 'PUC II Science B' }] });
        done();
      })
      .catch(done.fail);
  });

  it('a fees / "what can you see?" turn does NOT gain formOptions', function (done) {
    const adapter = makeAdapter([
      coursesBrick([{ value: 'c1', label: 'Course' }]),
      feesTransactionsRowsBrick,
      feesTransactionsFiltersBrick
    ]);
    const state: any = { fees: { txList: [{ id: 't1', amount: 5 }], queryString: 'q', txSearchTerm: 'a' } };
    adapter.buildOutboundContext(makePromptRequest('what can you see?'), state, '/fees/transactions')
      .then((bag: any) => {
        expect(bag.view.module).toBe('fees');
        expect('formOptions' in bag).toBe(false);
        done();
      })
      .catch(done.fail);
  });

  it('a non-enrol, non-org turn omits formOptions even with bricks present', function (done) {
    const adapter = makeAdapter([coursesBrick([{ value: 'c1', label: 'Course' }])]);
    adapter.buildOutboundContext(makePromptRequest('hello there'), {}, '/home')
      .then((bag: any) => {
        expect('formOptions' in bag).toBe(false);
        done();
      })
      .catch(done.fail);
  });
});
