import { Injectable, Optional, Inject } from '@angular/core';
import { ChatRequest, ChatEmitEventRequest } from './chat-contracts';
import {
  HostContextBag,
  HostModuleFlags,
  HostSurfaceSummary,
  HostActivitySummary
} from './ct-bot-host-protocol';
import { buildContextFocusFromBricks, buildViewSnapshotFromBricks, resolveFormOptionsFromBricks, VIEW_BRICKS, ViewBrick } from './view-bricks';
import { humanizeViewKey, previewValueText } from './view-serializer';
import { MockInstituteService } from './mock-institute.service';
import { CTApi } from '../../service/ct-api';
import { CtBotSessionTokenService } from './ct-bot-session-token.service';

// Abstract adapter type
export abstract class HostContextAdapter {
  abstract buildOutboundContext(request: ChatRequest, latestState: any, routerUrl: string): Promise<HostContextBag>;
  abstract buildEventContext(eventRequest: ChatEmitEventRequest, latestState: any, routerUrl: string): Promise<HostContextBag>;
  /** D1: get_institute_snapshot — the host function the effect runs when
   * the agent decided it needs institute facts. Reuses the same fetch /
   * snapshot shape ({ status, data | reason }) as context.institute. */
  abstract getInstituteSnapshot(latestState: any): Promise<any>;
}

@Injectable()
export class CtHostContextAdapter extends HostContextAdapter {
  private lastOkInstituteSnapshot: any = null;

  constructor(
    private ctApi: CTApi,
    private sessionToken: CtBotSessionTokenService,
    // M14-T1: context.view is composed from app-registered VIEW_BRICKS
    // (see view-bricks.ts). The adapter holds zero module knowledge;
    // with no bricks registered, context.view is omitted.
    @Optional() @Inject(VIEW_BRICKS) private viewBricks: ViewBrick[] | null
  ) { super(); }

  async buildOutboundContext(request: ChatRequest, latestState: any, routerUrl: string): Promise<HostContextBag> {
    const route: string = (routerUrl && String(routerUrl).trim()) ? String(routerUrl) : '/';
    const base = this.buildBaseOutboundContext(request, latestState, routerUrl);
    const withFormOptions = await this.attachFormOptionsForPrompt(base, request && request.prompt, latestState, route);
    // D1/D5a: ordinary turns omit the key entirely. Institute-info /
    // institute-summary prompts run the host function for THIS turn and
    // attach the plain snapshot object (same keys the panel binds) —
    // M11-T5a lets the harness render chat bullets from it. Never sent
    // on any other turn.
    if (this.isInstituteInfoIntent(request && request.prompt)
      || this.isInstituteFieldQuestion(request && request.prompt)) {
      try {
        const snap = await this.loadInstituteSnapshot(latestState);
        return this.attachInstituteContext(withFormOptions, snap);
      } catch (e) {
        return this.attachInstituteContext(withFormOptions, {
          status: 'unavailable',
          reason: 'unexpected_error',
          message: 'Unable to load institute details from the authenticated API.'
        });
      }
    }
    return this.omitInstituteContext(withFormOptions);
  }

  async buildEventContext(eventRequest: ChatEmitEventRequest, latestState: any, routerUrl: string): Promise<HostContextBag> {
    const eventContext = eventRequest.context || {};
    const personaOverride = eventContext && typeof eventContext['persona'] === 'string' ? String(eventContext['persona']) : '';
    const route: string = (routerUrl && String(routerUrl).trim()) ? String(routerUrl) : '/';
    const persona = personaOverride || this.readPersonaFromState(latestState);
    const moduleFlags = this.buildModuleFlags(route);
    const context: HostContextBag = {
      route,
      focus: buildContextFocusFromBricks(this.viewBricks, latestState, route),
      moduleFlags,
      flags: { underFees: moduleFlags.underFees }
    } as any;
    const viewSnapshot = this.buildViewSnapshot(route, latestState);
    if (viewSnapshot) { context.view = viewSnapshot; }
    if (persona) { (context as any).persona = persona; }
    this.attachAgentChatSummaries(context, latestState);
    const merged = Object.assign({}, this.copyContextExtras(eventContext), context);
    // BW-T5: workspace emits (buddy_parse / student.enrol.*) carry the same
    // deduped, capped formOptions.courses as user_message so the rebuilt
    // workspace Course select matches thin enrol (student add) instead of empty.
    const withFormOptions = await this.attachFormOptionsForEvent(merged, eventRequest, latestState, route);
    return this.omitInstituteContext(withFormOptions);
  }

  private buildBaseOutboundContext(request: ChatRequest, latestState: any, routerUrl: string): HostContextBag {
    const hostContext: Record<string, unknown> = request && request.context && request.context.host ? request.context.host : {};
    const route: string = (routerUrl && String(routerUrl).trim()) ? String(routerUrl) : '/';
    const personaFromContext: string = typeof hostContext['persona'] === 'string' ? String(hostContext['persona']) : '';
    const personaFromState = this.readPersonaFromState(latestState);
    const persona: string = personaFromContext || personaFromState;
    const moduleFlags = this.buildModuleFlags(route);
    const context: HostContextBag = {
      route,
      focus: buildContextFocusFromBricks(this.viewBricks, latestState, route),
      moduleFlags: moduleFlags,
      flags: { underFees: moduleFlags.underFees }
    } as any;
    const viewSnapshot = this.buildViewSnapshot(route, latestState);
    if (viewSnapshot) { context.view = viewSnapshot; }
    if (persona) { (context as any).persona = persona; }
    this.attachAgentChatSummaries(context, latestState);
    return Object.assign({}, this.copyContextExtras(hostContext), context);
  }

  /**
   * M14-T1: context.view is composed by the registered view bricks
   * (VIEW_BRICKS) for the current route — no module if/else here.
   * No matching brick → the key is omitted entirely (never {}).
   */
  private buildViewSnapshot(route: string, state: any): HostContextBag['view'] {
    return buildViewSnapshotFromBricks(this.viewBricks, state, route);
  }

  /** M11-T3: bounded pane summaries — surface (open workspace) and
   * activity (Actions log count + last line) derived from the agentChat
   * slice the host already passes in. Missing pane / empty log → the key
   * is omitted. No records blob, no institute data, no form fields. */
  private attachAgentChatSummaries(context: HostContextBag, state: any): HostContextBag {
    const agentChat = state && state.agentChat ? state.agentChat : null;
    if (!agentChat || typeof agentChat !== 'object') {
      return context;
    }
    const active = agentChat.activeSurface;
    if (active && typeof active === 'object' && String((active as any).type || '').trim()) {
      const summary: HostSurfaceSummary = { type: String((active as any).type) };
      if ((active as any).title) { summary.title = String((active as any).title); }
      if ((active as any).id) { summary.id = String((active as any).id); }
      if (String((active as any).type) === 'buddy-enrol-workspace') {
        if (Array.isArray((active as any).records)) { summary.recordCount = (active as any).records.length; }
        if ((active as any).activeRecordId) { summary.activeRecordId = String((active as any).activeRecordId); }
        // M11-T5b: resolve a human label for the active record from the
        // records ALREADY on the store surface (generic display value —
        // labels.name, values.name, then label/title/name keys). No new
        // API calls, no records[] blob on the summary.
        const activeRecordId = String((active as any).activeRecordId || '').trim();
        const records = Array.isArray((active as any).records) ? (active as any).records : [];
        if (activeRecordId && records.length) {
          const record = records.find((candidate: any) => candidate && candidate.id === activeRecordId);
          if (record) {
            const label = this.readRecordDisplayLabel(record);
            if (label) { summary.activeRecordLabel = label; }
          }
        }
      }
      // M11-T6: generic bounded preview from what the surface already
      // holds — institute-style plain data objects, thin-form schema
      // fields + values, and short record labels. No nested blobs, no
      // formOptions dump, no full records array.
      const preview = this.buildSurfacePreview(active);
      if (preview.length) {
        summary.preview = preview;
      }
      (context as any).surface = summary;
    }
    const log = agentChat.activityLog;
    const items = log && Array.isArray(log.items) ? log.items : [];
    if (items.length > 0) {
      const last = items[items.length - 1];
      const activitySummary: HostActivitySummary = { itemCount: items.length };
      if (last && last.kind) { activitySummary.lastKind = String(last.kind); }
      if (last && last.text) { activitySummary.lastText = String(last.text).trim().slice(0, 200); }
      // M12: the Assembler items' save-time payloads (name/course/dob as
      // known at save) ride on the summary for draft composition — a
      // bounded pass-through of what the store already holds, not
      // workspace preview.
      const payloads = items
        .map((item: any) => this.enrichAssemblerItemPayload(
          item && item.payload && typeof item.payload === 'object' ? item.payload : {},
          item && item.recordId ? String(item.recordId) : '',
          active
        ))
        .filter((payload: any) => payload && (payload.name || payload.course || payload.dob))
        .slice(-6);
      if (payloads.length) {
        (activitySummary as any).payloads = payloads;
      }
      // D-detour: the pane is Assembler — send context.assembler (same
      // shape); context.activity remains a one-release fallback.
      (context as any).assembler = activitySummary;
      (context as any).activity = activitySummary;
    }
    return context;
  }

  /** M11-T5b: generic display value for a record — no domain field list.
   * Preference: labels.name → values.name → label → title → name. */
  private readRecordDisplayLabel(record: any): string {
    if (!record || typeof record !== 'object') {
      return '';
    }
    const candidates: any[] = [
      record.labels && typeof record.labels === 'object' ? record.labels['name'] : null,
      record.values && typeof record.values === 'object' ? record.values['name'] : null,
      record.label,
      record.title,
      record.name
    ];
    for (const candidate of candidates) {
      if (candidate !== null && candidate !== undefined && typeof candidate !== 'object') {
        const text = String(candidate).trim();
        if (text) {
          return text;
        }
      }
    }
    return '';
  }

  private static readonly MAX_SURFACE_PREVIEW = 12;

  /** M11-T6: generic bounded preview of the OPEN store surface.Scalars
   * on surface.data, schema field label+value, or short record labels —
   * whatever the surface already carries. No nested blobs, no records
   * array, no formOptions. Omitted keys would be empty. */
  private buildSurfacePreview(surface: any): Array<{ label: string; value: string }> {
    const preview: Array<{ label: string; value: string }> = [];
    if (!surface || typeof surface !== 'object') {
      return preview;
    }
    const push = (label: string, value: any): void => {
      const text = previewValueText(value);
      if (!text || preview.length >= CtHostContextAdapter.MAX_SURFACE_PREVIEW) {
        return;
      }
      preview.push({ label: label, value: text });
    };
    const data = surface.data && typeof surface.data === 'object' && !Array.isArray(surface.data)
      ? surface.data as Record<string, unknown>
      : null;
    if (data && Object.keys(data).length) {
      Object.keys(data).forEach((key) => {
        const value = data[key];
        if (value && typeof value === 'object' && !Array.isArray(value)) {
          // nested objects (address-like maps) join their non-empty parts
          const parts = Object.keys(value)
            .map((part) => previewValueText(value[part]))
            .filter((part) => !!part)
            .join(', ');
          push(humanizeViewKey(key), parts);
          return;
        }
        push(humanizeViewKey(key), value);
      });
      return preview;
    }
    const fields = surface.schema && Array.isArray(surface.schema.fields) ? surface.schema.fields : null;
    if (fields && surface.data && typeof surface.data === 'object') {
      fields.forEach((field: any) => {
        if (!field || !field.id) {
          return;
        }
        push(field.label || humanizeViewKey(field.id), surface.data[field.id]);
      });
      return preview;
    }
    const records = Array.isArray(surface.records) ? surface.records : [];
    records.slice(0, 5).forEach((record: any, index: number) => {
      const label = this.readRecordDisplayLabel(record);
      if (label) {
        preview.push({ label: 'Record ' + (index + 1), value: label });
      }
    });
    return preview;
  }

  private copyContextExtras(source: Record<string, unknown>): Record<string, unknown> {
    const extras: Record<string, unknown> = {};
    if (!source || typeof source !== 'object') { return extras; }
    Object.keys(source).forEach((key: string) => {
      if (key === 'route' || key === 'persona' || key === 'focus' || key === 'flags' || key === 'moduleFlags' || key === 'view' || key === 'fees' || key === 'institute' || key === 'formOptions') {
        return;
      }
      extras[key] = source[key];
    });
    return extras;
  }

  private readPersonaFromState(state: any): string {
    const appState = state && state.app;
    const currentPersona = appState && appState.currentPersona;
    const title = currentPersona && currentPersona.title;
    const text = typeof title === 'string' ? title.trim() : '';
    return text;
  }

  private buildModuleFlags(route: string): HostModuleFlags {
    const normalizedRoute = (route || '').trim().toLowerCase();
    return {
      underFees: normalizedRoute.indexOf('/fees') === 0,
      underConnect: normalizedRoute.indexOf('/connect') === 0,
      underStudent: normalizedRoute.indexOf('/admin/student') === 0 || normalizedRoute.indexOf('/student') === 0
    };
  }

  private omitInstituteContext(bag: HostContextBag): HostContextBag {
    this.clearInstituteCacheIfUnauthenticated();
    const next = Object.assign({}, bag) as any;
    delete next.institute;
    console.info('[ct-bot-host] institute context present=false source=omitted');
    return next;
  }

  /** D1: a status hint only — never address/year/phone on the wire; the
   * card fields are fetched host-side by get_institute_snapshot. */
  private attachInstituteHint(bag: HostContextBag): HostContextBag {
    this.clearInstituteCacheIfUnauthenticated();
    const next = Object.assign({}, bag) as any;
    next.institute = { status: 'available' };
    return next;
  }

  private attachInstituteContext(bag: HostContextBag, freshSnapshot: any): HostContextBag {
    this.clearInstituteCacheIfUnauthenticated();
    const inbound = bag && (bag as any).institute;
    if (this.isOkInstituteSnapshot(inbound) && !this.lastOkInstituteSnapshot) {
      this.lastOkInstituteSnapshot = this.cloneInstituteSnapshot(inbound);
    }
    if (this.isOkInstituteSnapshot(freshSnapshot)) {
      this.lastOkInstituteSnapshot = this.cloneInstituteSnapshot(freshSnapshot);
      console.info('[ct-bot-host] institute context present=true status=ok source=fresh');
      return Object.assign({}, bag, { institute: freshSnapshot });
    }
    if (this.isOkInstituteSnapshot(this.lastOkInstituteSnapshot)) {
      console.info('[ct-bot-host] institute context present=true status=ok source=cache');
      return Object.assign({}, bag, { institute: this.lastOkInstituteSnapshot });
    }
    if (freshSnapshot) {
      console.info(
        '[ct-bot-host] institute context present=true status=%s source=fresh',
        freshSnapshot.status || '(none)'
      );
      return Object.assign({}, bag, { institute: freshSnapshot });
    }
    if (inbound) {
      console.info(
        '[ct-bot-host] institute context present=true status=%s source=inbound',
        inbound.status || '(none)'
      );
      return bag;
    }
    return bag;
  }

  private isOkInstituteSnapshot(snapshot: any): boolean {
    return !!(
      snapshot
      && typeof snapshot === 'object'
      && snapshot.status === 'ok'
      && snapshot.data
      && typeof snapshot.data === 'object'
    );
  }

  private cloneInstituteSnapshot(snapshot: any): any {
    try {
      return JSON.parse(JSON.stringify(snapshot));
    } catch (error) {
      return snapshot;
    }
  }

  private clearInstituteCacheIfUnauthenticated(): void {
    const token = this.sessionToken && typeof this.sessionToken.readAccessToken === 'function'
      ? this.sessionToken.readAccessToken()
      : '';
    if (!token) {
      this.lastOkInstituteSnapshot = null;
    }
  }

  private omitFormOptions(bag: HostContextBag): HostContextBag {
    const next = Object.assign({}, bag) as any;
    delete next.formOptions;
    return next;
  }

  private async attachFormOptionsForEvent(bag: HostContextBag, eventRequest: ChatEmitEventRequest, state: any, route: string): Promise<HostContextBag> {
    const cleared = this.omitFormOptions(bag);
    if (!this.isStudentEnrolEvent(eventRequest)) { return cleared; }
    // BW-T5: workspace emits (buddy_parse / student.enrol.*) carry the same
    // deduped, capped formOptions.courses as user_message so the rebuilt
    // workspace Course select matches thin enrol (student add) instead of empty.
    return this.attachFormOptionsByName(cleared, state, route, ['courses']);
  }

  private isStudentEnrolEvent(eventRequest: ChatEmitEventRequest): boolean {
    const eventName = String(eventRequest && eventRequest.event || '').trim();
    const action = String(eventRequest && eventRequest.action || '').trim();
    return eventName === 'buddy_parse' || action.indexOf('student.enrol') === 0;
  }

  private async attachFormOptionsForPrompt(bag: HostContextBag, prompt: string, state: any, route: string): Promise<HostContextBag> {
    const cleared = this.omitFormOptions(bag);
    if (this.isStudentEnrolIntent(prompt)) {
      return this.attachFormOptionsByName(cleared, state, route, ['courses']);
    }
    if (this.isOrgAddIntent(prompt)) {
      return this.attachFormOptionsByName(cleared, state, route, ['parentOrgs', 'ownerOrgs']);
    }
    return cleared;
  }

  /**
   * M14-T3: WHAT to attach comes from registered form-options bricks
   * (VIEW_BRICKS) — the adapter holds no slice names, no flatten, no
   * dedup. The intent gate above stays the WHEN (prompt regexes /
   * event names unchanged); every non-gated turn has already deleted
   * the formOptions key (omitFormOptions).
   */
  private async attachFormOptionsByName(bag: HostContextBag, state: any, route: string, names: string[]): Promise<HostContextBag> {
    const options = await resolveFormOptionsFromBricks(this.viewBricks, state, route, names);
    if (options && Object.keys(options).length) {
      return Object.assign({}, bag, { formOptions: options });
    }
    return bag;
  }

  private isStudentEnrolIntent(text: string): boolean {
    const normalized = String(text || '').trim().toLowerCase();
    if (!normalized) { return false; }
    return /(^|\b)(enroll\s+student|enrol\s+student|add\s+student|student\s+enrollment|student\s+enrolment)(\b|$)/.test(normalized);
  }

  private isOrgAddIntent(text: string): boolean {
    const normalized = String(text || '').trim().toLowerCase();
    if (!normalized) { return false; }
    return /(^|\b)(add\s+org|add\s+organization|add\s+organisation)(\b|$)/.test(normalized);
  }

  private isInstituteInfoIntent(text: string): boolean {
    const normalized = typeof text === 'string' ? text.toLowerCase() : '';
    if (!normalized.trim()) { return false; }
    if (/\b(inst|institute)\s+(info|information|details?)\b/.test(normalized)) { return true; }
    if (/\b(org|organization|organisation)\s+(info|information|details?)\b/.test(normalized)) { return true; }
    if (/\bschool\s+(info|information|details?)\b/.test(normalized)) { return true; }
    if (/(tell me about|about)\s+(the\s+)?(inst|institute|org|organization|organisation|school)\b/.test(normalized)) { return true; }
    if (/(info|information|details?)\s+(about|on)\s+(the\s+)?(inst|institute|org|organization|organisation|school)\b/.test(normalized)) { return true; }
    return false;
  }

  private isInstituteFieldQuestion(text: string): boolean {
    const normalized = typeof text === 'string' ? text.toLowerCase() : '';
    if (!normalized.trim()) { return false; }
    if (!/\b(institute|inst|school|org|organization|organisation)\b/.test(normalized)) { return false; }
    if (/\b(short\s*name|shortname)\b/.test(normalized)) { return true; }
    if (/\b(academic\s*year|acad(?:emic)?\s*year)\b/.test(normalized)) { return true; }
    if (/\baddress\b/.test(normalized)) { return true; }
    if (/\bstatus\b/.test(normalized)) { return true; }
    if (/\bname\b/.test(normalized) && !/\b(info|information|details?)\b/.test(normalized)) { return true; }
    return false;
  }

  private readStringField(source: any, keys: string[]): string {
    if (!source || typeof source !== 'object') { return ''; }
    for (let i = 0; i < keys.length; i++) {
      const key = keys[i];
      const value = source[key];
      if (value === null || value === undefined) { continue; }
      const text = String(value).trim();
      if (text) { return text; }
    }
    return '';
  }

  private formatAddress(institute: any): string {
    const address = institute && (institute.address || institute.Address || institute.addressLine || institute.AddressLine);
    if (typeof address === 'string') { return address.trim(); }
    if (!address || typeof address !== 'object') { return ''; }
    return [
      this.readStringField(address, ['line1', 'Line1', 'line']),
      this.readStringField(address, ['line2', 'Line2']),
      this.readStringField(address, ['city', 'City']),
      this.readStringField(address, ['state', 'State']),
      this.readStringField(address, ['pincode', 'Pincode', 'pinCode', 'PinCode', 'postalCode', 'PostalCode']),
      this.readStringField(address, ['country', 'Country'])
    ].filter((part: string) => !!part).join(', ');
  }

  /** D1: get_institute_snapshot host function — reuses the same
   * authenticated fetch already backing context.institute; returns the
   * same snapshot shape ({ status, data | reason }). No new UI. */
  async getInstituteSnapshot(latestState: any): Promise<any> {
    return this.loadInstituteSnapshot(latestState);
  }

  private async loadInstituteSnapshot(state: any): Promise<any> {
    const target = this.resolveInstituteTargetId(state);
    if (!target.id) {
      return { status: 'unavailable', source: target.source, reason: 'institute_id_not_found', message: 'Institute details are unavailable for this session context.' };
    }
    return new Promise((resolve) => {
      this.ctApi.getInst(target.id).subscribe(
        (response: any) => {
          const institute = this.extractInstituteEntity(response);
          if (!institute) {
            resolve({ status: 'unavailable', source: target.source, reason: 'empty_response', message: 'Institute details are unavailable from the API response.' });
            return;
          }
          resolve({ status: 'ok', source: target.source, data: this.toInstituteSnapshotData(institute) });
        },
        (error: any) => {
          resolve({ status: 'unavailable', source: target.source, reason: 'api_error', message: this.readApiErrorMessage(error) });
        }
      );
    });
  }

  private resolveInstituteTargetId(state: any): { id: string; source: string } {
    const selectedInst = state && state.inst && state.inst.selectedInst;
    const selectedInstId = this.readStringField(selectedInst, ['id', 'Id']);
    if (selectedInstId) { return { id: selectedInstId, source: 'state.inst.selectedInst' }; }
    const selectedClient = state && state.org && state.org.selectedClient;
    const selectedClientId = this.readStringField(selectedClient, ['id', 'Id', 'clientId', 'ClientId']);
    if (selectedClientId) { return { id: selectedClientId, source: 'state.org.selectedClient' }; }
    const ctContext = state && state.app && state.app.ctContext;
    const currentPersona = ctContext && ctContext.currentPersona;
    const personaClientId = this.readStringField(currentPersona, ['clientId', 'ClientId', 'id', 'Id']);
    if (personaClientId) { return { id: personaClientId, source: 'state.app.ctContext.currentPersona' }; }
    return { id: '', source: 'none' };
  }

  private extractInstituteEntity(response: any): any {
    if (!response || typeof response !== 'object') { return null; }
    if (response.data && typeof response.data === 'object' && !Array.isArray(response.data)) { return response.data; }
    if (Array.isArray(response.data) && response.data.length && typeof response.data[0] === 'object') { return response.data[0]; }
    if (Array.isArray(response) && response.length && typeof response[0] === 'object') { return response[0]; }
    if (response.id || response.Id || response.name || response.Name) { return response; }
    return null;
  }

  private toInstituteSnapshotData(institute: any): any {
    return {
      id: this.readStringField(institute, ['id', 'Id']),
      name: this.readStringField(institute, ['name', 'Name', 'clientName', 'ClientName']),
      address: this.formatAddress(institute),
      phone: this.readStringField(institute, ['phone', 'Phone', 'mobile', 'Mobile', 'contactNumber', 'ContactNumber']),
      email: this.readStringField(institute, ['email', 'Email', 'emailAddress', 'EmailAddress']),
      website: this.readStringField(institute, ['website', 'Website', 'url', 'Url']),
      shortName: this.readStringField(institute, ['shortName', 'ShortName', 'clientShortName', 'ClientShortName']),
      academicYearFrom: this.readStringField(institute, ['academicYearFrom', 'AcademicYearFrom', 'acadYearFrom']),
      academicYearTo: this.readStringField(institute, ['academicYearTo', 'AcademicYearTo', 'acadYearTo']),
      status: this.readStringField(institute, ['statusAsString', 'StatusAsString', 'status', 'Status']),
      board: this.readStringField(institute, ['board', 'Board', 'boardName', 'BoardName'])
    };
  }

  private readApiErrorMessage(error: any): string {
    if (error && error.error) {
      if (typeof error.error === 'string' && error.error.trim()) { return error.error.trim(); }
      if (typeof error.error.message === 'string' && error.error.message.trim()) { return error.error.message.trim(); }
    }
    if (error && typeof error.message === 'string' && error.message.trim()) { return error.message.trim(); }
    return 'Unable to load institute details from the authenticated API.';
  }

  /**
   * Fill missing name/course/dob on an Assembler item from the matching
   * open workspace record. Course is the human label only — never a UUID.
   */
  private enrichAssemblerItemPayload(payload: any, recordId: string, surface: any): Record<string, unknown> {
    const next: Record<string, unknown> = payload && typeof payload === 'object' ? Object.assign({}, payload) : {};
    const records = surface && String(surface.type || '') === 'buddy-enrol-workspace' && Array.isArray(surface.records)
      ? surface.records
      : [];
    const record = recordId
      ? records.filter((candidate: any) => candidate && candidate.id === recordId)[0]
      : null;
    if (!record) {
      if (next.course && this.looksLikeRawId(String(next.course))) {
        delete next.course;
      }
      return next;
    }
    if (!String(next.name || '').trim()) {
      const name = record.values && record.values.name ? String(record.values.name).trim() : '';
      if (name) { next.name = name; }
    }
    if (!String(next.course || '').trim() || this.looksLikeRawId(String(next.course))) {
      const course = this.readBuddyCourseLabel(record, surface);
      if (course) { next.course = course; }
      else if (this.looksLikeRawId(String(next.course || ''))) { delete next.course; }
    }
    if (!String(next.dob || '').trim()) {
      const dob = record.values && record.values.dob ? String(record.values.dob).trim() : '';
      if (dob) { next.dob = dob; }
    }
    return next;
  }

  private readBuddyCourseLabel(record: any, surface: any): string {
    const labeled = record && record.labels && record.labels['courseId']
      ? String(record.labels['courseId']).trim()
      : '';
    if (labeled && !this.looksLikeRawId(labeled)) {
      return labeled;
    }
    const raw = record && record.values ? String(record.values['courseId'] || '').trim() : '';
    const fromOptions = this.matchCourseOptionLabel(raw, surface);
    if (fromOptions) {
      return fromOptions;
    }
    if (raw && !this.looksLikeRawId(raw)) {
      return raw;
    }
    const rejected = record && Array.isArray(record.rejected) ? record.rejected : [];
    for (let i = 0; i < rejected.length; i++) {
      const fieldId = String(rejected[i] && rejected[i].fieldId || '').trim();
      const text = String(rejected[i] && rejected[i].text || '').trim();
      if (fieldId !== 'courseId' || !text) {
        continue;
      }
      const rejectedMatch = this.matchCourseOptionLabel(text, surface);
      if (rejectedMatch) {
        return rejectedMatch;
      }
      if (!this.looksLikeRawId(text)) {
        return text;
      }
    }
    return '';
  }

  private matchCourseOptionLabel(raw: string, surface: any): string {
    const value = String(raw || '').trim();
    if (!value) {
      return '';
    }
    const fields = surface && Array.isArray(surface.fields) ? surface.fields : [];
    const field = fields.filter((candidate: any) => candidate && candidate.id === 'courseId')[0];
    const options = field && Array.isArray(field.options) ? field.options : [];
    const norm = value.toLowerCase();
    for (let i = 0; i < options.length; i++) {
      const option = options[i];
      const optValue = String(option && option.value || '').trim();
      const optLabel = String(option && option.label || '').trim();
      if (optValue === value || optLabel === value
        || optValue.toLowerCase() === norm || optLabel.toLowerCase() === norm) {
        return optLabel || optValue;
      }
    }
    return '';
  }

  private looksLikeRawId(value: string): boolean {
    const text = String(value || '').trim();
    if (!text) {
      return true;
    }
    if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(text)) {
      return true;
    }
    if (/^[0-9a-f]{16,}$/i.test(text)) {
      return true;
    }
    return false;
  }
}
