import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../../../env/environment';
import { CtBotSessionTokenService } from './ct-bot-session-token.service';

export interface ConversationListItem {
  id: string;
  title: string;
  updatedAt: string;
}

export interface ConversationListResponse {
  items: ConversationListItem[];
}

export interface PersistedAssistantPayload {
  hostProtocolVersion?: string;
  correlationId?: string | null;
  messages: any[];
  actions: any[];
}

export interface PersistedConversationMessage {
  id: string;
  role: 'user' | 'assistant';
  createdAt: string;
  text?: string;
  userMessageId?: string;
  assistant?: PersistedAssistantPayload | null;
}

export interface ConversationDetailResponse {
  id: string;
  title: string;
  messages: PersistedConversationMessage[];
}

@Injectable({ providedIn: 'root' })
export class CtBotConversationHistoryService {
  private readonly harnessApiUrl: string;

  constructor(
    private readonly http: HttpClient,
    private readonly sessionToken: CtBotSessionTokenService
  ) {
    const configuredApiUrl = (environment as any).AGENT_HARNESS_API_URL;
    const configuredWsUrl = (environment as any).AGENT_HARNESS_WS_URL || 'ws://localhost:8787';
    this.harnessApiUrl = this.normalizeApiBaseUrl(configuredApiUrl || this.toHttpBaseUrl(configuredWsUrl));
  }

  listConversations(): Observable<ConversationListResponse> {
    return this.http.get<ConversationListResponse>(
      this.harnessApiUrl + '/v1/conversations',
      { headers: this.buildHeaders() }
    );
  }

  loadConversation(conversationId: string): Observable<ConversationDetailResponse> {
    return this.http.get<ConversationDetailResponse>(
      this.harnessApiUrl + '/v1/conversations/' + encodeURIComponent(conversationId),
      { headers: this.buildHeaders() }
    );
  }

  createConversation(conversationId: string, title: string = 'New chat'): Observable<{ id: string; title: string }> {
    return this.http.post<{ id: string; title: string }>(
      this.harnessApiUrl + '/v1/conversations',
      { id: conversationId, title: title },
      { headers: this.buildHeaders() }
    );
  }

  /**
   * M8-T1: persist the Actions (activity) log snapshot for one conversation
   * (write path only — same identity as chat history: AccessToken /
   * Authorization from CtBotSessionTokenService).
   */
  saveActivityLog(conversationId: string, activityLog: any): Observable<{ saved: boolean; updatedAt?: string }> {
    return this.http.put<{ saved: boolean; updatedAt?: string }>(
      this.harnessApiUrl + '/v1/conversations/' + encodeURIComponent(conversationId) + '/activity-log',
      { conversationId: conversationId, activityLog: activityLog },
      { headers: this.buildHeaders() }
    );
  }

  /**
   * M8-T2: restore the stored Actions log for one conversation. 404 when
   * nothing was stored (the caller falls back to an empty pane); the
   * harness 401s another user's conversation and never invents demo rows.
   */
  loadActivityLog(conversationId: string): Observable<{ conversationId?: string; updatedAt?: string; activityLog?: any }> {
    return this.http.get<{ conversationId?: string; updatedAt?: string; activityLog?: any }>(
      this.harnessApiUrl + '/v1/conversations/' + encodeURIComponent(conversationId) + '/activity-log',
      { headers: this.buildHeaders() }
    );
  }

  /**
   * M8-T3: persist the enrol Workspace snapshot (thin enrol form or buddy
   * workspace) for one conversation — write path only, same identity as
   * chat history / activity logs (AccessToken / Authorization from
   * CtBotSessionTokenService).
   */
  saveWorkspaceSnapshot(conversationId: string, surface: any): Observable<{ saved: boolean; updatedAt?: string }> {
    return this.http.put<{ saved: boolean; updatedAt?: string }>(
      this.harnessApiUrl + '/v1/conversations/' + encodeURIComponent(conversationId) + '/workspace-snapshot',
      { conversationId: conversationId, surface: surface },
      { headers: this.buildHeaders() }
    );
  }

  /**
   * M8-T4: restore the stored enrol Workspace snapshot for one conversation.
   * 404 when nothing was stored (the caller keeps today's new-surface
   * behaviour); the harness 401s another user's conversation and never
   * invents records.
   */
  loadWorkspaceSnapshot(conversationId: string): Observable<{ conversationId?: string; updatedAt?: string; surface?: any }> {
    return this.http.get<{ conversationId?: string; updatedAt?: string; surface?: any }>(
      this.harnessApiUrl + '/v1/conversations/' + encodeURIComponent(conversationId) + '/workspace-snapshot',
      { headers: this.buildHeaders() }
    );
  }

  private buildHeaders(): HttpHeaders {
    const token = this.sessionToken.readAccessToken();
    if (!token) {
      return new HttpHeaders();
    }
    return new HttpHeaders({
      AccessToken: token,
      Authorization: 'Bearer ' + token
    });
  }

  private toHttpBaseUrl(wsUrl: string): string {
    const trimmed = String(wsUrl || '').trim();
    if (!trimmed) {
      return 'http://localhost:8787';
    }
    if (trimmed.indexOf('ws://') === 0) {
      return 'http://' + trimmed.slice('ws://'.length).replace(/\/+$/, '');
    }
    if (trimmed.indexOf('wss://') === 0) {
      return 'https://' + trimmed.slice('wss://'.length).replace(/\/+$/, '');
    }
    return trimmed.replace(/\/+$/, '');
  }

  private normalizeApiBaseUrl(value: string): string {
    return String(value || 'http://localhost:8787').trim().replace(/\/+$/, '');
  }
}
