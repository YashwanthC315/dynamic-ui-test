import { Injectable, OnDestroy } from '@angular/core';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs/Subscription';
import { environment } from '../../../../env/environment';
import * as rootReducer from '../../rootReducer';

@Injectable({ providedIn: 'root' })
export class CtBotSessionTokenService implements OnDestroy {
  private latestState: any = null;
  private readonly stateSubscription: Subscription;
  private readonly tokenStorageKeys: string[];

  constructor(private readonly store: Store<rootReducer.State>) {
    this.stateSubscription = this.store.subscribe((state: any) => this.latestState = state);
    const configuredKey = String((environment as any).ACCESS_TOKEN || '').trim();
    this.tokenStorageKeys = configuredKey && configuredKey !== 'accessToken'
      ? [configuredKey, 'accessToken']
      : ['accessToken'];
  }

  ngOnDestroy(): void {
    this.stateSubscription.unsubscribe();
  }

  readAccessToken(): string {
    const stateToken = this.readStateToken();
    if (stateToken) {
      return stateToken;
    }

    for (let index = 0; index < this.tokenStorageKeys.length; index++) {
      const sessionToken = this.readSessionStorageValue(this.tokenStorageKeys[index]);
      if (sessionToken) {
        return sessionToken;
      }
    }

    return '';
  }

  private readStateToken(): string {
    const appState = this.latestState && this.latestState.app;
    if (!appState || typeof appState !== 'object') {
      return '';
    }
    const value = appState.accessToken;
    if (value === null || value === undefined) {
      return '';
    }
    return String(value).trim();
  }

  private readSessionStorageValue(key: string): string {
    if (!key) {
      return '';
    }
    try {
      return String(sessionStorage.getItem(key) || '').trim();
    } catch (error) {
      return '';
    }
  }
}
