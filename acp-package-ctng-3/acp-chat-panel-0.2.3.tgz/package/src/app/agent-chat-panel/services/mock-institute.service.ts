import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

export interface InstituteInfo {
  id: string;
  name: string;
  address: string;
  phone?: string;
  email?: string;
  website?: string;
}

@Injectable({ providedIn: 'root' })
export class MockInstituteService {
  constructor() {}

  fetchInstituteInfo(): Observable<InstituteInfo> {
    const mock: InstituteInfo = {
      id: 'institute_001',
      name: 'Sample Institute of Technology',
      address: '123 Campus Drive, Sample City, State, 123456',
      phone: '+1-555-1234',
      email: 'info@sampleinstitute.edu',
      website: 'https://www.sampleinstitute.edu',
    };
    return of(mock);
  }
}
