import { buildFilteredHarnessTools } from './frontend-agent-tool-filter';

describe('frontend-agent-tool-filter', function () {
  function makeDefinitions(): any[] {
    return [
      { name: 'get_current_view', description: 'Current view', input_schema: { type: 'object', properties: {} } },
      { name: 'get_route_focus_context', description: 'Route focus', input_schema: { type: 'object', properties: {} } },
      { name: 'get_ui_context', description: 'UI context', input_schema: { type: 'object', properties: {} } },
      {
        name: 'get_current_list_snapshot',
        description: 'List snapshot',
        input_schema: {
          type: 'object',
          properties: {
            top_n: { type: 'integer', minimum: 1, maximum: 50 },
            preview_limit: { type: 'integer', minimum: 1, maximum: 10 }
          }
        }
      },
      { name: 'get_current_entity_focus', description: 'Entity focus', input_schema: { type: 'object', properties: {} } },
      { name: 'get_screen_context_signals', description: 'Signals', input_schema: { type: 'object', properties: {} } },
      {
        name: 'get_current_filters_and_search',
        description: 'Loose schema',
        input_schema: {
          type: 'object',
          properties: {
            looseObject: { properties: { nested: {} } },
            list: { type: 'array' },
            choice: { anyOf: [{ properties: { foo: {} } }, { type: 'string' }] }
          }
        }
      },
      {
        name: 'record_fee_payment',
        description: 'Record payment',
        input_schema: {
          type: 'object',
          properties: { studentId: { type: 'string' }, installmentsPaid: { type: 'array' } },
          required: ['studentId', 'installmentsPaid']
        }
      }
    ];
  }

  it('includes core orientation tools and call_backend_agent on non-fees routes', function () {
    var router = { url: '/admin/dashboard' } as any;
    var tools = buildFilteredHarnessTools(router, makeDefinitions() as any);
    var names = tools.map(function (tool: any) { return tool.name; });

    expect(names).toContain('get_current_view');
    expect(names).toContain('get_route_focus_context');
    expect(names).toContain('call_backend_agent');
    expect(names).not.toContain('record_fee_payment');
  });

  it('adds fees tools on fees routes and preserves registered schemas', function () {
    var router = { url: '/fees/transactions?status=due' } as any;
    var tools = buildFilteredHarnessTools(router, makeDefinitions() as any);
    var byName: any = {};
    tools.forEach(function (tool: any) { byName[tool.name] = tool; });

    expect(byName.record_fee_payment).toBeDefined();
    expect(byName.record_fee_payment.input_schema.properties.studentId.type).toBe('string');
    expect(byName.record_fee_payment.input_schema.required).toContain('studentId');
    expect(byName.get_current_list_snapshot.input_schema.properties.top_n.maximum).toBe(50);
  });

  it('injects a structured schema for call_backend_agent', function () {
    var router = { url: '/home' } as any;
    var tools = buildFilteredHarnessTools(router, makeDefinitions() as any);
    var bridge = tools.find(function (tool: any) { return tool.name === 'call_backend_agent'; }) as any;

    expect(bridge).toBeDefined();
    expect(bridge.input_schema.type).toBe('object');
    expect(bridge.input_schema.properties.agent.type).toBe('object');
    expect(bridge.input_schema.properties.input.type).toBe('object');
    expect(bridge.input_schema.properties.options.type).toBe('object');
    expect(bridge.input_schema.required).toContain('agent');
    expect(bridge.input_schema.required).toContain('input');
  });

  it('normalizes schema members so properties and union members have explicit types', function () {
    var router = { url: '/fees/transactions' } as any;
    var tools = buildFilteredHarnessTools(router, makeDefinitions() as any);
    var tool = tools.find(function (entry: any) { return entry.name === 'get_current_filters_and_search'; }) as any;

    expect(tool.input_schema.type).toBe('object');
    expect(tool.input_schema.properties.looseObject.type).toBe('object');
    expect(tool.input_schema.properties.looseObject.properties.nested.type).toBe('string');
    expect(tool.input_schema.properties.list.type).toBe('array');
    expect(tool.input_schema.properties.list.items.type).toBe('object');
    expect(tool.input_schema.properties.choice.anyOf[0].type).toBe('object');
    expect(tool.input_schema.properties.choice.anyOf[1].type).toBe('string');
  });
});
