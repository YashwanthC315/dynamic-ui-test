import { ComponentFactoryResolver, ComponentRef, Injectable, ViewContainerRef } from '@angular/core';

import { InstitutePanelFieldComponent } from '../components/institute-panel-field.component';

export interface InstituteFieldViewModel {
  label: string;
  displayValue: string;
  isLink: boolean;
  href: string;
  wide: boolean;
}

@Injectable({ providedIn: 'root' })
export class InstituteSurfaceRendererService {
  private createdComponents: Array<ComponentRef<InstitutePanelFieldComponent>> = [];
  private viewContainerRef: ViewContainerRef | null = null;

  constructor(private readonly componentFactoryResolver: ComponentFactoryResolver) {}

  renderFields(fields: InstituteFieldViewModel[], container: ViewContainerRef): void {
    if (!container) {
      return;
    }

    this.viewContainerRef = container;
    this.clearAllComponents();

    const factory = this.componentFactoryResolver.resolveComponentFactory(InstitutePanelFieldComponent);
    fields.forEach((field) => {
      const componentRef = container.createComponent(factory);
      componentRef.instance.label = field.label;
      componentRef.instance.displayValue = field.displayValue;
      componentRef.instance.isLink = field.isLink;
      componentRef.instance.href = field.href;
      componentRef.instance.wide = field.wide;
      componentRef.changeDetectorRef.detectChanges();
      this.createdComponents.push(componentRef);
    });
  }

  clearAllComponents(): void {
    this.createdComponents.forEach((componentRef) => componentRef.destroy());
    this.createdComponents = [];

    if (this.viewContainerRef) {
      this.viewContainerRef.clear();
    }
  }
}
