import { InstituteInfo } from './mock-institute.service';

// Transport-layer surface contracts for dynamic UI components driven by harness.
// Keep these shapes domain-agnostic at the top level; concrete domain interfaces (like InstituteInfo)
// are used only inside `props`/`data` fields.

export type SurfaceType = 'institute-summary' | 'table' | 'org-add-form' | 'student-enrol-form' | 'buddy-enrol-workspace' | 'activity-log';

export interface BaseSurface {
  // Transport discriminator (used by the dynamic renderer to pick a component)
  type: SurfaceType | string;
  // Optional unique id for the surface instance
  id?: string;
  // Optional human title displayed by host or component
  title?: string;
}

export interface InstituteSummarySurface extends BaseSurface {
  type: 'institute-summary';
  // Concrete data for institute panel; reuse existing domain interface
  data: InstituteInfo | Record<string, unknown>;
  // Optional schema for fully dynamic field rendering.
  schema?: {
    titlePath?: string;
    subtitlePath?: string;
    fields?: Array<{
      id: string;
      label: string;
      path?: string;
      type?: 'text' | 'link' | 'address' | 'academicYear' | 'status';
      wide?: boolean;
    }>;
  };
}

export interface TableColumn {
  id: string;
  label?: string;
  // hint for rendering/formatting
  type?: 'string' | 'number' | 'date' | 'boolean';
}

export type TableRow = Record<string, string | number | boolean | null>;

export interface TableSurface extends BaseSurface {
  type: 'table';
  columns: TableColumn[];
  rows: TableRow[];
  // optional actions per-row (e.g. view/edit)
  rowActions?: Array<{
    id: string;
    label: string;
    // payload is opaque transport data for the host to interpret
    payload?: Record<string, unknown>;
  }>;
}

export type OrgAddFormFieldType = 'text' | 'select';

export interface OrgAddFormFieldOption {
  label: string;
  value: string;
}

/**
 * M3 org-add field (harness JSON).
 * Renderer (`org-add-field`): text | select.
 */
export interface OrgAddFormField {
  id: string;
  label: string;
  type?: OrgAddFormFieldType;
  required?: boolean;
  maxLength?: number;
  placeholder?: string;
  helperText?: string;
  options?: OrgAddFormFieldOption[];
  /** FE lookup hint; harness demo should send inline `options` instead. */
  optionsSource?: 'firstLevelOrgs' | 'modules';
}

export interface OrgAddFormSchema {
  fields?: OrgAddFormField[];
}

/** Prefill keys; thin demo uses name / shortName. Extra keys allowed for later optional fields. */
export interface OrgAddFormValues {
  name?: string;
  shortName?: string;
  parentId?: string;
  ownerId?: string;
  [key: string]: unknown;
}

/**
 * Host emit_event:
 * - event: 'form_submit', action: submitAction, correlationId, values — persist via CTApi.
 * - event: 'form_continue', action, correlationId, values — prefill and open the full add form.
 * Prefer correlationId === surface.id when both are present.
 */
export interface OrgAddFormSubmitMeta {
  formId?: string;
  submitAction?: string;
  correlationId?: string;
}

export interface OrgAddFormSurface extends BaseSurface, OrgAddFormSubmitMeta {
  type: 'org-add-form';
  /** Initial values (same as component `initialValues`). */
  data?: OrgAddFormValues;
  schema?: OrgAddFormSchema;
}

export type StudentEnrolFormFieldType = 'text' | 'select' | 'radio' | 'email' | 'tel' | 'date';

export interface StudentEnrolFormFieldOption {
  label: string;
  value: string;
}

/**
 * M3 student-enrol field (harness JSON).
 * Renderer (`student-enrol-field`): text | email | tel | date (native input) | select | radio.
 * In-chat `AssistantFormBlock` / ChatBlock.form is text | number | select only (no radio/date/email).
 */
export interface StudentEnrolFormField {
  id: string;
  label: string;
  type?: StudentEnrolFormFieldType;
  required?: boolean;
  maxLength?: number;
  placeholder?: string;
  helperText?: string;
  options?: StudentEnrolFormFieldOption[];
  /** FE lookup hint; harness demo should send inline `options` instead. */
  optionsSource?: 'courses' | 'gender';
}

export interface StudentEnrolFormSchema {
  fields?: StudentEnrolFormField[];
}

/** Prefill keys for required enrol fields. Extra keys allowed for later optional fields. */
export interface StudentEnrolFormValues {
  name?: string;
  dob?: string;
  gender?: string;
  courseId?: string;
  [key: string]: unknown;
}

/**
 * Host emit_event:
 * - event: 'form_submit' — persist via the real student-add save path.
 * - event: 'form_continue' — prefill and open `/admin/student/add`.
 * Prefer correlationId === surface.id when both are present.
 */
export interface StudentEnrolFormSubmitMeta {
  formId?: string;
  submitAction?: string;
  correlationId?: string;
}

export interface StudentEnrolFormSurface extends BaseSurface, StudentEnrolFormSubmitMeta {
  type: 'student-enrol-form';
  /** Initial values (same as component `initialValues`). */
  data?: StudentEnrolFormValues;
  schema?: StudentEnrolFormSchema;
}

/**
 * BW-T0 buddy workspace events (host emit_event → harness).
 * - event: 'buddy_parse',     action: 'student.enrol.parse'  — values: { text } (Prepare click; agent owns parse).
 * - event: 'record_selected', action: 'student.enrol.select' — values: { recordId }.
 * - event: 'field_patched',   action: 'student.enrol.patch'  — values: { recordId, fieldId, value } (later).
 * - event: 'form_submit',     action: 'student.enrol.submit' — values: active record values (existing event).
 * Search, pager, and local drafts stay host-only; no events for them.
 */
export type BuddyEnrolWorkspaceEventType =
  | 'buddy_parse'
  | 'record_selected'
  | 'field_patched'
  | 'form_submit'
  /** H-validate: Check runs the validation child hop (fields + records in, flags out). */
  | 'buddy_validate';

export type BuddyEnrolWorkspaceActionType =
  | 'student.enrol.parse'
  | 'student.enrol.select'
  | 'student.enrol.patch'
  | 'student.enrol.submit'
  /** H-validate: Check action — same hop, payload = current fields + records. */
  | 'student.enrol.validate';

/** Agent-reported parse rejection (bad date, unresolved course, ...). Never guessed by FE. */
export interface BuddyEnrolRejection {
  fieldId?: string;
  text?: string;
  reason?: string;
}

/** End-exclusive character span into `buddy.text` (agent-owned mapping). */
export interface BuddyTextSpan {
  start: number;
  end: number;
}

/** Where a parsed record and its mapped field tokens live in `buddy.text`. */
export interface BuddyEnrolRecordSource {
  record: BuddyTextSpan;
  fields?: { [fieldId: string]: BuddyTextSpan };
}

/** One parsed student record. `values` uses the agent-defined field ids; FE only projects them. */
export interface BuddyEnrolRecord {
  id: string;
  values: Record<string, string>;
  /** Display labels for resolved values (e.g. courseId → course label). */
  labels?: Record<string, string>;
  rejected?: BuddyEnrolRejection[];
  /** Unmapped text quoted by the agent; kept, never applied. */
  leftovers?: string[];
  valid?: boolean;
  /**
   * H-validate: set by the last Check hop (buddy_validate). Submits follow
   * this flag — before a Check (or after an edit clears it) nothing submits.
   */
  validationChecked?: boolean;
  /** Per-record validation reasons from the last Check (kept for the chip ⚠). */
  validationReasons?: string[];
  /** M9-T2c: persisted/restored save state — the workspace seeds its saved
   * chips from these flags on a fresh bind. */
  saved?: boolean;
  saveFailed?: boolean;
  /** Character spans of the record and its mapped tokens in `buddy.text`; optional for pre-T3.5 records. */
  source?: BuddyEnrolRecordSource;
}

/** Whole-buddy parse summary surfaced beside the fields grid. */
export interface BuddyEnrolParseSummary {
  mapped?: Array<{ fieldId?: string; value?: string }>;
  rejected?: BuddyEnrolRejection[];
  leftovers?: string[];
  /** Coarse input format the agent detected; informational only. */
  format?: 'csv' | 'delimited' | 'lines' | 'prose' | 'mixed';
}

/**
 * Agent-owned buddy enrol workspace: the agent parses buddy text and resolves
 * courses; the FE renders `records[]`, filters/pages them, and mechanically
 * two-way-projects `fields[]` onto the active record.
 */
export interface BuddyEnrolWorkspaceSurface extends BaseSurface, StudentEnrolFormSubmitMeta {
  type: 'buddy-enrol-workspace';
  /** Raw buddy text (source of truth for the agent's next parse). */
  buddy?: { text?: string };
  records: BuddyEnrolRecord[];
  activeRecordId?: string;
  /** Field schema the agent defined; field ids key `BuddyEnrolRecord.values`. */
  fields?: StudentEnrolFormField[];
  parse?: BuddyEnrolParseSummary;
  /**
   * Clerk-facing chrome for the enroll Workspace (payload-driven; the FE
   * falls back to sensible defaults when omitted): title already comes from
   * BaseSurface; helpText explains the flow, inputPlaceholder cues the
   * textarea, prepareLabel names the primary Prepare action.
   */
  helpText?: string;
  inputPlaceholder?: string;
  prepareLabel?: string;
}

/**
 * P0-B result/action panel (activity-log surface) — shared contract only.
 * Purpose: harness-driven activity log for the right panel column (results of
 * sanitize/parse/submit hops), rendered later by a dedicated component.
 * - `items` are human lines (never raw JSON); `kind` picks the tone.
 * - `recordId` links an item to a buddy chip when relevant.
 * - `actions` are opaque to FE: focus a record, emit an internal prompt, or navigate.
 * Institute-specific fields are deliberately excluded; extend via payload later.
 */
export interface ActivityAction {
  id: string;
  label: string;
  type: 'focus_record' | 'internal.prompt' | 'navigate' | 'copy_names' | 'copy_all_names' | 'draft_parent_message';
  payload?: Record<string, unknown>;
}

export interface ActivityItem {
  id: string;
  kind: 'info' | 'success' | 'warning' | 'error';
  /** Human line, never raw JSON. */
  text: string;
  /** Buddy chip id when relevant. */
  recordId?: string;
  /** M12: small save-time metadata authored by the harness authoring hop
   * (e.g. name / course label / dob as known at save) — carried on the
   * Assembler item for draft composition. No extra API. */
  payload?: Record<string, unknown>;
  actions?: ActivityAction[];
}

export interface ActivityLogSurface extends BaseSurface {
  type: 'activity-log';
  items: ActivityItem[];
  /**
   * M5-T3: whole-pane overflow menu catalog (same ActivityAction shape).
   * Payload-driven: when the surface carries the field (even []), the host
   * renders exactly that; when the payload omits it, the host supplies one
   * "Copy all saved names" item as the demo fallback.
   */
  menuActions?: ActivityAction[];
  /**
   * M8-T5: owner pin — the conversation id this snapshot belongs to. The
   * persist write-back PUTs to the PINNED id (never a later active id), so
   * one conversation's log can never be written onto another.
   */
  conversationId?: string;
}

export type AgentSurface =
  | InstituteSummarySurface
  | TableSurface
  | OrgAddFormSurface
  | StudentEnrolFormSurface
  | BuddyEnrolWorkspaceSurface
  | ActivityLogSurface;

/**
 * Org Details on `/admin/org/add`: Name, Short Name, Parent, Owner.
 * - name: HTML required; Save disabled when empty.
 * - shortName: has-error when empty; maxlength 6.
 * - parentId / ownerId: optional selects (None/empty allowed).
 */
export const EXAMPLE_ORG_ADD_FORM_SURFACE: OrgAddFormSurface = {
  type: 'org-add-form',
  id: 'surface_org_add_demo',
  title: 'Add Organization',
  formId: 'org-add-thin',
  submitAction: 'org.add.submit',
  correlationId: 'surface_org_add_demo',
  data: {
    name: '',
    shortName: '',
    parentId: '',
    ownerId: ''
  },
  schema: {
    fields: [
      { id: 'name', label: 'Name', type: 'text', required: true, maxLength: 50 },
      { id: 'shortName', label: 'Short Name', type: 'text', required: true, maxLength: 6, helperText: 'Up to 6 characters' },
      {
        id: 'parentId',
        label: 'Parent',
        type: 'select',
        placeholder: 'None',
        options: []
      },
      {
        id: 'ownerId',
        label: 'Owner',
        type: 'select',
        placeholder: 'None',
        options: []
      }
    ]
  }
};

/**
 * Thin demo = required fields on `/admin/student/add` only
 * (Save disabled unless name, DOB, gender, course.id; HTML required on those four).
 * Optional enrol fields (studentId, DOA, admission, email, parents, …) are omitted.
 * Runtime today: ChatResponse.surface (activeSurface).
 */
export const EXAMPLE_STUDENT_ENROL_FORM_SURFACE: StudentEnrolFormSurface = {
  type: 'student-enrol-form',
  id: 'surface_stu_enrol_demo',
  title: 'Enroll Student',
  formId: 'student-enrol-thin',
  submitAction: 'student.enrol.submit',
  correlationId: 'surface_stu_enrol_demo',
  data: {
    name: '',
    dob: '',
    gender: '',
    courseId: ''
  },
  schema: {
    fields: [
      { id: 'name', label: 'Name', type: 'text', required: true, maxLength: 50, placeholder: 'first  middle  last' },
      { id: 'dob', label: 'Date Of Birth', type: 'date', required: true, placeholder: 'dd/mm/yyyy' },
      {
        id: 'gender',
        label: 'Gender',
        type: 'select',
        required: true,
        placeholder: '',
        options: [
          { label: 'Female', value: 'Female' },
          { label: 'Male', value: 'Male' }
        ]
      },
      {
        id: 'courseId',
        label: 'Course',
        type: 'select',
        required: true,
        placeholder: '-- Select course --',
        options: []
      }
    ]
  }
};

/**
 * BW-T0 fixture for BW-T1: buddy workspace surface shape emitted by the agent
 * (parse/mapping/course-resolution are agent-owned; FE only renders this JSON).
 */
export const EXAMPLE_BUDDY_ENROL_WORKSPACE: BuddyEnrolWorkspaceSurface = {
  type: 'buddy-enrol-workspace',
  id: 'buddy_ws_1',
  title: 'Enroll students',
  helpText: 'Paste the list below, then click Prepare. Only the selected student is edited.',
  inputPlaceholder: 'Name, date of birth, gender, class — one student per line',
  prepareLabel: 'Prepare',
  formId: 'student-enrol-buddy',
  submitAction: 'student.enrol.submit',
  correlationId: 'buddy_ws_1',
  buddy: {
    text: ''
  },
  records: [
    {
      id: 'r1',
      values: { name: 'Ada Lovelace', dob: '12/03/2014', gender: 'Female', courseId: 'g6' },
      labels: { courseId: 'Grade 6' },
      rejected: [],
      leftovers: [],
      valid: true
    },
    {
      id: 'r2',
      values: { name: 'Grace Hopper', dob: '', gender: 'Female', courseId: '' },
      labels: {},
      rejected: [
        { fieldId: 'dob', text: '31/02/2014', reason: 'Not a valid date.' },
        { fieldId: 'courseId', text: 'Grade 6B', reason: 'Unresolved course.' }
      ],
      leftovers: ['Bring the transport form tomorrow'],
      valid: false
    },
    {
      id: 'r3',
      values: { name: 'Alan Turing', dob: '23/06/2012', gender: 'Male', courseId: 'g9' },
      labels: { courseId: 'Grade 9 - Secondary' },
      rejected: [],
      leftovers: [],
      valid: true
    }
  ],
  activeRecordId: 'r1',
  fields: [
    { id: 'name', label: 'Name', type: 'text', required: true },
    { id: 'dob', label: 'Date of Birth', type: 'date', required: true },
    {
      id: 'gender',
      label: 'Gender',
      type: 'select',
      required: true,
      options: [
        { value: 'Female', label: 'Female' },
        { value: 'Male', label: 'Male' }
      ]
    },
    { id: 'courseId', label: 'Course', type: 'select', required: true, options: [] }
  ],
  parse: {
    mapped: [
      { fieldId: 'name', value: 'Ada Lovelace' },
      { fieldId: 'dob', value: '12/03/2014' },
      { fieldId: 'gender', value: 'Female' },
      { fieldId: 'courseId', value: 'Grade 6' }
    ],
    rejected: [
      { fieldId: 'dob', text: '31/02/2014', reason: 'Not a valid date.' },
      { fieldId: 'courseId', text: 'Grade 6B', reason: 'Unresolved course.' }
    ],
    leftovers: ['Bring the transport form tomorrow']
  }
};

/* Example payload:

const exampleInstituteResponse: ChatResponse = {
  schemaVersion: '1.0',
  requestId: 'r-123',
  conversationId: 'c-42',
  messageId: 'm-9',
  parentMessageId: 'pm-8',
  agent: { id: 'ct-bot', displayName: 'CT Bot' },
  status: 'completed',
  blocks: [ { type: 'text', text: 'Showing institute details' } ],
  surface: {
    type: 'institute-summary',
    id: 'inst-summary-1',
    title: 'Institute overview',
    data: {
      id: 'institute_001',
      name: 'Sample Institute of Technology',
      address: '123 Campus Drive, Sample City, State, 123456',
      phone: '+1-555-1234',
      email: 'info@sampleinstitute.edu',
      website: 'https://www.sampleinstitute.edu'
    }
  }
};

const exampleStudentEnrolResponse: ChatResponse = {
  schemaVersion: '1.0',
  requestId: 'r-stu-1',
  conversationId: 'c-42',
  messageId: 'm-enrol',
  parentMessageId: 'm-user-enrol',
  agent: { id: 'ct-bot', displayName: 'CT Bot' },
  status: 'completed',
  blocks: [ { type: 'text', text: 'Opening student enrollment.' } ],
  surface: EXAMPLE_STUDENT_ENROL_FORM_SURFACE
};

const exampleOrgAddResponse: ChatResponse = {
  schemaVersion: '1.0',
  requestId: 'r-org-1',
  conversationId: 'c-42',
  messageId: 'm-org-add',
  parentMessageId: 'm-user-org',
  agent: { id: 'ct-bot', displayName: 'CT Bot' },
  status: 'completed',
  blocks: [ { type: 'text', text: 'Opening the Add Organization form.' } ],
  surface: EXAMPLE_ORG_ADD_FORM_SURFACE
};

*/
