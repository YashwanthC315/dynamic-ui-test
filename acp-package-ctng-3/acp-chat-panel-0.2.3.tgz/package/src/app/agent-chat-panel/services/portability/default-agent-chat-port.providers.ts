import { Provider } from '@angular/core';

import {
  AGENT_CHAT_SURFACE_PLUGINS,
  AGENT_CHAT_RESPONSE_PORT,
  AGENT_CHAT_STATE_PORT,
} from './agent-chat-port.contracts';
import {
  DefaultAgentChatResponsePortAdapter,
  DefaultAgentChatStatePortAdapter,
} from './default-agent-chat-port.adapters';
import {
  ActivityLogSurfacePlugin,
  InstituteSummarySurfacePlugin,
  OrgAddFormSurfacePlugin,
  StudentEnrolFormSurfacePlugin,
  BuddyEnrolWorkspaceSurfacePlugin,
} from './default-agent-chat-surface.plugins';

export const DEFAULT_AGENT_CHAT_PORT_PROVIDERS: Provider[] = [
  DefaultAgentChatStatePortAdapter,
  DefaultAgentChatResponsePortAdapter,
  InstituteSummarySurfacePlugin,
  OrgAddFormSurfacePlugin,
  StudentEnrolFormSurfacePlugin,
  BuddyEnrolWorkspaceSurfacePlugin,
  ActivityLogSurfacePlugin,
  { provide: AGENT_CHAT_STATE_PORT, useExisting: DefaultAgentChatStatePortAdapter },
  { provide: AGENT_CHAT_RESPONSE_PORT, useExisting: DefaultAgentChatResponsePortAdapter },
  { provide: AGENT_CHAT_SURFACE_PLUGINS, useExisting: InstituteSummarySurfacePlugin, multi: true },
  { provide: AGENT_CHAT_SURFACE_PLUGINS, useExisting: OrgAddFormSurfacePlugin, multi: true },
  { provide: AGENT_CHAT_SURFACE_PLUGINS, useExisting: StudentEnrolFormSurfacePlugin, multi: true },
  { provide: AGENT_CHAT_SURFACE_PLUGINS, useExisting: BuddyEnrolWorkspaceSurfacePlugin, multi: true },
  { provide: AGENT_CHAT_SURFACE_PLUGINS, useExisting: ActivityLogSurfacePlugin, multi: true },
];
