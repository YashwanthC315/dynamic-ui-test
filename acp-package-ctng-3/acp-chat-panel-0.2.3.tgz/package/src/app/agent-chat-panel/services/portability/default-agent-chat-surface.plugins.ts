import { Injectable } from '@angular/core';

import { InstitutePanelComponent } from '../../components/institute-panel.component';
import { OrgAddFormSurfaceComponent } from '../../components/org-add-form-surface.component';
import { StudentEnrolFormSurfaceComponent } from '../../components/student-enrol-form-surface.component';
import { BuddyEnrolWorkspaceSurfaceComponent } from '../../components/buddy-enrol-workspace-surface.component';
import { ActivityLogListComponent } from '../../components/activity-log-list.component';
import {
  AgentChatSurfacePluginHelpers,
  AgentChatSurfacePluginPort,
} from './agent-chat-port.contracts';
import {
  ActivityAction,
  ActivityItem,
  AgentSurface,
} from '../surface-contracts';

@Injectable({ providedIn: 'root' })
export class InstituteSummarySurfacePlugin implements AgentChatSurfacePluginPort {
  type = 'institute-summary';
  title = 'Institute Info';
  component = InstitutePanelComponent;

  bind(surface: AgentSurface, instance: any): void {
    instance.data = (surface as any).data || null;
    instance.schema = (surface as any).schema || null;
  }
}

@Injectable({ providedIn: 'root' })
export class OrgAddFormSurfacePlugin implements AgentChatSurfacePluginPort {
  type = 'org-add-form';
  title = 'Add Org';
  component = OrgAddFormSurfaceComponent;

  bind(surface: AgentSurface, instance: any, helpers: AgentChatSurfacePluginHelpers): void {
    instance.title = (surface as any).title || 'Add New Org';
    instance.initialValues = (surface as any).data || null;
    instance.schema = (surface as any).schema || null;
    instance.formId = (surface as any).formId || (surface as any).id || null;
    instance.submitAction = (surface as any).submitAction || 'org.add.submit';
    instance.correlationId = (surface as any).correlationId || (surface as any).id || null;

    if (instance.formSubmit && instance.formSubmit.subscribe) {
      instance.formSubmit.subscribe((payload: any) => {
        helpers.emitFormSubmit(surface, payload, 'org.add.submit');
      });
    }
  }
}

@Injectable({ providedIn: 'root' })
export class StudentEnrolFormSurfacePlugin implements AgentChatSurfacePluginPort {
  type = 'student-enrol-form';
  title = 'Enroll Student';
  component = StudentEnrolFormSurfaceComponent;

  bind(surface: AgentSurface, instance: any, helpers: AgentChatSurfacePluginHelpers): void {
    instance.title = (surface as any).title || 'Enroll Student';
    instance.initialValues = (surface as any).data || null;
    instance.schema = (surface as any).schema || null;
    instance.formId = (surface as any).formId || (surface as any).id || null;
    instance.submitAction = (surface as any).submitAction || 'student.enrol.submit';
    instance.correlationId = (surface as any).correlationId || (surface as any).id || null;

    if (instance.formSubmit && instance.formSubmit.subscribe) {
      instance.formSubmit.subscribe((payload: any) => {
        helpers.emitFormSubmit(surface, payload, 'student.enrol.submit');
      });
    }
  }
}

@Injectable({ providedIn: 'root' })
export class BuddyEnrolWorkspaceSurfacePlugin implements AgentChatSurfacePluginPort {
  type = 'buddy-enrol-workspace';
  title = 'Enroll students';
  component = BuddyEnrolWorkspaceSurfaceComponent;

  bind(surface: AgentSurface, instance: any, helpers: AgentChatSurfacePluginHelpers): void {
    instance.surface = surface;

    if (instance.formSubmit && instance.formSubmit.subscribe) {
      instance.formSubmit.subscribe((payload: any) => {
        helpers.emitFormSubmit(surface, payload, 'student.enrol.submit');
      });
    }

    // Optional host support: forwarded only when the panel implements emitEvent (BW-T1+).
    if (helpers.emitEvent) {
      if (instance.parseRequested && instance.parseRequested.subscribe) {
        instance.parseRequested.subscribe((payload: { text: string }) => {
          helpers.emitEvent(surface, 'buddy_parse', 'student.enrol.parse', { text: payload && payload.text || '' });
        });
      }
      if (instance.recordSelected && instance.recordSelected.subscribe) {
        instance.recordSelected.subscribe((payload: { recordId: string }) => {
          helpers.emitEvent(surface, 'record_selected', 'student.enrol.select', { recordId: payload && payload.recordId || '' });
        });
      }
      // H-validate: Check runs the validation child hop with the CURRENT
      // fields[] + records[] (deep copy) + buddy.text so the echo carries the
      // same notes back.
      if (instance.checkRequested && instance.checkRequested.subscribe) {
        instance.checkRequested.subscribe((payload: any) => {
          helpers.emitEvent(surface, 'buddy_validate', 'student.enrol.validate', {
            fields: payload && payload.fields || [],
            records: payload && payload.records || [],
            surfaceId: payload && payload.surfaceId || '',
            activeRecordId: payload && payload.activeRecordId || '',
            buddyText: payload && payload.buddyText || '',
            parse: payload && payload.parse || undefined
          });
        });
      }
    }
  }
}

/** M13: Assembler demo defaults live behind the plugin seam — used ONLY
 * when the harness payload omits actions / menuActions. Never merged on
 * top of a present field (even []). */
export function assemblerFallbackRowActions(item: ActivityItem): ActivityAction[] {
  const actions: ActivityAction[] = [];
  if (item.recordId) {
    actions.push({
      id: 'focus_' + item.recordId,
      label: 'Focus',
      type: 'focus_record',
      payload: { recordId: item.recordId }
    });
  }
  actions.push({
    id: 'copy_names_' + Math.random().toString(36).slice(2, 9),
    label: 'Copy names',
    type: 'copy_names',
    payload: {}
  });
  return actions;
}

export function normalizeAssemblerSurface(surface: AgentSurface): AgentSurface {
  const items = (surface as any).items;
  if (!Array.isArray(items) || !items.some((item: ActivityItem) => !Array.isArray(item.actions))) {
    return surface;
  }
  return Object.assign({}, surface, {
    items: items.map((item: ActivityItem) => {
      if (Array.isArray(item.actions)) {
        return item;
      }
      return Object.assign({}, item, { actions: assemblerFallbackRowActions(item) });
    })
  });
}

export function assemblerFallbackMenuActions(): ActivityAction[] {
  return [{
    id: 'copy_all_names_fallback',
    label: 'Copy all saved names',
    type: 'copy_all_names',
    payload: {}
  }];
}

/** M13: the Assembler is now a routed AgentSurface — the plugin maps the
 * existing ActivityLogSurface type to the same ActivityLogListComponent
 * the host has always rendered, so the pane mounts through the
 * AGENT_CHAT_SURFACE_PLUGINS registry like institute / enrol / buddy. */
@Injectable({ providedIn: 'root' })
export class ActivityLogSurfacePlugin implements AgentChatSurfacePluginPort {
  type = 'activity-log';
  title = 'Assembler';
  component = ActivityLogListComponent;
}
