import { InjectionToken, Type } from '@angular/core';
import { Observable } from 'rxjs';

import { ChatEmitEventRequest, ChatRequest, ChatResponse } from '../chat-contracts';
import { ConversationListItem } from '../ct-bot-conversation-history.service';
import { AgentSurface } from '../surface-contracts';

export type AgentChatStatus = 'idle' | 'inFlight' | 'error';

export interface AgentChatStatePort {
  messages$: Observable<any[]>;
  conversationId$: Observable<string | null>;
  conversationList$: Observable<ConversationListItem[]>;
  status$: Observable<AgentChatStatus>;
  activeRequestId$: Observable<string | null>;
  error$: Observable<string | null>;
  activeSurface$: Observable<AgentSurface | null>;
  activityLog$: Observable<AgentSurface | null>;
  /** M9-T2: restored enrol Workspace snapshot for the active conversation —
   * fetched by the SET_CONVERSATION_ID effect (404 → null); never
   * auto-opened by the panel. */
  restoredWorkspaceSurface$: Observable<AgentSurface | null>;

  setMessages(messages: any[]): void;
  setConversationId(conversationId: string | null): void;
  setConversationList(list: ConversationListItem[]): void;
  sendRequest(requestId: string, message?: any): void;
  sendSuccess(requestId: string, message?: any): void;
  sendFailure(requestId: string, error: string): void;
  cancelRequest(requestId: string): void;
  clearError(): void;
  setActiveRequestId(activeRequestId: string | null): void;
  setStatus(status: AgentChatStatus): void;

  loadConversations(restoreActive?: boolean): void;
  restoreConversationById(conversationId: string): void;
  createConversation(conversationId: string, title?: string): void;
  navigate(href: string, label?: string, messageId?: string): void;
  emitEvent(eventRequest: ChatEmitEventRequest): void;
  loadInstitute(): void;

  openSurface(surface: AgentSurface): void;
  clearSurface(): void;
  setActivityLog(surface: AgentSurface): void;
  /** M5-T4: optional menuActions[] accompanies the item when the harness
   * authored the whole-pane catalog (even []); M8-T5: optional
   * conversationId pins the snapshot's owner for the persist write-back. */
  appendActivityItem(item: any, menuActions?: any, conversationId?: string): void;
  clearActivityLog(): void;
  /** M9-T2: the panel only dispatches — effects own the harness REST I/O
   * (GET activity log → SetActivityLog). */
  loadActivityLog(conversationId: string): void;
  /** M9-T2: post-settle workspace persist trigger (the effect owns the
   * PUT). */
  requestWorkspaceSnapshotPersist(): void;
}

export interface AgentChatResponsePort {
  responses$: Observable<ChatResponse>;
  transportErrors$: Observable<{ requestId: string; details: string }>;
}

export interface AgentChatSurfacePluginPort {
  type: string;
  title?: string;
  component: Type<any>;
  bind?: (surface: AgentSurface, instance: any, helpers: AgentChatSurfacePluginHelpers) => void;
}

export interface AgentChatSurfacePluginHelpers {
  emitFormSubmit: (surface: AgentSurface, payload: any, defaultAction: string) => void;
  /**
   * BW-T0 type-level only; host wiring lands in BW-T1. Lets a surface plugin
   * emit an arbitrary workspace event (e.g. buddy_parse / record_selected)
   * without the panel knowing surface-specific event names.
   */
  emitEvent?: (
    surface: AgentSurface,
    event: string,
    action: string,
    values?: Record<string, unknown>
  ) => void;
}

export interface AgentChatTransportPort {
  send(request: ChatRequest): Observable<ChatResponse>;
  emitEvent(eventRequest: ChatEmitEventRequest): Observable<ChatResponse>;
}

export const AGENT_CHAT_STATE_PORT = new InjectionToken<AgentChatStatePort>('AGENT_CHAT_STATE_PORT');
export const AGENT_CHAT_RESPONSE_PORT = new InjectionToken<AgentChatResponsePort>('AGENT_CHAT_RESPONSE_PORT');
export const AGENT_CHAT_SURFACE_PLUGINS = new InjectionToken<AgentChatSurfacePluginPort[]>('AGENT_CHAT_SURFACE_PLUGINS');
export const AGENT_CHAT_TRANSPORT_PORT = new InjectionToken<AgentChatTransportPort>('AGENT_CHAT_TRANSPORT_PORT');
