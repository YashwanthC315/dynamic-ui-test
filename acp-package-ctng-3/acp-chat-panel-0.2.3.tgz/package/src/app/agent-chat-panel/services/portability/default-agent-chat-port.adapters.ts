import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { ChatFacade } from '../chat.facade';
import { ChatResponseForwarder } from '../chat-response-forwarder.service';
import {
  AgentChatResponsePort,
  AgentChatStatePort,
} from './agent-chat-port.contracts';

@Injectable({ providedIn: 'root' })
export class DefaultAgentChatStatePortAdapter implements AgentChatStatePort {
  readonly messages$ = this.chatFacade.messages$;
  readonly conversationId$ = this.chatFacade.conversationId$;
  readonly conversationList$ = this.chatFacade.conversationList$;
  readonly status$ = this.chatFacade.status$;
  readonly activeRequestId$ = this.chatFacade.activeRequestId$;
  readonly error$ = this.chatFacade.error$;
  readonly activeSurface$ = this.chatFacade.activeSurface$;
  readonly activityLog$ = this.chatFacade.activityLog$;

  constructor(private readonly chatFacade: ChatFacade) {}

  setMessages(messages: any[]): void {
    this.chatFacade.setMessages(messages);
  }

  setConversationId(conversationId: string | null): void {
    this.chatFacade.setConversationId(conversationId);
  }

  setConversationList(list: any[]): void {
    this.chatFacade.setConversationList(list);
  }

  sendRequest(requestId: string, message?: any): void {
    this.chatFacade.sendRequest(requestId, message);
  }

  sendSuccess(requestId: string, message?: any): void {
    this.chatFacade.sendSuccess(requestId, message);
  }

  sendFailure(requestId: string, error: string): void {
    this.chatFacade.sendFailure(requestId, error);
  }

  cancelRequest(requestId: string): void {
    this.chatFacade.cancelRequest(requestId);
  }

  clearError(): void {
    this.chatFacade.clearError();
  }

  setActiveRequestId(activeRequestId: string | null): void {
    this.chatFacade.setActiveRequestId(activeRequestId);
  }

  setStatus(status: 'idle' | 'inFlight' | 'error'): void {
    this.chatFacade.setStatus(status);
  }

  loadConversations(restoreActive: boolean = false): void {
    this.chatFacade.loadConversations(restoreActive);
  }

  restoreConversationById(conversationId: string): void {
    this.chatFacade.restoreConversationById(conversationId);
  }

  createConversation(conversationId: string, title: string = 'New chat'): void {
    this.chatFacade.createConversation(conversationId, title);
  }

  navigate(href: string, label?: string, messageId?: string): void {
    this.chatFacade.navigate(href, label, messageId);
  }

  emitEvent(eventRequest: any): void {
    this.chatFacade.emitEvent(eventRequest);
  }

  loadInstitute(): void {
    this.chatFacade.loadInstitute();
  }

  openSurface(surface: any): void {
    this.chatFacade.openSurface(surface);
  }

  clearSurface(): void {
    this.chatFacade.clearSurface();
  }

  setActivityLog(surface: any): void {
    this.chatFacade.setActivityLog(surface);
  }

  appendActivityItem(item: any, menuActions?: any, conversationId?: string): void {
    this.chatFacade.appendActivityItem(item, menuActions, conversationId);
  }

  clearActivityLog(): void {
    this.chatFacade.clearActivityLog();
  }

  loadActivityLog(conversationId: string): void {
    this.chatFacade.loadActivityLog(conversationId);
  }

  get restoredWorkspaceSurface$(): Observable<any> {
    return this.chatFacade.restoredWorkspaceSurface$;
  }

  requestWorkspaceSnapshotPersist(): void {
    this.chatFacade.requestWorkspaceSnapshotPersist();
  }
}

@Injectable({ providedIn: 'root' })
export class DefaultAgentChatResponsePortAdapter implements AgentChatResponsePort {
  readonly responses$ = this.forwarder.responses$;
  readonly transportErrors$ = this.forwarder.transportErrors$;

  constructor(private readonly forwarder: ChatResponseForwarder) {}
}
