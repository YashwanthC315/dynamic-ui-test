import { Injectable, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import { Subscriber } from 'rxjs/Subscriber';
import { Subscription } from 'rxjs/Subscription';
import * as rootReducer from '../../rootReducer';
import { environment } from '../../../../env/environment';
import { HostContextAdapter } from './host-context-adapter.service';
import {
  AssistantConfirmationBlock,
  AssistantFormBlock,
  AssistantLinkBlock,
  AssistantSuggestionsBlock,
  HarnessAssistantResponse,
  HarnessErrorResponse,
  HostContextFocus,
  HostViewSnapshot,
  HarnessToHostMessage,
  HostContextBag,
  HostModuleFlags,
  hostProtocolCapabilities,
  hostProtocolVersion
} from './ct-bot-host-protocol';
import { ChatAction, ChatBlock, ChatEmitEventRequest, ChatRequest, ChatResponse, ChatSuggestionAction } from './chat-contracts';
import { AgentSurface } from './surface-contracts';
import { HarnessTransportClient } from './chat-transport-adapter.service';
import { CtBotSessionTokenService } from './ct-bot-session-token.service';

interface PendingRequest {
  request: {
    requestId: string;
    conversationId: string;
    messageId: string;
  };
  observer: Subscriber<ChatResponse>;
}

interface InstituteContextSnapshot {
  status: 'ok' | 'unavailable';
  source?: string;
  reason?: string;
  message?: string;
  data?: {
    id?: string;
    name?: string;
    shortName?: string;
    academicYearFrom?: string;
    academicYearTo?: string;
    status?: string;
    board?: string;
  };
}

interface ViewContextProvider {
  canHandle(route: string, state: any): boolean;
  getSnapshot(route: string, state: any): HostViewSnapshot | null;
}

const MAX_VIEW_ROWS = 30;
const MAX_VIEW_FIELD_LENGTH = 160;

@Injectable({ providedIn: 'root' })
export class CtBotHostService implements HarnessTransportClient, OnDestroy {
  private readonly harnessUrl: string;
  private readonly fallbackConversationId = this.createId('conv');
  private readonly allowedNavigationHrefs = new Set([
    '/home',
    '/fees',
    '/fees/transactions',
    '/fees/transactions/add',
    '/fees/add',
    '/admin/inst',
    '/connect/marksCardRecipients',
  ]);
  private socket: WebSocket | null = null;
  private connectPromise: Promise<WebSocket> | null = null;
  private pending: PendingRequest | null = null;
  private latestState: any = null;
  private stateSubscription: Subscription;
  constructor(
    private readonly router: Router,
    private readonly store: Store<rootReducer.State>,
    private readonly sessionToken: CtBotSessionTokenService,
    private readonly hostContextAdapter: HostContextAdapter
  ) {
    this.harnessUrl = (environment as any).AGENT_HARNESS_WS_URL || 'ws://localhost:8787';
    this.stateSubscription = this.store.subscribe((state: any) => this.latestState = state);
  }

  /** M15-T3: the conversation id the mock-socket path falls back to —
   * reused verbatim by the file-run send path for parity. */
  get conversationFallbackId(): string {
    return this.fallbackConversationId;
  }

  /** M15-T3: build the SAME context bag the mock-socket user_message path
   * composes (host adapter + request context extras) — no socket. */
  buildUserContextBag(request: ChatRequest): Promise<HostContextBag> {
    return this.buildOutboundContext(request);
  }

  /** M15-T3: build the SAME context bag the mock-socket emit_event path
   * composes (formOptions gates, event context) — no socket. */
  buildEventContextBag(eventRequest: ChatEmitEventRequest): Promise<HostContextBag> {
    return this.buildEventContext(eventRequest);
  }

  /**
   * M15-T3: build a ChatResponse from a harness assistant payload for a
   * given request envelope — the SAME block / byline / fallback mapping
   * the socket path uses (extracted from completeWithAssistant; no
   * second renderer). completeWithAssistant delegates to this.
   */
  buildAssistantChatResponse(
    payload: HarnessAssistantResponse,
    request: { requestId: string; conversationId: string; messageId: string }
  ): ChatResponse {
    if (payload.hostProtocolVersion !== hostProtocolVersion) {
      console.warn('[ct-bot-host] Protocol version mismatch:', payload.hostProtocolVersion);
    }

    const blocks = this.mapBlocks(payload.messages, payload.correlationId || null);
    // Optional byline from the harness (e.g. Parse agent); default is CT-Bot Assistant.
    const responseAgent = payload.agent && typeof payload.agent === 'object' && payload.agent.id
      ? {
        id: payload.agent.id,
        displayName: payload.agent.displayName || payload.agent.id
      }
      : { id: 'ct-bot-mock-harness', displayName: 'CT-Bot Assistant' };
    const response: ChatResponse = {
      schemaVersion: '1.0.0',
      requestId: request.requestId,
      conversationId: payload.conversationId || request.conversationId,
      messageId: this.createId('resp'),
      parentMessageId: request.messageId,
      agent: responseAgent,
      status: 'completed',
      blocks: blocks.length ? blocks : [{ type: 'text', text: 'I can help with Fees, Home, institute info, adding a student or organization, and marks cards.' }],
      surface: this.isPlainObject(payload.surface) ? payload.surface as AgentSurface : undefined,
      // M5-T4: harness-authored Actions catalog (per-row item + menuActions)
      // forwarded verbatim; the host applies its demo fallback only when
      // the fields are omitted.
      activity: this.isPlainObject(payload.activity) ? payload.activity : undefined,
      actions: this.mapActions(payload.actions)
    };

    console.info('[ct-bot-host] surface present=%s', !!response.surface);
    return response;
  }

  send(request: ChatRequest): Observable<ChatResponse> {
    return new Observable((observer: Subscriber<ChatResponse>) => {
      if (this.pending) {
        observer.error(new Error('Only one CT-Bot message can be in flight at a time.'));
        return;
      }

      const conversationId = request.conversationId || this.fallbackConversationId;
      const outbound = {
        type: 'user_message',
        conversationId,
        messageId: request.messageId || this.createId('msg'),
        text: request.prompt,
        // M10-T1: prior-turn thread (may be absent/empty on the first prompt).
        history: request.history,
        context: {} as HostContextBag,
      };

      this.pending = {
        request: {
          requestId: request.requestId,
          conversationId,
          messageId: request.messageId,
        },
        observer,
      };

      this.buildOutboundContext(request)
        .then((context) => {
          outbound.context = context;
          return this.ensureSocket();
        })
        .then((socket) => {
          if (!this.pending || this.pending.observer !== observer) {
            return;
          }
          socket.send(JSON.stringify(outbound));
        })
        .catch(() => {
          this.failPending('Unable to connect right now. Please try again.');
        });

      return () => {
        if (this.pending && this.pending.observer === observer) {
          this.pending = null;
        }
      };
    });
  }

  ngOnDestroy(): void {
    this.stateSubscription.unsubscribe();
    if (this.socket) {
      this.socket.close();
    }
  }

  emitEvent(eventRequest: ChatEmitEventRequest): Observable<ChatResponse> {
    return new Observable((observer: Subscriber<ChatResponse>) => {
      if (this.pending) {
        observer.error(new Error('Only one CT-Bot message can be in flight at a time.'));
        return;
      }

      const conversationId = eventRequest.conversationId || this.fallbackConversationId;
      const outbound = {
        type: 'emit_event',
        conversationId,
        correlationId: eventRequest.correlationId,
        event: eventRequest.event,
        action: eventRequest.action,
        values: eventRequest.values || {},
        // M5-T4: buddy-workspace chip id — the harness authors the per-row
        // Actions catalog (Focus + Copy names) for THAT saved student.
        recordId: eventRequest.recordId ? String(eventRequest.recordId) : undefined,
        // D6.4-fix: parse hops carry the open workspace fields.
        fields: eventRequest.fields,
        context: {} as HostContextBag,
      };

      this.pending = {
        request: {
          requestId: eventRequest.requestId,
          conversationId: conversationId,
          messageId: eventRequest.messageId,
        },
        observer,
      };

      this.buildEventContext(eventRequest)
        .then((context) => {
          outbound.context = context;
          return this.ensureSocket();
        })
        .then((socket) => {
          if (!this.pending || this.pending.observer !== observer) {
            return;
          }
          socket.send(JSON.stringify(outbound));
        })
        .catch(() => {
          this.failPending('Unable to connect right now. Please try again.');
        });

      return () => {
        if (this.pending && this.pending.observer === observer) {
          this.pending = null;
        }
      };
    });
  }

  private ensureSocket(): Promise<WebSocket> {
    if (this.socket && this.socket.readyState === WebSocket.OPEN) {
      return Promise.resolve(this.socket);
    }

    if (this.connectPromise) {
      return this.connectPromise;
    }

    this.connectPromise = new Promise((resolve, reject) => {
      const url = this.withAccessToken(this.harnessUrl, this.sessionToken.readAccessToken());
      const socket = new WebSocket(url);
      let settled = false;

      socket.onopen = () => {
        settled = true;
        this.socket = socket;
        this.connectPromise = null;
        socket.send(JSON.stringify({
          type: 'hello',
          hostProtocolVersion,
          capabilities: hostProtocolCapabilities,
        }));
        resolve(socket);
      };

      socket.onmessage = (event: MessageEvent) => {
        this.handleIncoming(event.data);
      };

      socket.onerror = () => {
        if (!settled) {
          settled = true;
          this.connectPromise = null;
          reject(new Error('socket_error'));
        }
      };

      socket.onclose = () => {
        this.socket = null;
        if (!settled) {
          settled = true;
          this.connectPromise = null;
          reject(new Error('socket_closed'));
        } else if (this.pending) {
          this.failPending('Connection closed before receiving a response.');
        }
      };
    });

    return this.connectPromise;
  }

  private handleIncoming(raw: any): void {
    let payload: HarnessToHostMessage;
    try {
      payload = JSON.parse(String(raw)) as HarnessToHostMessage;
    } catch (error) {
      this.failPending('Received an invalid response. Please try again.');
      return;
    }

    if (payload.type === 'assistant_response') {
      this.completeWithAssistant(payload);
      return;
    }

    if (payload.type === 'error') {
      this.completeWithError(payload);
      return;
    }

    console.warn('[ct-bot-host] Ignoring unsupported message type:', (payload as any).type);
  }

  private completeWithAssistant(payload: HarnessAssistantResponse): void {
    const pending = this.pending;
    if (!pending) {
      return;
    }
    this.pending = null;

    const response = this.buildAssistantChatResponse(payload, {
      requestId: pending.request.requestId,
      conversationId: pending.request.conversationId,
      messageId: pending.request.messageId
    });

    pending.observer.next(response);
    pending.observer.complete();
  }

  private isPlainObject(value: any): boolean {
    if (!value || Object.prototype.toString.call(value) !== '[object Object]') {
      return false;
    }
    const prototype = Object.getPrototypeOf(value);
    return prototype === null || prototype === Object.prototype;
  }

  mapStoredAssistantBlocks(messages: any[], correlationId?: string | null): ChatBlock[] {
    return this.mapBlocks(
      Array.isArray(messages) ? messages : [],
      typeof correlationId === 'string' ? correlationId : null
    );
  }

  private completeWithError(payload: HarnessErrorResponse): void {
    const pending = this.pending;
    if (!pending) {
      return;
    }
    this.pending = null;

    const safeMessage = this.toSafeUserErrorMessage(payload.message);

    pending.observer.next({
      schemaVersion: '1.0.0',
      requestId: pending.request.requestId,
      conversationId: payload.conversationId || pending.request.conversationId,
      messageId: this.createId('resp'),
      parentMessageId: pending.request.messageId,
      agent: {
        id: 'ct-bot-mock-harness',
        displayName: 'CT-Bot Assistant',
      },
      status: 'failed',
      blocks: [{ type: 'error', message: safeMessage }],
      actions: [],
    });
    pending.observer.complete();
  }

  private failPending(message: string): void {
    const pending = this.pending;
    if (!pending) {
      return;
    }
    this.pending = null;
    pending.observer.error(new Error(message));
  }

  private toSafeUserErrorMessage(message: string | undefined): string {
    const candidate = typeof message === 'string' ? message.trim() : '';
    if (!candidate) {
      return 'Sorry, I could not process that request.';
    }

    const lowered = candidate.toLowerCase();
    if (
      lowered.indexOf('harness') >= 0 ||
      lowered.indexOf('protocol') >= 0 ||
      lowered.indexOf('envelope') >= 0 ||
      lowered.indexOf('websocket') >= 0 ||
      lowered.indexOf('socket') >= 0
    ) {
      return 'Sorry, something went wrong while processing your request.';
    }

    return candidate;
  }

  private normalizeInternalHref(href: string): string {
    const trimmed = typeof href === 'string' ? href.trim() : '';
    if (!trimmed) {
      return '';
    }
    const queryIndex = trimmed.indexOf('?');
    const hashIndex = trimmed.indexOf('#');
    let cutIndex = -1;
    if (queryIndex >= 0 && hashIndex >= 0) {
      cutIndex = Math.min(queryIndex, hashIndex);
    } else {
      cutIndex = queryIndex >= 0 ? queryIndex : hashIndex;
    }
    const withoutQuery = cutIndex >= 0 ? trimmed.slice(0, cutIndex) : trimmed;
    return withoutQuery.length > 1 ? withoutQuery.replace(/\/+$/, '') : withoutQuery;
  }

  private isAllowlistedInternalHref(href: string): boolean {
    const normalizedHref = this.normalizeInternalHref(href);
    if (!normalizedHref || normalizedHref.charAt(0) !== '/' || /^https?:\/\//i.test(normalizedHref)) {
      return false;
    }

    return Array.from(this.allowedNavigationHrefs).some((allowedHref) => {
      return normalizedHref === allowedHref
        || normalizedHref.indexOf(allowedHref + '?') === 0
        || normalizedHref.indexOf(allowedHref + '#') === 0;
    });
  }

  private mapBlocks(messages: any[], responseCorrelationId: string | null): ChatBlock[] {
    if (!Array.isArray(messages)) {
      return [];
    }

    return messages.reduce((acc: ChatBlock[], message: any) => {
      if (!message || typeof message !== 'object') {
        return acc;
      }

      if (message.type === 'text' && typeof message.text === 'string') {
        acc.push({ type: 'text', text: message.text });
        return acc;
      }

      if (message.type === 'markdown' && typeof message.markdown === 'string') {
        acc.push({ type: 'markdown', markdown: message.markdown });
        return acc;
      }

      if (message.type === 'suggestions') {
        const suggestionsBlock = this.mapSuggestionsBlock(message as AssistantSuggestionsBlock);
        if (suggestionsBlock) {
          acc.push(suggestionsBlock);
        }
        return acc;
      }

      if (message.type === 'link') {
        const linkBlock = this.mapLinkBlock(message as AssistantLinkBlock);
        if (linkBlock) {
          acc.push(linkBlock);
        }
        return acc;
      }

      if (message.type === 'form') {
        const formBlock = this.mapFormBlock(message as AssistantFormBlock, responseCorrelationId);
        if (formBlock) {
          acc.push(formBlock);
        }
        return acc;
      }

      if (message.type === 'confirmation') {
        const confirmationBlock = this.mapConfirmationBlock(message as AssistantConfirmationBlock, responseCorrelationId);
        if (confirmationBlock) {
          acc.push(confirmationBlock);
        }
        return acc;
      }

      console.warn('[ct-bot-host] Skipping unsupported block type:', message.type);
      return acc;
    }, []);
  }

  private mapSuggestionsBlock(message: AssistantSuggestionsBlock): ChatBlock | null {
    if (!Array.isArray(message.items)) {
      return null;
    }
    const mappedItems = message.items
      .map((item: any) => this.mapSuggestionItem(item))
      .filter((item: ChatSuggestionAction | null): item is ChatSuggestionAction => item !== null);
    if (!mappedItems.length) {
      return null;
    }
    return {
      type: 'suggestions',
      id: typeof message.id === 'string' && message.id.trim() ? message.id.trim() : undefined,
      items: mappedItems
    };
  }

  private mapSuggestionItem(item: any): ChatSuggestionAction | null {
    if (!item || typeof item !== 'object') {
      return null;
    }
    const id = typeof item.id === 'string' ? item.id.trim() : '';
    const label = typeof item.label === 'string' ? item.label.trim() : '';
    const action = typeof item.action === 'string' ? item.action.trim().toLowerCase() : '';
    const payload = item.payload && typeof item.payload === 'object' ? item.payload as Record<string, unknown> : {};
    if (!id || !label || !action) {
      return null;
    }

    if (action === 'send_message') {
      const text = typeof payload.text === 'string' ? payload.text.trim() : '';
      if (!text) {
        return null;
      }
      return {
        id,
        label,
        action: {
          id: 'sugg_send_' + id,
          label,
          payload: { type: 'internal.prompt', prompt: text }
        }
      };
    }

    return null;
  }

  private mapLinkBlock(message: AssistantLinkBlock): ChatBlock | null {
    const href = typeof message.href === 'string' ? message.href.trim() : '';
    const label = typeof message.label === 'string' ? message.label.trim() : '';
    if (!href || !label) {
      return null;
    }

    return {
      type: 'link',
      id: typeof message.id === 'string' && message.id.trim() ? message.id.trim() : undefined,
      label: label,
      href: href,
      target: message.target === 'external' ? 'external' : 'internal'
    };
  }

  private mapActions(actions: any[]): ChatAction[] {
    if (!Array.isArray(actions)) {
      return [];
    }

    return actions.reduce((acc: ChatAction[], action: any) => {
      if (!action || typeof action !== 'object') {
        return acc;
      }

      if (action.type === 'navigate') {
        const route = this.normalizeInternalHref(String(action.route || action.href || ''));
        if (!this.isAllowlistedInternalHref(route)) {
          console.warn('[ct-bot-host] Skipping unsafe navigate action from harness:', route);
          return acc;
        }
        acc.push({
          id: this.createId('action'),
          label: 'Navigate',
          payload: { type: 'navigate', href: route, target: 'internal' },
        });
        return acc;
      }

      if (action.type === 'change_state') {
        acc.push({
          id: this.createId('action'),
          label: 'Change state',
          payload: { type: 'change_state', patch: action.patch || {} },
        });
        return acc;
      }

      console.warn('[ct-bot-host] Skipping unsupported action type:', action.type);
      return acc;
    }, []);
  }

  private buildOutboundContext(request: ChatRequest): Promise<HostContextBag> {
    const routerUrl = (this.router && (this.router as any).url) ? (this.router as any).url : '/';
    return this.hostContextAdapter.buildOutboundContext(request, this.latestState, routerUrl);
  }

  private buildEventContext(eventRequest: ChatEmitEventRequest): Promise<HostContextBag> {
    const routerUrl = (this.router && (this.router as any).url) ? (this.router as any).url : '/';
    return this.hostContextAdapter.buildEventContext(eventRequest, this.latestState, routerUrl);
  }

  private mapFormBlock(block: AssistantFormBlock, responseCorrelationId: string | null): ChatBlock | null {
    if (!block || !Array.isArray(block.fields) || !block.submitAction) {
      console.warn('[ct-bot-host] Invalid form block payload.');
      return null;
    }

    const normalizedFields = block.fields
      .filter((field: any) => field && typeof field.id === 'string' && typeof field.type === 'string' && typeof field.label === 'string')
      .map((field: any) => ({
        id: String(field.id),
        type: String(field.type) as 'text' | 'number' | 'select',
        label: String(field.label),
        required: !!field.required,
        options: Array.isArray(field.options)
          ? field.options
            .filter((option: any) => option && typeof option.value === 'string' && typeof option.label === 'string')
            .map((option: any) => ({ value: String(option.value), label: String(option.label) }))
          : undefined
      }))
      .filter((field: any) => field.type === 'text' || field.type === 'number' || field.type === 'select');

    if (!normalizedFields.length) {
      console.warn('[ct-bot-host] Form block has no supported fields.');
      return null;
    }

    return {
      type: 'form',
      formId: block.formId || this.createId('form'),
      title: block.title || 'Form',
      submitAction: block.submitAction,
      correlationId: block.correlationId || responseCorrelationId || '',
      fields: normalizedFields,
    };
  }

  private mapConfirmationBlock(block: AssistantConfirmationBlock, responseCorrelationId: string | null): ChatBlock | null {
    if (!block || typeof block.text !== 'string' || !block.confirmAction || !block.cancelAction) {
      console.warn('[ct-bot-host] Invalid confirmation block payload.');
      return null;
    }

    return {
      type: 'confirmation',
      text: block.text,
      confirmAction: block.confirmAction,
      cancelAction: block.cancelAction,
      correlationId: block.correlationId || responseCorrelationId || '',
    };
  }

  private readPersonaFromState(): string {
    const appState = this.latestState && this.latestState.app;
    const currentPersona = appState && appState.currentPersona;
    const title = currentPersona && currentPersona.title;
    const text = typeof title === 'string' ? title.trim() : '';
    return text;
  }

  private readStringField(source: any, keys: string[]): string {
    if (!source || typeof source !== 'object') {
      return '';
    }
    for (let i = 0; i < keys.length; i++) {
      const key = keys[i];
      const value = source[key];
      if (value === null || value === undefined) {
        continue;
      }
      const text = String(value).trim();
      if (text) {
        return text;
      }
    }
    return '';
  }

  private readFocusFromState(): HostContextFocus | null {
    const selectedStudent = this.latestState && this.latestState.student && this.latestState.student.selectedStudent;
    const studentId = this.readStringField(selectedStudent, ['id', 'Id', 'studentId', 'StudentId']);
    if (studentId) {
      return {
        type: 'student',
        id: studentId,
        label: this.readStringField(selectedStudent, ['name', 'Name', 'studentId', 'StudentId']) || studentId
      };
    }

    const selectedApplicant = this.latestState && this.latestState.admissions && this.latestState.admissions.selectedApplicant;
    const applicantId = this.readStringField(selectedApplicant, ['id', 'Id', 'applicationNumber', 'ApplicationNumber']);
    if (applicantId) {
      return {
        type: 'applicant',
        id: applicantId,
        label: this.readStringField(selectedApplicant, ['name', 'Name', 'applicationNumber', 'ApplicationNumber']) || applicantId
      };
    }

    return null;
  }

  private buildModuleFlags(route: string): HostModuleFlags {
    const normalizedRoute = (route || '').trim().toLowerCase();
    return {
      underFees: normalizedRoute.indexOf('/fees') === 0,
      underConnect: normalizedRoute.indexOf('/connect') === 0,
      underStudent: normalizedRoute.indexOf('/admin/student') === 0 || normalizedRoute.indexOf('/student') === 0
    };
  }

  private withAccessToken(url: string, token: string): string {
    if (!token) {
      return url;
    }
    return url + (url.indexOf('?') >= 0 ? '&' : '?') + 'access_token=' + encodeURIComponent(token);
  }

  private createId(prefix: string): string {
    return prefix + '_' + Date.now() + '_' + Math.random().toString(36).slice(2, 9);
  }
}
