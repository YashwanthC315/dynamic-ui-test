import { InjectionToken } from '@angular/core';

import { HostContextFocus, HostViewSnapshot } from './ct-bot-host-protocol';
import {
  VIEW_SNAPSHOT_MAX_ROWS,
  capText,
  collectColumns,
  humanizeViewKey,
  scalarText,
  serializeFlatViewRow
} from './view-serializer';

/** M14-T1..T4: view bricks — the context-side sibling of
 * AGENT_CHAT_SURFACE_PLUGINS. A brick is one app-owned line of
 * registration: WHICH slice of the store is the current screen's view
 * (select) and WHICH route shows it (routePattern). Everything generic
 * — bounding, scalar serialization, column collection, omit-if-empty,
 * focus id/label resolution, option dedup — lives in this orchestrator;
 * module field names live only inside bricks. No module names may
 * appear in this file. */

export type ViewBrickKind = 'rows' | 'filters' | 'focus' | 'form-options' | 'summary' | 'chart' | 'wizard';

export interface ViewBrick {
  kind: ViewBrickKind;
  /** Prefix match against router.url, same style as buildModuleFlags.
   * Focus and form-options bricks register '/' so they ride any turn
   * (their gate is the intent/event, not the route). */
  routePattern: string;
  module?: string;
  screen?: string | ((route: string) => string);
  title?: string | ((route: string) => string);
  /** Resolved with the RAW rows (before bounding), so an app brick can
   * keep today's `length ? 'store.fees.txList' : 'store.fees'` split. */
  source?: string | ((rawRows: any[]) => string);
  maxRows?: number;
  /** focus bricks: wire type ('student' | 'applicant' | ...) and the
   * app's id/label key lists. Falls back to module, then ['id','Id']. */
  focusType?: string;
  idField?: string[];
  labelField?: string[];
  /** form-options bricks: the wire key under context.formOptions
   * ('courses' | 'parentOrgs' | 'ownerOrgs' | ...). select may also
   * return already-shaped {value,label}[] entries; raw rows are read
   * through the same idField/labelField key lists (labelField falls
   * back to 'label', then to the value). */
  name?: string;
  valueField?: string[];
  /** form-options only: app-owned async fallback when the store slice
   * is empty. The orchestrator never calls this; only the adapter's
   * intent gate awaits it (via resolveFormOptionsFromBricks). Must not
   * be set on rows/filters/focus bricks. */
  fallback?: (state: any) => Promise<any[]>;
  /** The only module-aware line: read the slice out of latestState.
   * route is passed as the second argument (wizard bricks derive the
   * current step from it; other bricks may ignore it). */
  select: (state: any, route?: string) => unknown;
}

export const VIEW_BRICKS = new InjectionToken<ViewBrick[]>('VIEW_BRICKS');

export function routeMatchesBrick(pattern: string, route: string): boolean {
  const normalizedRoute = (route || '').trim().toLowerCase();
  const normalizedPattern = String(pattern || '').trim().toLowerCase();
  if (!normalizedPattern) { return false; }
  return normalizedRoute.indexOf(normalizedPattern) === 0;
}

function safeSelect(brick: ViewBrick, state: any, route?: string): any {
  try {
    return brick.select(state, route);
  } catch (e) {
    return undefined;
  }
}

function resolveBrickText(value: string | ((route: string) => string) | undefined, route: string): string {
  if (typeof value === 'function') {
    const text = value(route);
    return typeof text === 'string' ? text : '';
  }
  return typeof value === 'string' ? value : '';
}

function resolveBrickSource(brick: ViewBrick, rawRows: any[]): string {
  if (typeof brick.source === 'function') {
    const text = brick.source(rawRows);
    return typeof text === 'string' ? text : '';
  }
  return typeof brick.source === 'string' ? brick.source : '';
}

/**
 * M14-T1: replace buildViewSnapshot's module if/else with registered
 * bricks. Route + latestState in, HostViewSnapshot (or null) out.
 * - First matching brick per (kind, module) wins.
 * - A 'rows' brick that matches its route ships the snapshot even when
 *   the selected list is empty (byte-identical with the pre-T1 Fees
 *   path, which shipped `rows: []` on an empty txList). null/undefined
 *   selects are treated as empty.
 * - A 'filters' brick whose select yields no keys is omitted entirely.
 * - No matching brick → null → context.view is omitted (never {}).
 */
export function buildViewSnapshotFromBricks(
  bricks: ViewBrick[] | null,
  state: any,
  route: string
): HostViewSnapshot | null {
  const registered = Array.isArray(bricks) ? bricks : [];
  const matched = registered.filter((brick) => !!(brick && typeof brick.select === 'function'
    && routeMatchesBrick(brick.routePattern, route)));
  if (!matched.length) { return null; }

  // First matching brick per (kind, module) wins.
  const seen: Record<string, boolean> = {};
  const winners: ViewBrick[] = [];
  matched.forEach((brick) => {
    const key = brick.kind + '|' + String(brick.module || '');
    if (seen[key]) { return; }
    seen[key] = true;
    winners.push(brick);
  });

  const rowsBrick = winners.filter((brick) => brick.kind === 'rows')[0] || null;
  const filtersBrick = winners.filter((brick) => brick.kind === 'filters')[0] || null;

  let serializedRows: Array<Record<string, unknown>> | null = null;
  let rawRows: any[] = [];
  let rowCount = 0;
  let truncated = false;
  let maxRows = VIEW_SNAPSHOT_MAX_ROWS;
  if (rowsBrick) {
    const raw = safeSelect(rowsBrick, state);
    rawRows = Array.isArray(raw) ? raw : [];
    maxRows = typeof rowsBrick.maxRows === 'number' && rowsBrick.maxRows > 0 ? rowsBrick.maxRows : VIEW_SNAPSHOT_MAX_ROWS;
    serializedRows = rawRows
      .slice(0, maxRows)
      .map((row: any) => serializeFlatViewRow(row))
      .filter((row: Record<string, unknown>) => Object.keys(row).length > 0);
    rowCount = rawRows.length;
    truncated = rawRows.length > maxRows;
  }

  let filters: Record<string, unknown> | null = null;
  if (filtersBrick) {
    const raw = safeSelect(filtersBrick, state, route);
    if (raw && typeof raw === 'object' && !Array.isArray(raw) && Object.keys(raw).length > 0) {
      filters = raw as Record<string, unknown>;
    }
  }

  // M14-T4: store-backed extras that are not rows — summary pairs, a
  // chart summary, a wizard step. Bounded, scalar-only; an empty select
  // omits its key. A view bag may be extras-only (routes with no rows
  // brick).
  const extras: Record<string, unknown> = {};
  EXTRA_KINDS.forEach((kind: ViewBrickKind) => {
    const brick = winners.filter((candidate) => candidate.kind === kind)[0] || null;
    if (!brick) { return; }
    const extra = buildViewExtra(kind, brick, safeSelect(brick, state, route));
    if (extra !== undefined) { extras[kind] = extra; }
  });
  const extrasPresent = Object.keys(extras).length > 0;

  if (!serializedRows && !filters && !extrasPresent) { return null; }

  // Assemble in the pre-T1 HostViewSnapshot field order, extras after.
  const snapshot: Record<string, unknown> = {};
  if (rowsBrick) {
    snapshot['module'] = rowsBrick.module || 'app';
    snapshot['screen'] = resolveBrickText(rowsBrick.screen, route) || 'other';
    snapshot['title'] = resolveBrickText(rowsBrick.title, route);
    const source = resolveBrickSource(rowsBrick, rawRows);
    if (source) { snapshot['source'] = source; }
  }
  if (filters) { snapshot['filters'] = filters; }
  if (serializedRows) {
    snapshot['columns'] = collectColumns(serializedRows);
    snapshot['rows'] = serializedRows;
    snapshot['rowCount'] = rowCount;
    snapshot['truncated'] = truncated;
    snapshot['maxRows'] = maxRows;
  }
  Object.keys(extras).forEach((key: string) => {
    snapshot[key] = extras[key];
  });
  return snapshot as HostViewSnapshot;
}

const EXTRA_KINDS: ViewBrickKind[] = ['summary', 'chart', 'wizard'];

export interface ViewSummaryEntry {
  label: string;
  value: string;
}

const VIEW_EXTRAS_MAX_ENTRIES = 12;

/**
 * M14-T4: bounded serialization for summary/chart/wizard kinds.
 * - summary: {label,value}[] — the brick may return shaped entries or a
 *   scalar map object (keys humanized); scalars only, cap 12.
 * - chart: {title?, kind?, series?} — the brick shapes it; series
 *   entries must be shaped {label,value} scalars, cap 12. No series
 *   invented, no blobs.
 * - wizard: scalar key/value object (boolean/number/string/Date),
 *   cap 12 keys — the brick computes things like hasAttachment itself.
 * An empty select -> undefined (the key is omitted).
 */
function buildViewExtra(kind: ViewBrickKind, brick: ViewBrick, raw: any): unknown | undefined {
  if (kind === 'summary') {
    const entries: ViewSummaryEntry[] = [];
    const pushEntry = (label: string, value: string): void => {
      if (!label || !value || entries.length >= VIEW_EXTRAS_MAX_ENTRIES) { return; }
      entries.push({ label: capText(label), value: capText(value) });
    };
    if (Array.isArray(raw)) {
      raw.forEach((entry: any) => {
        if (!entry || typeof entry !== 'object') { return; }
        const label = scalarText(entry['label']);
        const value = scalarText(entry['value']);
        if (label || value) { pushEntry(label, value); }
      });
      return entries.length ? entries : undefined;
    }
    if (raw && typeof raw === 'object') {
      Object.keys(raw).forEach((key: string) => {
        pushEntry(humanizeViewKey(key), scalarText(raw[key]));
      });
      return entries.length ? entries : undefined;
    }
    return undefined;
  }
  if (kind === 'chart') {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) { return undefined; }
    const bounded: Record<string, unknown> = {};
    const title = scalarText(raw['title']);
    const chartKind = scalarText(raw['kind']);
    if (title) { bounded['title'] = capText(title); }
    if (chartKind) { bounded['kind'] = capText(chartKind); }
    const series = Array.isArray(raw['series']) ? raw['series'] : [];
    const boundedSeries: ViewSummaryEntry[] = [];
    series.forEach((entry: any) => {
      if (boundedSeries.length >= VIEW_EXTRAS_MAX_ENTRIES) { return; }
      if (!entry || typeof entry !== 'object') { return; }
      const label = scalarText(entry['label']);
      const value = scalarText(entry['value']);
      if (!label || !value) { return; }
      boundedSeries.push({ label: capText(label), value: capText(value) });
    });
    if (boundedSeries.length) { bounded['series'] = boundedSeries; }
    return Object.keys(bounded).length ? bounded : undefined;
  }
  if (kind === 'wizard') {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) { return undefined; }
    const bounded: Record<string, string> = {};
    Object.keys(raw).forEach((key: string) => {
      if (Object.keys(bounded).length >= VIEW_EXTRAS_MAX_ENTRIES) { return; }
      const value = raw[key];
      const scalar = value === true || value === false || typeof value === 'number' ? String(value) : scalarText(value);
      if (!scalar) { return; }
      bounded[key] = capText(scalar);
    });
    return Object.keys(bounded).length ? bounded : undefined;
  }
  return undefined;
}

function readStringField(source: any, keys: string[]): string {
  if (!source || typeof source !== 'object') { return ''; }
  for (let i = 0; i < keys.length; i++) {
    const value = source[keys[i]];
    if (value === null || value === undefined) { continue; }
    const text = String(value).trim();
    if (text) { return text; }
  }
  return '';
}

/**
 * M14-T2: focus is a registered brick, not adapter hardcoding. Focus
 * bricks register routePattern '/' so they are evaluated on every turn
 * (pre-T2 readFocusFromState was route-independent). In registration
 * order, the first brick whose select yields an entity with a
 * non-empty id (via idField keys) wins; label = first labelField key,
 * falling back to the id. No brick yields an id → null, same as the
 * pre-T2 bag (context.focus present-as-null).
 */
export function buildContextFocusFromBricks(
  bricks: ViewBrick[] | null,
  state: any,
  route: string
): HostContextFocus | null {
  const registered = Array.isArray(bricks) ? bricks : [];
  const matched = registered.filter((brick) => !!(brick && typeof brick.select === 'function'
    && brick.kind === 'focus'
    && routeMatchesBrick(brick.routePattern, route)));
  if (!matched.length) { return null; }

  // First matching focus brick per (kind, module) wins, mirroring rows.
  const seen: Record<string, boolean> = {};
  const winners: ViewBrick[] = [];
  matched.forEach((brick) => {
    const key = brick.kind + '|' + String(brick.module || '');
    if (seen[key]) { return; }
    seen[key] = true;
    winners.push(brick);
  });

  for (let i = 0; i < winners.length; i++) {
    const brick = winners[i];
    const entity = safeSelect(brick, state, route);
    const id = readStringField(entity, brick.idField && brick.idField.length ? brick.idField : ['id', 'Id']);
    if (!id) { continue; }
    const label = readStringField(entity, brick.labelField && brick.labelField.length ? brick.labelField : ['name', 'Name']) || id;
    const focus: HostContextFocus = {
      type: (brick.focusType || brick.module || 'other') as HostContextFocus['type'],
      id: id,
      label: label
    };
    return focus;
  }
  return null;
}

/** M14-T3: one select option on the wire — {value,label}, max 100 per
 * list. The generic half of the old mapCourseOptions / mapOrgOptions:
 * dedup by value, then by normalized label (keep first). */
export interface FormOption {
  value: string;
  label: string;
}

export const FORM_OPTIONS_MAX = 100;

function normalizeOptionLabel(label: string): string {
  return String(label || '').trim().replace(/\s+/g, ' ').toLowerCase();
}

function toFormOption(raw: any, valueField?: string[], labelField?: string[]): FormOption | null {
  if (!raw || typeof raw !== 'object') { return null; }
  // Already-shaped {value,label}: the app brick flattened/mapped it.
  const shapedValue = typeof raw['value'] === 'string' ? raw['value'].trim() : '';
  if (shapedValue) {
    const shapedLabel = typeof raw['label'] === 'string' ? raw['label'].trim() : '';
    return { value: shapedValue, label: shapedLabel || shapedValue };
  }
  // Raw store row: read value/label through the brick's key lists.
  const value = readStringField(raw, valueField && valueField.length ? valueField : ['id', 'Id']);
  if (!value) { return null; }
  const label = readStringField(raw, labelField && labelField.length ? labelField : ['name', 'Name', 'label', 'Label']) || value;
  return { value: value, label: label };
}

function dedupeFormOptions(options: FormOption[]): FormOption[] {
  const result: FormOption[] = [];
  const seenValues: Record<string, boolean> = {};
  const seenLabels: Record<string, boolean> = {};
  for (let i = 0; i < options.length && result.length < FORM_OPTIONS_MAX; i++) {
    const option = options[i];
    if (!option.value || seenValues[option.value]) { continue; }
    const labelKey = normalizeOptionLabel(option.label);
    if (labelKey && seenLabels[labelKey]) { continue; }
    seenValues[option.value] = true;
    if (labelKey) { seenLabels[labelKey] = true; }
    result.push(option);
  }
  return result;
}

function optionsFromRows(rows: any[], brick: ViewBrick): FormOption[] {
  return dedupeFormOptions((rows || [])
    .map((row: any) => toFormOption(row, brick.valueField, brick.labelField))
    .filter((option: FormOption | null): option is FormOption => !!option));
}

function findFormOptionsBrick(registered: ViewBrick[], name: string): ViewBrick | null {
  const wanted = String(name || '').trim();
  if (!wanted) { return null; }
  return registered.filter((brick) => !!(brick && brick.kind === 'form-options'
    && typeof brick.select === 'function'
    && String(brick.name || '').trim() === wanted))[0] || null;
}

/**
 * M14-T3: form options are registered bricks. `names` is the adapter's
 * intent-gated request (e.g. ['courses'] on an enrol turn, or
 * ['parentOrgs','ownerOrgs'] on an org-add turn); the orchestrator
 * composes { [name]: {value,label}[] } from the matching bricks.
 * Store-only and synchronous — the API fallback, if a brick declares
 * one, is awaited by resolveFormOptionsFromBricks, never here.
 * - Bricks register '/' (intent-gated, not route-gated).
 * - A matched brick always contributes its key, even empty ([]).
 * - A requested name with no matching brick contributes nothing; if
 *   nothing contributes, the whole formOptions bag is omitted.
 */
export function buildFormOptionsFromBricks(
  bricks: ViewBrick[] | null,
  state: any,
  route: string,
  names: string[]
): Record<string, FormOption[]> | null {
  const requested = (names || []).map((name: any) => String(name || '').trim()).filter((name: string) => !!name);
  if (!requested.length) { return null; }
  const registered = Array.isArray(bricks) ? bricks : [];
  const result: Record<string, FormOption[]> = {};
  requested.forEach((name: string) => {
    const brick = findFormOptionsBrick(registered, name);
    if (!brick) { return; }
    const raw = safeSelect(brick, state, route);
    result[name] = optionsFromRows(Array.isArray(raw) ? raw : [], brick);
  });
  return Object.keys(result).length ? result : null;
}

/**
 * M14-T3: store pass first; for a matched brick whose store slice is
 * empty, await its app-owned fallback (same fallback function shared by
 * several bricks is awaited ONCE — today's single API call serves both
 * parentOrgs and ownerOrgs). Errors fall back to empty options; never
 * invented values.
 */
export async function resolveFormOptionsFromBricks(
  bricks: ViewBrick[] | null,
  state: any,
  route: string,
  names: string[]
): Promise<Record<string, FormOption[]> | null> {
  const fromStore = buildFormOptionsFromBricks(bricks, state, route, names);
  if (!fromStore) { return null; }
  const registered = Array.isArray(bricks) ? bricks : [];

  // Collect the matched bricks whose store slice came back empty.
  const needFallback: ViewBrick[] = [];
  Object.keys(fromStore).forEach((name: string) => {
    if (fromStore[name].length) { return; }
    const brick = findFormOptionsBrick(registered, name);
    if (brick && typeof brick.fallback === 'function') { needFallback.push(brick); }
  });

  // Same fallback function shared by several bricks is awaited ONCE —
  // today's single API call serves both parentOrgs and ownerOrgs.
  const fallbackResults = new Map<any, Promise<FormOption[]>>();
  needFallback.forEach((brick: ViewBrick) => {
    if (fallbackResults.has(brick.fallback)) { return; }
    fallbackResults.set(brick.fallback, Promise.resolve()
      .then(() => brick.fallback(state))
      .then((raw: any) => optionsFromRows(Array.isArray(raw) ? raw : [], brick))
      .catch(() => [] as FormOption[]));
  });

  const resolved = new Map<any, FormOption[]>();
  const fallbackEntries: Array<[any, Promise<FormOption[]>]> = [];
  fallbackResults.forEach((promise: Promise<FormOption[]>, fn: any) => {
    fallbackEntries.push([fn, promise]);
  });
  if (fallbackEntries.length) {
    const values = await Promise.all(fallbackEntries.map((entry: [any, Promise<FormOption[]>]) => entry[1]));
    fallbackEntries.forEach((entry: [any, Promise<FormOption[]>], index: number) => {
      resolved.set(entry[0], values[index]);
    });
  }

  Object.keys(fromStore).forEach((name: string) => {
    if (fromStore[name].length) { return; }
    const brick = findFormOptionsBrick(registered, name);
    if (brick && typeof brick.fallback === 'function' && resolved.has(brick.fallback)) {
      fromStore[name] = resolved.get(brick.fallback) as FormOption[];
    }
  });

  console.info(
    '[ct-bot-host] formOptions %s source=view-bricks',
    Object.keys(fromStore).map((name: string) => name + '=' + fromStore[name].length).join(' ')
  );
  return fromStore;
}
