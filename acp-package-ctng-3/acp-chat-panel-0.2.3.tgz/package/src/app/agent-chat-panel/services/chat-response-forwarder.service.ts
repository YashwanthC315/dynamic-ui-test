import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import { ChatResponse } from './chat-contracts';

@Injectable({ providedIn: 'root' })
export class ChatResponseForwarder {
  private responseSubject = new Subject<ChatResponse>();
  private transportErrorSubject = new Subject<{ requestId: string; details: string }>();

  publishResponse(response: ChatResponse) {
    this.responseSubject.next(response);
  }

  publishTransportError(requestId: string, details: string) {
    this.transportErrorSubject.next({ requestId, details });
  }

  get responses$(): Observable<ChatResponse> {
    return this.responseSubject.asObservable();
  }

  get transportErrors$(): Observable<{ requestId: string; details: string }> {
    return this.transportErrorSubject.asObservable();
  }
}
