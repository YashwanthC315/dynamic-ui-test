/** M14-T1: generic view-row serialization, lifted verbatim from the Fees
 * path in CtHostContextAdapter (host-context-adapter.service.ts). No
 * module knowledge lives here — bricks choose slices, this module
 * serializes whatever a brick selects. */

export const VIEW_SNAPSHOT_MAX_ROWS = 30;
/** Single string value cap inside a serialized row. */
export const VIEW_ROW_VALUE_MAX_LENGTH = 160;

export function serializeFlatViewRow(row: any): Record<string, unknown> {
  const serialized: Record<string, unknown> = {};
  if (!row || typeof row !== 'object') { return serialized; }
  Object.keys(row).forEach((key: string) => {
    const value = toSerializableScalar(row[key]);
    if (value === undefined) { return; }
    serialized[key] = value;
  });
  return serialized;
}

export function toSerializableScalar(value: unknown): string | number | boolean | null | undefined {
  if (value === null) { return null; }
  if (value === undefined) { return undefined; }
  if (typeof value === 'string') {
    const trimmed = value.trim();
    if (!trimmed) { return undefined; }
    return trimmed.length > VIEW_ROW_VALUE_MAX_LENGTH ? trimmed.slice(0, VIEW_ROW_VALUE_MAX_LENGTH) + '...' : trimmed;
  }
  if (typeof value === 'number') { return isFinite(value) ? value : undefined; }
  if (typeof value === 'boolean') { return value; }
  if (value instanceof Date) { return value.toISOString(); }
  return undefined;
}

export function collectColumns(rows: Array<Record<string, unknown>>): string[] {
  const seen: Record<string, boolean> = {};
  const columns: string[] = [];
  rows.forEach((row: Record<string, unknown>) => {
    Object.keys(row).forEach((key: string) => {
      if (seen[key]) { return; }
      seen[key] = true;
      columns.push(key);
    });
  });
  return columns;
}

/** M14-T4: bounded scalars for summary/chart/wizard extras. Scalars
 * only — nested objects/arrays yield '' (the brick pre-shapes anything
 * meaningful, e.g. a length count); the orchestrator never invents. */
export const VIEW_EXTRA_MAX_LENGTH = 120;

export function scalarText(value: unknown): string {
  if (value === null || value === undefined) { return ''; }
  if (typeof value === 'string') {
    const trimmed = value.trim();
    return trimmed;
  }
  if (typeof value === 'number') { return isFinite(value) ? String(value) : ''; }
  if (typeof value === 'boolean') { return value ? 'true' : 'false'; }
  if (value instanceof Date) { return value.toISOString(); }
  return '';
}

export function capText(text: string, max: number = VIEW_EXTRA_MAX_LENGTH): string {
  return String(text || '').length > max ? String(text).slice(0, max) + '...' : String(text || '');
}

/** Verbatim move from CtHostContextAdapter (pre-T4 humanizePreviewKey). */
export function humanizeViewKey(key: string): string {
  const spaced = String(key || '')
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .replace(/[_-]+/g, ' ')
    .trim();
  if (!spaced) {
    return String(key || '');
  }
  return spaced.charAt(0).toUpperCase() + spaced.slice(1);
}

/** Verbatim move from CtHostContextAdapter (pre-T4 previewValueText):
 * nested objects/arrays join their non-empty parts; scalars are
 * trimmed to 120 chars. Used by the surface preview and the view
 * extras. */
export function previewValueText(value: any): string {
  if (value === null || value === undefined || typeof value === 'object') {
    if (value && typeof value === 'object' && !Array.isArray(value)) {
      return Object.keys(value)
        .map((part) => previewValueText(value[part]))
        .filter((part) => !!part)
        .join(', ');
    }
    if (Array.isArray(value)) {
      return value.map((entry) => previewValueText(entry)).filter((part) => !!part).join(', ');
    }
    return '';
  }
  return String(value).trim().slice(0, 120);
}
