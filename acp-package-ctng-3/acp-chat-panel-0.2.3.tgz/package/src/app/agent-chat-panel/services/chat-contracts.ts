import { AgentSurface } from './surface-contracts';

export type ChatResponseStatus = 'completed' | 'failed' | 'cancelled';

export interface ChatContext {
  app: Record<string, unknown>;
  host: Record<string, unknown>;
  catalog: {
    itemCount: number;
  };
}

export interface ChatRequest {
  schemaVersion: string;
  requestId: string;
  conversationId: string;
  messageId: string;
  prompt: string;
  /** M10-T1: prior-turn thread for the harness (excludes the current prompt). */
  history?: Array<{ role: 'user' | 'assistant'; text: string }>;
  context: ChatContext;
  capabilities?: string[];
  client: {
    appId: string;
    appVersion?: string;
    locale?: string;
  };
}

/**
 * P0-A sanitizer child (before parse) — contract only; no FE behaviour wired yet.
 * - event 'buddy_sanitize' (action owned by harness) carries raw buddy notes via `text`.
 * - FE must not parse; sanitize is an agent hop emitted before buddy_parse.
 */
export interface BuddySanitizeResult {
  /** Human-facing chat line for the sanitize hop. */
  chatText: string;
  /** Sanitized notes: one student per line; empty slots as ", ,". */
  buddyText: string;
  /** Warnings only; no invented fields. */
  notes?: string[];
}

export interface ChatEmitEventRequest {
  requestId: string;
  messageId: string;
  conversationId: string;
  correlationId: string;
  /** 'buddy_sanitize': raw buddy notes hop before parse (P0-A). */
  event: 'form_submit' | 'confirm' | 'cancel' | 'buddy_sanitize' | string;
  action: string;
  /** Raw buddy notes for the sanitize hop (event 'buddy_sanitize'). */
  text?: string;
  values?: Record<string, unknown>;
  /** BW-T6: surface formId (e.g. student-enrol-buddy) for save-outcome handling. */
  formId?: string;
  /** BW-T6: buddy-workspace record id correlated with this save. */
  recordId?: string;
  /**
   * D6.4-fix: the open workspace fields (ids + order) from the store
   * surface, passed on buddy_parse / student.enrol.parse so the parse
   * hop keeps the field list even after a host/harness restart. A plain
   * pass-through of what the store already holds — no invention.
   */
  fields?: Array<{ id: string; label?: string; type?: string; required?: boolean }>;
  /**
   * M5-T4 follow-up: host-side marker for the post-save authoring hop —
   * the save already persisted via CTApi; this emit only asks the harness
   * to author the Actions catalog. The persist intercept skips it (never
   * a second save) and the host handles its reply silently.
   */
  activityAuthoring?: boolean;
  context?: {
    route?: string;
    persona?: string;
    [key: string]: unknown;
  };
}

export interface ChatAction {
  id: string;
  label: string;
  payload: Record<string, unknown>;
}

export interface ChatSuggestionAction {
  id: string;
  label: string;
  action: ChatAction;
}

export interface ChatBlock {
  type: 'text' | 'markdown' | 'status' | 'data' | 'suggestions' | 'form' | 'confirmation' | 'link' | 'error' | string;
  id?: string;
  text?: string;
  markdown?: string;
  level?: 'info' | 'loading' | 'warning' | 'success';
  items?: Array<{ key: string; value: string }> | ChatSuggestionAction[];
  title?: string;
  formId?: string;
  submitAction?: string;
  correlationId?: string;
  fields?: Array<{
    id: string;
    type: 'text' | 'number' | 'select';
    label: string;
    required?: boolean;
    options?: Array<{ value: string; label: string }>;
  }>;
  confirmAction?: string;
  cancelAction?: string;
  label?: string;
  href?: string;
  target?: 'internal' | 'external' | string;
  message?: string;
  details?: string;
}

export interface ChatResponse {
  schemaVersion: string;
  requestId: string;
  conversationId: string;
  messageId: string;
  parentMessageId: string;
  agent: {
    id: string;
    displayName?: string;
    avatarKey?: string;
  };
  status: ChatResponseStatus;
  blocks: ChatBlock[];
  // Optional surface payload: transport-level contract for driving dynamic UI components
  // (M3 student enrol: type student-enrol-form; see EXAMPLE_STUDENT_ENROL_FORM_SURFACE).
  surface?: AgentSurface;
  // M5-T4: harness-authored Actions catalog for a settled form_submit
  // (enroll saves) — per-row item (recordId + actions) + whole-pane
  // menuActions; see HarnessSaveActivity in ct-bot-host-protocol.
  activity?: import('./ct-bot-host-protocol').HarnessSaveActivity;
  contextPatch?: Record<string, unknown>;
  actions?: ChatAction[];
  diagnostics?: {
    traceId?: string;
  };
}
