import { Router } from '@angular/router';
import { ToolCatalogDefinition, ToolInputSchema } from '../../ai-context-tools';

export interface HarnessToolDefinition {
  name: string;
  description: string;
  input_schema: ToolInputSchema;
}

type JsonSchema = { [key: string]: any };

const CORE_TOOL_NAMES = [
  'get_current_view',
  'get_route_focus_context',
  'get_ui_context',
  'get_current_entity_focus',
  'get_current_list_snapshot',
  'get_current_filters_and_search',
  'get_screen_context_signals'
];

const FEES_TOOL_NAMES = [
  'get_fee_transaction_work_context',
  'get_fee_transactions_list_context',
  'get_suspense_allocation_context',
  'get_refund_work_context',
  'record_fee_payment',
  'allocate_suspense_transaction',
  'create_suspense_transaction',
  'create_fee_refund',
  'update_fee_transaction_meta',
  'set_fee_transaction_status',
  'set_refund_status',
  'send_fee_receipt_email',
  'upsert_fee_definition'
];

/**
 * Keeps the model's tool catalogue small and route-aware. The backend-agent
 * bridge is always available because it is implemented by the harness loop.
 */
export function buildFilteredHarnessTools(router: Router, definitions: ToolCatalogDefinition[]): HarnessToolDefinition[] {
  const inFees = (router.url || '').split('?')[0].replace(/^\//, '').split('/')[0] === 'fees';
  const allowed = CORE_TOOL_NAMES.concat(['call_backend_agent']);
  if (inFees) {
    allowed.push.apply(allowed, FEES_TOOL_NAMES as any);
  }

  const byName: { [name: string]: ToolCatalogDefinition | { name: string; description: string; input_schema: ToolInputSchema } } = {};
  definitions.forEach((definition) => byName[definition.name] = definition);
  byName.call_backend_agent = {
    name: 'call_backend_agent',
    description: 'Invoke a backend domain agent through the harness.',
    input_schema: {
      type: 'object',
      properties: {
        version: { type: 'string', enum: ['1.0'] },
        action: { type: 'string', enum: ['invoke'] },
        requestId: { type: 'string' },
        agent: {
          type: 'object',
          properties: {
            id: { type: 'string' },
            name: { type: 'string' }
          },
          required: ['id'],
          additionalProperties: true
        },
        input: { type: 'object' },
        context: { type: 'object' },
        options: { type: 'object' },
        metadata: { type: 'object' }
      },
      required: ['version', 'agent', 'input'],
      additionalProperties: true
    }
  };

  return allowed
    .filter((name, index, names) => names.indexOf(name) === index && !!byName[name])
    .map((name) => ({
      name,
      description: byName[name].description,
      input_schema: normalizeToolSchema(byName[name].input_schema || { type: 'object', properties: {} })
    }));
}

function normalizeToolSchema(schema: any): ToolInputSchema {
  var root = normalizeSchemaNode(schema, 'object');
  if (root.type !== 'object') {
    return { type: 'object', properties: {} };
  }
  if (!root.properties || typeof root.properties !== 'object') {
    root.properties = {};
  }
  return root as ToolInputSchema;
}

function normalizeSchemaNode(node: any, fallbackType: string): JsonSchema {
  var base: JsonSchema = (node && typeof node === 'object' && !Array.isArray(node)) ? Object.assign({}, node) : {};

  if (!base.type) {
    base.type = inferSchemaType(base, fallbackType);
  }

  if (base.type === 'object') {
    var properties = (base.properties && typeof base.properties === 'object' && !Array.isArray(base.properties))
      ? base.properties
      : {};
    var normalizedProps: { [key: string]: any } = {};
    Object.keys(properties).forEach(function (key) {
      normalizedProps[key] = normalizeSchemaNode(properties[key], 'string');
    });
    base.properties = normalizedProps;
  }

  if (base.type === 'array') {
    base.items = normalizeSchemaNode(base.items, 'object');
  }

  if (Array.isArray(base.anyOf)) {
    base.anyOf = base.anyOf.map(function (member: any) { return normalizeSchemaNode(member, 'object'); });
  }
  if (Array.isArray(base.oneOf)) {
    base.oneOf = base.oneOf.map(function (member: any) { return normalizeSchemaNode(member, 'object'); });
  }

  return base;
}

function inferSchemaType(node: JsonSchema, fallbackType: string): string {
  if (node.properties || node.required || node.additionalProperties !== undefined) {
    return 'object';
  }
  if (node.anyOf || node.oneOf) {
    return 'object';
  }
  if (node.items || node.minItems !== undefined || node.maxItems !== undefined) {
    return 'array';
  }
  if (node.enum && Array.isArray(node.enum) && node.enum.length) {
    var first = node.enum[0];
    if (typeof first === 'number') {
      return 'number';
    }
    if (typeof first === 'boolean') {
      return 'boolean';
    }
    if (typeof first === 'object') {
      return 'object';
    }
    return 'string';
  }
  if (node.minimum !== undefined || node.maximum !== undefined || node.exclusiveMinimum !== undefined || node.exclusiveMaximum !== undefined) {
    return 'number';
  }
  return fallbackType;
}
