import { Inject, Injectable, InjectionToken } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';
import { ChatBlock, ChatRequest, ChatResponse } from './chat-contracts';

export interface HarnessTransportClient {
  send(request: ChatRequest): Observable<ChatResponse>;
}

export const HARNESS_TRANSPORT_CLIENT = new InjectionToken<HarnessTransportClient>('HARNESS_TRANSPORT_CLIENT');

@Injectable({ providedIn: 'root' })
export class ChatTransportAdapterService {
  constructor(@Inject(HARNESS_TRANSPORT_CLIENT) private readonly client: HarnessTransportClient) {}

  send(request: ChatRequest): Observable<ChatResponse> {
    return this.client.send(request).pipe(
      map((response) => this.normalizeResponse(request, response))
    );
  }

  private normalizeResponse(request: ChatRequest, response: ChatResponse): ChatResponse {
    const hasEnvelope =
      response.schemaVersion &&
      response.requestId &&
      response.conversationId &&
      response.messageId &&
      response.parentMessageId &&
      response.status &&
      Array.isArray(response.blocks);

    if (!hasEnvelope) {
      throw new Error('Received an invalid response. Please try again.');
    }

    if (response.requestId !== request.requestId) {
      throw new Error('Received an unexpected response. Please try again.');
    }

    if (response.conversationId !== request.conversationId) {
      throw new Error('Received an unexpected response. Please try again.');
    }

    if (response.parentMessageId !== request.messageId) {
      throw new Error('Received an unexpected response. Please try again.');
    }

    const blocks = response.blocks.length > 0
      ? response.blocks
      : [
          {
            type: 'error',
            message: 'I could not generate a readable response. Please try again.',
          } as ChatBlock,
        ];

    return {
      ...response,
      blocks,
    };
  }
}
