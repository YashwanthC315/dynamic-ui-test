import { HttpClient, HttpHeaders } from '@angular/common/http';
import { InjectionToken, Injectable, Inject, Optional } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { HostContextBag } from './ct-bot-host-protocol';

/**
 * M15-T1: agent file-run port — one file-run per utterance, POSTed by
 * the host (the panel does not call it yet; the event socket stays as
 * it is). Everything host-specific — base url, bearer token, agent_path
 * — comes from the host config (AGENT_FILE_RUN_CONFIG, mapped from the
 * environment in AppModule), never literals in this file.
 *
 * The wire contract is strict:
 *   POST {base}/api/playground/agent-file-runs
 *   Authorization: Bearer <token>
 *   { "agent_path": "<from config>", "user_prompt": "<one string>" }
 * user_prompt carries history + host context bag + this turn's text as
 * ONE string. system_prompt in the body is a mistake (the API 422s it —
 * correctly). A 202 response returns { run_id }; the caller (a ChatEffects
 * action flow) stores it under the existing conversationId — this port
 * only POSTs.
 */

export interface AgentFileRunConfig {
  baseUrl: string;
  bearerToken: string;
  agentPath: string;
  /** M15-T7: the suggestions agent file (host config). Chips run only
   * when set; the run is started by the reply effect for persisted
   * assistant replies. */
  suggestionsAgentPath?: string;
}

export const AGENT_FILE_RUN_CONFIG = new InjectionToken<AgentFileRunConfig>('AGENT_FILE_RUN_CONFIG');

/** M10-T1 history shape reused verbatim (text-only prior turns). */
export interface AgentFileRunTurn {
  role: 'user' | 'assistant';
  text: string;
}

export interface AgentFileRunRequest {
  /** The conversation the utterance belongs to; run_id is stored under it. */
  conversationId: string;
  /** This turn's text — the user prompt, or the pasted buddy text on a
   * buddy-parse turn. One utterance, one file run. */
  turnText: string;
  /** Prior turns of THIS conversation (may be absent on the first). */
  history?: AgentFileRunTurn[];
  /** The composed host context bag for this turn (may be absent). */
  context?: HostContextBag;
  /** M15-T3: the panel request this run answers; rides back so the reply
   * can be published as a ChatResponse the panel already renders. */
  requestId?: string;
  /** M15-T3: the user message id — becomes the reply's parentMessageId. */
  messageId?: string;
  /** M15-T7: per-run agent file override — STILL host config (the reply
   * effect passes the suggestions agent path from AGENT_FILE_RUN_CONFIG
   * for chips runs); absent falls back to this.config.agentPath. */
  agentPath?: string;
}

export abstract class AgentFileRunPort {
  /** POSTs one file run; emits the 202 run_id. The port only POSTs —
   * it does not decide and does not keep state (M15-T1 follow-up: run
   * ids live in the agentChat store under conversationId). */
  abstract startFileRun(request: AgentFileRunRequest): Observable<string>;

  /**
   * M15-T3: the reply carries no agent byline, so the host reads the
   * run record: GET {base}/api/playground/runs/{run_id} -> body.label.
   * Emits the label the caller copies onto message.agent; '' when the
   * record has no label (caller falls back to CT-Bot Assistant).
   */
  abstract readRunLabel(runId: string): Observable<string>;
}

/**
 * user_prompt is ONE string: prior turns, then the host context bag as
 * compact JSON, then this turn's text. Deterministic; no extra prose.
 */
export function buildFileRunUserPrompt(request: AgentFileRunRequest): string {
  const parts: string[] = [];
  (request.history || []).forEach((turn: AgentFileRunTurn) => {
    const role = turn.role === 'assistant' ? 'assistant' : 'user';
    if (turn.text && String(turn.text).trim()) {
      parts.push(role + ': ' + String(turn.text));
    }
  });
  if (request.context && typeof request.context === 'object' && Object.keys(request.context).length) {
    parts.push('[host_context] ' + JSON.stringify(request.context));
  }
  parts.push(request.turnText || '');
  return parts.join('\n');
}

@Injectable({ providedIn: 'root' })
export class HttpAgentFileRunPort extends AgentFileRunPort {
  private readonly config: AgentFileRunConfig;

  constructor(
    private readonly http: HttpClient,
    @Inject(AGENT_FILE_RUN_CONFIG) config: AgentFileRunConfig
  ) {
    super();
    this.config = config || { baseUrl: '', bearerToken: '', agentPath: '' };
  }

  startFileRun(request: AgentFileRunRequest): Observable<string> {
    if (!this.config.agentPath || !this.config.bearerToken) {
      return new Observable<string>((observer) => {
        observer.error(new Error('Agent file-run port is not configured (AGENT_FILE_RUN_BEARER_TOKEN / AGENT_FILE_RUN_AGENT_PATH).'));
      });
    }
    if (!request || !request.conversationId) {
      return new Observable<string>((observer) => {
        observer.error(new Error('Agent file-run requires a conversationId.'));
      });
    }
    const conversationId = String(request.conversationId);
    const agentPath = (request.agentPath && String(request.agentPath).trim()) || this.config.agentPath;
    if (!agentPath) {
      return new Observable<string>((observer) => {
        observer.error(new Error('Agent file-run is not configured (AGENT_FILE_RUN_AGENT_PATH).'));
      });
    }
    const body = {
      agent_path: agentPath,
      user_prompt: buildFileRunUserPrompt(request)
    };
    return new Observable<string>((observer) => {
      this.http.post<{ run_id: string }>(
        this.normalizeBaseUrl(this.config.baseUrl) + '/api/playground/agent-file-runs',
        body,
        { headers: this.buildHeaders(), observe: 'response' }
      ).subscribe(
        (response) => {
          const runId = this.readRunId(response && (response as any).body);
          if (!runId) {
            observer.error(new Error('Agent file-run response had no run_id (status ' + ((response && (response as any).status) || '?') + ').'));
            return;
          }
          observer.next(runId);
          observer.complete();
        },
        (error) => {
          observer.error(new Error('Agent file-run failed: ' + this.readErrorText(error)));
        }
      );
    });
  }

  private readRunId(body: any): string {
    if (body && typeof body === 'object') {
      const runId = body['run_id'] !== undefined && body['run_id'] !== null ? String(body['run_id']).trim() : '';
      if (runId) { return runId; }
    }
    return '';
  }

  readRunLabel(runId: string): Observable<string> {
    const target = String(runId || '').trim();
    return new Observable<string>((observer) => {
      if (!target || !this.config.bearerToken) {
        observer.next('');
        observer.complete();
        return () => undefined;
      }
      this.http.get(this.normalizeBaseUrl(this.config.baseUrl) + '/api/playground/runs/' + encodeURIComponent(target),
        { headers: this.buildHeaders() }
      ).subscribe(
        (body: any) => {
          const label = body && typeof body === 'object' && body['label'] !== undefined && body['label'] !== null
            ? String(body['label']).trim()
            : '';
          observer.next(label);
          observer.complete();
        },
        () => {
          // Fallback is the caller's (CT-Bot Assistant); no invented label.
          observer.next('');
          observer.complete();
        }
      );
      return () => undefined;
    });
  }

  private buildHeaders(): HttpHeaders {
    return new HttpHeaders({
      'Authorization': 'Bearer ' + this.config.bearerToken,
      'Content-Type': 'application/json'
    });
  }

  private normalizeBaseUrl(url: string): string {
    const trimmed = String(url || '').trim().replace(/\/+$/, '');
    return trimmed;
  }

  private readErrorText(error: any): string {
    if (error && error.error) {
      if (typeof error.error === 'string' && error.error.trim()) { return error.error.trim(); }
      if (error.error.message) { return String(error.error.message); }
    }
    if (error && error.message) { return String(error.message); }
    return 'unknown error';
  }
}
