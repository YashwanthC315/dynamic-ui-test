/**
 * D5: APP-owned enrol / organization form fixtures.
 *
 * The mock harness (mock-harness/server.ts) imports these builders but
 * does NOT author the field lists itself — this module is owned by the
 * APP side (mirrors surface-contracts + the real student/org add panels).
 * Course/parent/owner options come from host context.formOptions; no
 * option lists are invented here.
 */

export interface FormSelectOption {
  label: string;
  value: string;
}

export interface FormOptionsContext {
  courses?: FormSelectOption[];
  parentOrgs?: FormSelectOption[];
  ownerOrgs?: FormSelectOption[];
  orgs?: FormSelectOption[];
}

function normalizeSelectLabel(label: string): string {
  return String(label || '').trim().replace(/\s+/g, ' ').toLowerCase();
}

function mapSelectOptions(raw: unknown): FormSelectOption[] {
  if (!Array.isArray(raw)) {
    return [];
  }
  const options: FormSelectOption[] = [];
  const seenValues: Record<string, boolean> = {};
  const seenLabels: Record<string, boolean> = {};
  for (let i = 0; i < raw.length && options.length < 100; i++) {
    const item = raw[i];
    if (!item || typeof item !== 'object') {
      continue;
    }
    const valueSource = (item as any).value != null ? (item as any).value : (item as any).id;
    const value = valueSource == null ? '' : String(valueSource).trim();
    const labelSource = (item as any).label != null ? (item as any).label : (item as any).name;
    const label = (labelSource == null ? value : String(labelSource).trim()) || value;
    if (!value || !label) {
      continue;
    }
    const labelKey = normalizeSelectLabel(label);
    if (seenValues[value] || seenLabels[labelKey]) {
      continue;
    }
    seenValues[value] = true;
    seenLabels[labelKey] = true;
    options.push({ label: label, value: value });
  }
  return options;
}

export function studentEnrolOpenMessage(formOptions?: FormOptionsContext | null): string {
  const courses = mapSelectOptions(formOptions && formOptions.courses);
  const text = 'Opening the student enrollment form. Fill in the details in the panel.';
  if (courses.length) {
    return text;
  }
  return text + ' Course options are not available in this session.';
}

export function orgAddOpenMessage(formOptions?: FormOptionsContext | null): string {
  const parentOrgs = mapSelectOptions(formOptions && (formOptions.parentOrgs || formOptions.orgs));
  const ownerOrgs = mapSelectOptions(formOptions && (formOptions.ownerOrgs || formOptions.orgs));
  const text = 'Opening the Add Organization form. Fill in the details in the panel.';
  if (parentOrgs.length || ownerOrgs.length) {
    return text;
  }
  return text + ' Parent and owner options are not available in this session.';
}

export function buildStudentEnrolFormSurface(formOptions?: FormOptionsContext | null): Record<string, unknown> {
  // Required on the real student add panel: name, DOB, gender, course.id (Save + HTML required).
  // Optional enrol fields are omitted from this M3 demo schema.
  const courseOptions = mapSelectOptions(formOptions && formOptions.courses);
  return {
    type: 'student-enrol-form',
    id: 'surface_stu_enrol_demo',
    title: 'Enroll Student',
    formId: 'student-enrol-thin',
    submitAction: 'student.enrol.submit',
    correlationId: 'surface_stu_enrol_demo',
    data: {
      name: '',
      dob: '',
      gender: '',
      courseId: ''
    },
    schema: {
      fields: [
        { id: 'name', label: 'Name', type: 'text', required: true, maxLength: 50, placeholder: 'first  middle  last' },
        { id: 'dob', label: 'Date Of Birth', type: 'date', required: true, placeholder: 'dd/mm/yyyy' },
        {
          id: 'gender',
          label: 'Gender',
          type: 'select',
          required: true,
          placeholder: '',
          options: [
            { label: 'Female', value: 'Female' },
            { label: 'Male', value: 'Male' }
          ]
        },
        {
          id: 'courseId',
          label: 'Course',
          type: 'select',
          required: true,
          placeholder: '-- Select course --',
          options: courseOptions
        }
      ]
    }
  };
}

export function buildOrgAddFormSurface(formOptions?: FormOptionsContext | null): Record<string, unknown> {
  // Org Details on the real org add panel: Name, Short Name, Parent, Owner.
  const parentOrgs = mapSelectOptions(formOptions && (formOptions.parentOrgs || formOptions.orgs));
  const ownerOrgs = mapSelectOptions(formOptions && (formOptions.ownerOrgs || formOptions.orgs));
  const orgOptions = ownerOrgs.length ? ownerOrgs : parentOrgs;
  return {
    type: 'org-add-form',
    id: 'surface_org_add_demo',
    title: 'Add Organization',
    formId: 'org-add-thin',
    submitAction: 'org.add.submit',
    correlationId: 'surface_org_add_demo',
    data: {
      name: '',
      shortName: '',
      parentId: '',
      ownerId: ''
    },
    schema: {
      fields: [
        { id: 'name', label: 'Name', type: 'text', required: true, maxLength: 50 },
        { id: 'shortName', label: 'Short Name', type: 'text', required: true, maxLength: 6, helperText: 'Up to 6 characters' },
        { id: 'parentId', label: 'Parent', type: 'select', placeholder: 'None', options: parentOrgs },
        { id: 'ownerId', label: 'Owner', type: 'select', placeholder: 'None', options: orgOptions }
      ]
    }
  };
}
