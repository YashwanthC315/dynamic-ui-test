import { ComponentFactoryResolver, ComponentRef, Injectable, ViewContainerRef } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';

import { OrgAddFieldComponent, OrgAddFieldOption, OrgAddFieldSchema } from '../components/org-add-field.component';

interface CreatedOrgField {
  ref: ComponentRef<OrgAddFieldComponent>;
  sub: Subscription | null;
}

@Injectable({ providedIn: 'root' })
export class OrgAddSurfaceRendererService {
  private created: CreatedOrgField[] = [];
  private viewContainerRef: ViewContainerRef | null = null;

  constructor(private readonly componentFactoryResolver: ComponentFactoryResolver) {}

  renderFields(
    fields: OrgAddFieldSchema[],
    values: Record<string, any>,
    container: ViewContainerRef,
    getOptions: (field: OrgAddFieldSchema) => OrgAddFieldOption[],
    onValueChange: (fieldId: string, value: any) => void
  ): void {
    if (!container) {
      return;
    }

    this.viewContainerRef = container;
    this.clearAllComponents();
    const factory = this.componentFactoryResolver.resolveComponentFactory(OrgAddFieldComponent);

    fields.forEach((field) => {
      const ref = container.createComponent(factory);
      ref.instance.field = field;
      ref.instance.value = values[field.id];
      ref.instance.options = getOptions(field);
      const sub = ref.instance.valueChange.subscribe((value) => onValueChange(field.id, value));
      ref.changeDetectorRef.detectChanges();
      this.created.push({ ref: ref, sub: sub });
    });
  }

  clearAllComponents(): void {
    this.created.forEach((item) => {
      if (item.sub) {
        item.sub.unsubscribe();
      }
      item.ref.destroy();
    });
    this.created = [];
    if (this.viewContainerRef) {
      this.viewContainerRef.clear();
    }
  }
}
