import { FrontendAgentService } from './frontend-agent.service';

describe('FrontendAgentService', function () {
  var service: any;

  beforeEach(function () {
    var routerMock: any = { url: '/fees/transactions' };
    var state = { app: { accessToken: 'token-1' } };
    var storeMock: any = {
      subscribe: function (listener: any) {
        listener(state);
        return { unsubscribe: function () { return; } };
      }
    };
    service = new FrontendAgentService(routerMock, storeMock, null as any);
  });

  it('appends assistant tool_calls before tool result messages', async function () {
    var sentPayloads: any[] = [];
    var socket: any = {
      readyState: WebSocket.OPEN,
      send: function (payload: string) { sentPayloads.push(JSON.parse(payload)); },
      close: function () { return; }
    };

    service.activeRun = {
      runId: 'run-1',
      conversationId: 'conv-1',
      requestId: 'req-1',
      socket: socket,
      cancelled: false,
      terminal: false,
      deltas: []
    };

    service.handleServerEvent(JSON.stringify({
      type: 'tool_calls',
      run_id: 'run-1',
      tool_calls: [
        {
          id: 'tc-1',
          name: 'call_backend_agent',
          arguments: { version: '1.0', agent: { id: 'fees-agent' }, input: { task: 'check' } }
        }
      ]
    }));

    await Promise.resolve();
    await Promise.resolve();

    var assistantIndex = service.messages.findIndex(function (message: any) {
      return message.role === 'assistant' && Array.isArray(message.tool_calls) && message.tool_calls.length === 1 && message.tool_calls[0].id === 'tc-1';
    });
    var toolIndex = service.messages.findIndex(function (message: any) {
      return message.role === 'tool' && message.tool_call_id === 'tc-1';
    });

    expect(assistantIndex).toBeGreaterThan(-1);
    expect(toolIndex).toBeGreaterThan(assistantIndex);
    expect(service.messages[assistantIndex].tool_calls[0].function.name).toBe('call_backend_agent');
    expect(service.messages[assistantIndex].tool_calls[0].function.arguments).toContain('"version":"1.0"');
    expect(sentPayloads[sentPayloads.length - 1].type).toBe('tool_results');
  });

  it('does not send cancel once a run is terminal', function () {
    var sent = false;
    var socket: any = {
      readyState: WebSocket.OPEN,
      send: function () { sent = true; },
      close: function () { return; }
    };

    service.activeRun = {
      runId: 'run-2',
      conversationId: 'conv-2',
      requestId: 'req-2',
      socket: socket,
      cancelled: false,
      terminal: true,
      deltas: []
    };

    service.cancelRun('transport subscription cancelled');
    expect(sent).toBe(false);
  });

  it('emits a safe generic message for harness run failures and logs technical details', function () {
    var socket: any = {
      readyState: WebSocket.OPEN,
      send: function () { return; },
      close: function () { return; }
    };
    service.activeRun = {
      runId: 'run-3',
      conversationId: 'conv-3',
      requestId: 'req-3',
      socket: socket,
      cancelled: false,
      terminal: false,
      deltas: []
    };

    var emitted: any = null;
    service.error$.subscribe(function (event: any) { emitted = event; });
    var consoleSpy = spyOn(console, 'error');
    var technical = 'OpenAI call failed (422): {"error":"bad_request"} <html>stack</html>';

    service.handleServerEvent(JSON.stringify({
      type: 'error',
      run_id: 'run-3',
      code: 'run_failed',
      message: technical
    }));

    expect(emitted.code).toBe('run_failed');
    expect(emitted.message).toBe('Unable to fulfill your request. Please try again later.');
    expect(consoleSpy).toHaveBeenCalled();
    expect(JSON.stringify(consoleSpy.calls.mostRecent().args)).toContain(technical);
  });

  it('emits session-expired message when access token is missing', function () {
    var routerMock: any = { url: '/fees/transactions' };
    var storeMock: any = {
      subscribe: function (listener: any) {
        listener({ app: { accessToken: '' } });
        return { unsubscribe: function () { return; } };
      }
    };
    var noTokenService: any = new FrontendAgentService(routerMock, storeMock, null as any);
    try { sessionStorage.removeItem('accessToken'); } catch (error) { /* non-browser test env */ }

    var emitted: any = null;
    noTokenService.error$.subscribe(function (event: any) { emitted = event; });
    noTokenService.startRun('hello', { runId: 'run-4', conversationId: 'conv-4', requestId: 'req-4' });

    expect(emitted.code).toBe('missing_access_token');
    expect(emitted.message).toBe('Your session expired. Please sign in again.');
  });
});
