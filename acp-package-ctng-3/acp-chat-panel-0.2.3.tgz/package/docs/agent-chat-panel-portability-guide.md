# Agent Chat Panel Portability Guide (Phase 3)

This guide explains how to reuse the chat panel in another Angular app with minimum changes while keeping feature parity.

Phase 3 introduces a plugin-based right-panel surface architecture:

- Core panel no longer hard-codes institute/org/student surface components.
- Dynamic surfaces are discovered via `AGENT_CHAT_SURFACE_PLUGINS` token.
- Default ctng4 plugins are provided here for backward compatibility.

## What you should copy

For full feature parity, copy the `agent-chat-panel` feature folder (not only TS + HTML):

- `components/*`
- `services/*`
- `services/portability/*`
- `store/*` (if using NgRx integration mode)
- `styles/agent-chat-panel.css`

If you only copy `agent-chat-panel.component.ts` and `agent-chat-panel.component.html`, the panel can render but transport/history/surface behavior will be incomplete.

## Integration modes

### Mode A: Full mode (recommended)

Use this when you want complete parity: transport, history, suggestions/actions, and plugin surfaces.

1. Register providers:

```ts
import { DEFAULT_AGENT_CHAT_PORT_PROVIDERS } from 'src/app/agent-chat-panel/services/portability/default-agent-chat-port.providers';

@NgModule({
  providers: [
    ...DEFAULT_AGENT_CHAT_PORT_PROVIDERS,
    // your transport + context adapter bindings
  ],
})
export class AppModule {}
```

2. If you use NgRx mode, include chat reducer/effects in your host wiring.

3. Ensure these Angular modules are available where panel is declared:

- `FormsModule`
- `CommonModule`

4. Include chat CSS:

- `src/app/agent-chat-panel/styles/agent-chat-panel.css`

### Mode B: Lite mode

Use this when you want basic panel UI first, then add backend/history/plugins incrementally.

1. Provide custom implementations for these tokens:

- `AGENT_CHAT_STATE_PORT`
- `AGENT_CHAT_RESPONSE_PORT`

2. Skip `AGENT_CHAT_SURFACE_PLUGINS` initially.

3. Add plugins later once your surfaces are ready.

## Surface plugin contract

Surface plugins are registered using the multi-token `AGENT_CHAT_SURFACE_PLUGINS`.

Plugin shape (from `agent-chat-port.contracts.ts`):

```ts
export interface AgentChatSurfacePluginPort {
  type: string;
  title?: string;
  component: Type<any>;
  bind?: (surface: AgentSurface, instance: any, helpers: AgentChatSurfacePluginHelpers) => void;
}
```

`bind` is where you map transport `surface` payload to component inputs and wire form submit callbacks.

## Example custom plugin

```ts
@Injectable({ providedIn: 'root' })
export class CustomTableSurfacePlugin implements AgentChatSurfacePluginPort {
  type = 'table';
  title = 'Table';
  component = MyTableSurfaceComponent;

  bind(surface: AgentSurface, instance: any): void {
    instance.columns = (surface as any).columns || [];
    instance.rows = (surface as any).rows || [];
  }
}
```

Register it:

```ts
providers: [
  { provide: AGENT_CHAT_SURFACE_PLUGINS, useExisting: CustomTableSurfacePlugin, multi: true },
]
```

## Host template usage

```html
<app-agent-chat-panel
  [isOpen]="agentPanelOpen"
  [appContext]="agentAppContext"
  [hostContext]="agentHostContext"
  [entities]="agentEntities"
  [navigationTabs]="navPerms"
  (panelWidthChange)="agentPanelWidth = $event"
  (agentEvent)="onAgentEvent($event)">
</app-agent-chat-panel>
```

## Important notes

1. Keep allowlisted navigation behavior unless you intentionally change security posture.
2. If your app does not use Font Awesome, icon classes will degrade visually but functionality remains.
3. For Angular 7 hosts, keep `entryComponents` for dynamic surface components.
4. For newer Angular versions, convert dynamic surfaces to Ivy/standalone-compatible loading patterns.

## Quick checklist

1. Copy panel feature files.
2. Register portability providers.
3. Register chat reducer/effects if using NgRx mode.
4. Register surface plugins (or rely on defaults).
5. Add CSS and host template wiring.
6. Validate send, history, navigation, and form-surface submit paths.
