# @acp/chat-panel v0.3.12 Release Notes

Workspace closes the Assembler. No other behavior changes.

## Changed files
- `dist/acp-harness-bridge.js`: one observer/listener pair on the Workspace element, removed on `disconnect()`.
- Docs: SPEC_DOC 5, INTEGRATION_SPEC 12.3, README, CHANGELOG, AGENT_GUIDE. Test: `tests/workspace-close.html`.
- Not changed: `dist/acp-chat-panel.js`, typings, styles, host wiring (the Assembler's own close event already syncs host state).

## Behavior
| Action | Result |
|---|---|
| Close Workspace (x, `close()`, host binding, reset) | Assembler closes too |
| Close the Assembler | Workspace stays open |
| Open the Assembler while Workspace is closed | Stays open |
| Workspace closes with the Assembler already closed | Nothing happens |
