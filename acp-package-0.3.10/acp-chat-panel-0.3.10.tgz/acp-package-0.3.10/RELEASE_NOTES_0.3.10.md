# @acp/chat-panel v0.3.10 Release Notes

Date handling and validation sync fixes on top of v0.3.9. No other behavior changes.

## Changed files
- `dist/acp-chat-panel.js`: `BuddyEnrolWorkspaceSurface` plus two small helpers. Nothing else.
- Docs: SPEC_DOC 6.3, README, CHANGELOG, AGENT_GUIDE. Test: `tests/bulk-enrollment.html`.
- Not changed: harness connector, chat panel, Workspace/Assembler containers, styles, typings.

## Behavior
| Scenario | v0.3.10 |
|---|---|
| Invalid date dropped by the agent | Shown in the form from the raw text; corrected date replaces it in the raw text |
| Date or course corrected, then Validate | Raw text keeps the correction; form and raw text stay in sync |
| Agent echoes the original raw text in its reply | Ignored; the textarea is never overwritten |
| Raw text edited by hand, then Validate | Text kept; Submit blocked with a note to click Prepare |
| Validation passed but a required field is empty | Reason shown under the form |
| Agent renumbers record ids | Matched by unique name |
